/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 * Copyright (c) 1995-2010, Stanford University. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FCAM_TIME_H
#define FCAM_TIME_H

//! \file
//! The Time class encapsulates a wall clock time.

#include <stdio.h>
#include <time.h>
#include <string>

namespace FCam
{

/** Time represents a wall clock time. Not to be used for
 * representing a duration of time. Two times can be subtracted to
 * return the difference between them in microseconds. A number of
 * microseconds can be added to or subtracted from time to return
 * a new time. Times also support all the comparison operators.
 */

class Time
{
public:

    /** The current time */
    static Time now();

    /** Construct a Time from a number of seconds and microseconds */
    Time( int s, int us )
    {
        t.tv_sec = s;
        t.tv_usec = us;
    }

    /** Construct a Time from a timeval */
    Time( timeval t_ ) : t( t_ ) {};

    /** Construct a Time from a struct timespec */
    Time( struct timespec t_ )
    {
        t.tv_sec = t_.tv_sec;
        t.tv_usec = t_.tv_nsec / 1000;
    }

    Time()
    {
        t.tv_sec = 0;
        t.tv_usec = 0;
    }

    /** The number of seconds since the epoch */
    int s() const
    {
        return t.tv_sec;
    }

    /** The number of microseconds since the last second */
    int us() const
    {
        return t.tv_usec;
    }

    std::string toString() const
    {
        time_t tim = t.tv_sec;
        struct tm *local = localtime( &tim );
        char buf[32];
        // From most significant to least significant
        snprintf( buf, 23, "%04d.%02d.%02d_%02d.%02d.%02d.%02d",
                  local->tm_year + 1900,
                  local->tm_mon + 1,
                  local->tm_mday,
                  local->tm_hour,
                  local->tm_min,
                  local->tm_sec,
                  ( int )( t.tv_usec / 10000 ) );
        return std::string( buf );
    }

    /** @name Arithmetic
     *
     * You can add or subtract a number of microseconds to a time
     * to create a nearby time, or subtract to times to get the
     * difference in microseconds.
     */
    //@{
    Time operator+( int usecs ) const;
    Time operator+=( int usecs );
    Time operator-( int usecs ) const
    {
        return ( *this ) + ( -usecs );
    }
    Time operator-=( int usecs )
    {
        return ( *this ) += ( -usecs );
    }
    int operator-( const Time &other ) const;
    //@}

    /** @name Comparison
     *
     * Times can be compared using the standard operators
     */
    //@{
    bool operator<( const Time &other ) const;
    bool operator>( const Time &other ) const;
    bool operator>=( const Time &other ) const;
    bool operator<=( const Time &other ) const;
    bool operator==( const Time &other ) const;
    bool operator!=( const Time &other ) const;
    //@}

    /** @name Casting
     *
     * Time can be cast to a timeval or struct timespec for use in
     * syscalls.
     */
    //@{
    operator timeval();
    operator struct timespec();
    //@}

private:
    timeval t;
};

}

#endif
