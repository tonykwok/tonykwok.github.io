var _base_8h =
[
    [ "Size", "struct_f_cam_1_1_size.html", "struct_f_cam_1_1_size" ],
    [ "Rect", "struct_f_cam_1_1_rect.html", "struct_f_cam_1_1_rect" ],
    [ "fcamPanic", "_base_8h.html#a40d0ad0b0819cfda32058753b650850b", null ],
    [ "ImageFormat", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559", [
      [ "RGB24", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559a845686b10540a83bfbdaa09a674d6dbc", null ],
      [ "RGB16", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559a684e6135676247767378c94b565fe78b", null ],
      [ "UYVY", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559afcbb5c076d298c2328f91227b656f319", null ],
      [ "YUV24", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559a2ce9a7ff61fc69049311d766e631d8a3", null ],
      [ "YUV420p", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559aa948bf993a0b797b45bd2ed5f2c6ba88", null ],
      [ "RAW", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559aaa27d87414c6f232ba3a825862895b2f", null ],
      [ "Y8", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559a14305ef0c12a4980e3499f2aed40ef78", null ],
      [ "U8", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559ad0f0bad865bad666eb1a106d44841d13", null ],
      [ "V8", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559a39064d75c13a1a3f66354d65695f3c09", null ],
      [ "UNKNOWN", "_base_8h.html#a677071e67e8ff9e73ea32ce2e5b59559afbf5dc74476bbc2c67ae43d55e496867", null ]
    ] ],
    [ "BayerPattern", "_base_8h.html#a7f8fb43344ca76719c61ff28719041ec", [
      [ "RGGB", "_base_8h.html#a7f8fb43344ca76719c61ff28719041eca0ee083bee47e796d06319bbda85a3361", null ],
      [ "BGGR", "_base_8h.html#a7f8fb43344ca76719c61ff28719041eca040273db7f4ad9ee0b531deebc94558d", null ],
      [ "GRBG", "_base_8h.html#a7f8fb43344ca76719c61ff28719041ecae59ac541ae30c422321e933105671ac3", null ],
      [ "GBRG", "_base_8h.html#a7f8fb43344ca76719c61ff28719041ecaa80fb311b5c4614b91074ea744caeb4a", null ],
      [ "NotBayer", "_base_8h.html#a7f8fb43344ca76719c61ff28719041ecadb532e06c1824ee1e66b7ee64bafb09a", null ]
    ] ],
    [ "ColorSpace", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60", [
      [ "RGB", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60a57e131798fc5afe901fe2c111a190df5", null ],
      [ "sRGB", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60a30391ba0149a3678a07f8293d081a966", null ],
      [ "YUV", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60a887fa39acf2bf1bee81484e1dbc140ee", null ],
      [ "YpUV", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60ae54b96dc33b097c091e08fd1703c9316", null ],
      [ "RGrGbB", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60ab621b7712ccf4b34216287c849d08ec6", null ],
      [ "DefaultColorspace", "_base_8h.html#acd57b1f895e126a148e9cd525e31cb60a65535fa3814c8b8c7f3e577c94264bef", null ]
    ] ],
    [ "bytesPerPixel", "_base_8h.html#aee1005dd1587f08eccd6af2e955c2dde", null ],
    [ "panic", "_base_8h.html#ac5af1159cc05b265767478de23febd1c", null ]
];