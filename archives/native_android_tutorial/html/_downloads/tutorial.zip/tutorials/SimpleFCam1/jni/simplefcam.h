//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------


#ifndef SIMPLEFCAM_H_
#define SIMPLEFCAM_H_

#include <jni.h>
#include <sstream>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <pthread.h>
#include "FCam/Tegra.h"

class SimpleFCam
{
public:
    SimpleFCam( JNIEnv * env, jobject thiz, jobject jAssetManager );
    ~SimpleFCam();

    // Set the output directory
    void setOutputDirectory( const char * aOutputDir );

    // creates the worker thread
    void launchWorkerThread();

    // worker thread entry point
    void run();

protected:

    // A convenience class to flush the log using str operators <<.
    class LogFlusher
    {
    public:
        LogFlusher( SimpleFCam * parent ) :
            mParent( parent )
        {};

        std::stringstream & operator()() const
        {
            mParent->flushLogStream();
            return mParent->logStream();
        }

    private:

        SimpleFCam * mParent;
    };

    static void * workerFunc( void * arg );

    // Returns the stream we are using for logging
    std::stringstream & logStream();

    LogFlusher flush();

    // Flush the log
    void flushLogStream();

    // Return true if there is an FCam Error Event in the event queue.
    bool errorCheck();

    // Save the image to the output path and notify media scanner.
    void saveJPEG( const std::string & filename , FCam::Tegra::Frame & aFrame );

    // Attach thread to Java VM  and get the thread JNIEnv.
    void attachThread();

    // Detach thread from Java VM.
    void detachThread();

    // Calls the Java Activity to print the text
    void printToConsole( const std::string & text );

    // Calls the Java Activity to trigger a media scanner update
    // given the image file name. This will make the image
    // show up in Gallery.
    void notifyMediaScanner( const std::string & path );

    // Calls the Java Activity to notify the thread finished.
    void notifyThreadCompletion();


    // Process Java VM
    JavaVM * mJavaVm;

    // Worker thread JNI Env.
    JNIEnv * mJniEnv;


    jobject mInstance;
    jmethodID mPrintToConsoleMethod;
    jmethodID mNotifyMediaScannerMethod;
    jmethodID mNotifyThreadCompletionMethod;

    jobject  mAssetManagerRef;
    AAssetManager * mNativeAssetManager;

    std::string mOutputDirectory;
    std::stringstream mLogBuffer;

    // Handle to the worker thread
    pthread_t mWorkerThread;

    // Auxiliary function to flush the log using <<.
    friend
    std::stringstream & operator<< ( std::basic_ostream<char> & stream, SimpleFCam::LogFlusher flusher );
};


#endif /* SIMPLEFCAM_H_ */
