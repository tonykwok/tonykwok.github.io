//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef RECT_SHADER_H_
#define RECT_SHADER_H_

#include <GLES2/gl2.h>

class RectShader
{
public:

    enum ImageRowStorage
    {
        // First byte in memory is top row
        STORAGE_TOP_FIRST    = 1,

        // First byte in memory is bottom row
        STORAGE_BOTTOM_FIRST = 2
    };

    enum ImageAspectRatio
    {
        ASPECT_RATIO_KEEP       = 1,
        ASPECT_RATIO_STRETCH    = 2
    };

    /*
     * Load, compile, and initialize the shader.
     */
    RectShader( const char *shaderName );

    /*
     * Destructor.
     */
    virtual ~RectShader();


    /*
     * Set the attributes of the shader.
     */
    virtual void bind( const GLfloat vertices[8], const GLfloat uvs[8] );

    /*
     * Set the viewport aspect ratio
     */
    virtual void setViewportAspectRatio( float width, float height );

    /*
     * To be called when the image size changes. Set image size, which
     * row is zero, and if we want to keep the aspect ratio or fit the image
     */
    virtual void setImageSize( float width, float height,
                               ImageRowStorage zeroRow = STORAGE_TOP_FIRST,
                               ImageAspectRatio aspect = ASPECT_RATIO_STRETCH );

    /*
     * Returns the origin of the rectangle in viewport coordinates
     */
    void getOrigUniform( GLfloat origin[2] ) const;

    /*
     * Returns the dimensions of the rectangle in viewport coordinates
     */
    void getDimUniform( GLfloat dim[2] ) const;


protected:
    /* Functions */

    /*
     * Computes the viewport region the current image will take.
     */
    void updateClipRegion();

    /* Variables */
    GLint mProgram;   // The shader
    GLint mPosAttrib; // Attribute for the surface corners in screen coordinates
    GLint mUvAttrib;  // Attribute for the surface corners in GL coordinates

    GLint mDUniform;        // uD uniform location
    GLint mViewOrigUniform; // uViewOrig uniform location
    GLint mViewDimUniform;  // uViewDim uniform location

    GLfloat mViewOrig[2];   // Current clip coordinates rectangle origin
    GLfloat mViewDim[2];    // Current clip coordinates rectangle dimension
    GLfloat mTexelDelta[2]; // Current texel delta value

    float mRectAspectRatio;     // The rectangle aspect ratio w / h
    float mViewportAspectRatio; // The viewport aspect ratio w / h

    ImageRowStorage     mZeroRowPos;     // Location of zero row (top or bottom)
    ImageAspectRatio    mAspectBehavior; // Keep or stretch aspect ratio.
};

#endif /* RECT_SHADER_H_ */
