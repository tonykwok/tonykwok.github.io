//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include <jni.h>
#include <cmath>
#include <memory>
#include "simplefcam.h"

#include <FCam/Tegra.h>

// This is the main function to run FCam code.
// It will execute on its own thread.
void SimpleFCam::run()
{
    FCam::Tegra::Sensor sensor;
    FCam::Tegra::Shot meterShot;
    FCam::Tegra::Shot captureShot;

    // Setup a half-sized capture for the streaming shot.
    // to get 30fps.
    const int width  = sensor.maxImageSize().width / 2;
    const int height = sensor.maxImageSize().height / 2;

    // Set the initial shot parameters.
    meterShot.exposure = 16666;
    meterShot.gain = 1.0f;
    meterShot.image = FCam::Image( width, height, FCam::YUV420p );

    // Enable the histogram unit
    meterShot.histogram.enabled = true;
    meterShot.histogram.region = FCam::Rect( 0, 0, width, height );

    // We will stream until the exposure stabilizes
    int count = 0;          // # of frames streamed
    int stableCount = 0;    // # of consecutive frames with stable exposure
    float exposure;         // total exposure for the current frame (exposure time * gain)
    float lastExposure = 0; // total exposure for the previous frame

    FCam::Tegra::Frame frame;

    do
    {
        // Ask the sensor to stream with the given parameters
        sensor.stream( meterShot );

        // Retrieve a frame
        frame = sensor.getFrame();
        logStream() << "Frame " << count << " exposure: " << frame.exposure()
                    << " gain: " << frame.gain() << " - ";

        // Calculate the total exposure used (including gain)
        exposure = frame.exposure() * frame.gain();

        // Increment stableCount if the exposure is within 5% of the
        // previous one
        if( std::fabs( exposure - lastExposure ) < 0.05f * lastExposure )
        {
            stableCount++;
        }
        else
        {
            stableCount = 0;
        }

        // Terminate when stable for 5 frames
        if( stableCount >= 5 ) { break; }

        // Update lastExposure
        lastExposure = exposure;

        // Call the autoexposure algorithm. It will update stream1
        // using this frame's histogram.
        autoExpose( &meterShot, frame );

        // Call the auto white-balance algorithm. It will similarly
        // update the white balance using the histogram.
        autoWhiteBalance( &meterShot, frame );

        logStream() << "New exposure: " << meterShot.exposure << " gain: " << meterShot.gain << std::endl;
        logStream() << flush();

        ++count;
    }
    while( true );

    // Now let's capture a full resolution shot
    // Copy the meter shot but assign a full resolution image.
    captureShot = meterShot;
    captureShot.image = FCam::Image( sensor.maxImageSize(), FCam::YUV420p );

    sensor.stopStreaming();
    sensor.capture( captureShot );

    // We might still not have retrieved all the
    // metering shots - call getFrame() until
    // we get the captureShot;
    while( sensor.shotsPending() > 0 && frame.shot().id != captureShot.id )
    {
        frame = sensor.getFrame();
    }

    sensor.stop();

    logStream() << "Full-sized frame received, saving to file" << std::endl << flush();

    // Write out the fill size picture
    saveJPEG( "SimpleFCam3.jpg", frame );
}

SimpleFCam::SimpleFCam( JNIEnv *env, jobject thiz, jobject jAssetManager )
    : mJavaVm( NULL ), mJniEnv( NULL ),
      mNativeAssetManager( NULL ),
      mAssetManagerRef( NULL )
{
    // Grab a reference to the Java VM.
    env->GetJavaVM( &mJavaVm );

    // Access the object class
    jclass clazz = env->GetObjectClass( thiz );

    // Create a persistent reference to the object instance
    mInstance = env->NewGlobalRef( thiz );

    if( jAssetManager != NULL )
    {
        mAssetManagerRef = env->NewGlobalRef( jAssetManager );
        mNativeAssetManager = AAssetManager_fromJava( env, jAssetManager );
    }

    // Get the method IDs for the functions we will be calling in Java
    mPrintToConsoleMethod = env->GetMethodID( clazz, "printToConsole", "(Ljava/lang/String;)V" );
    mNotifyMediaScannerMethod = env->GetMethodID( clazz, "notifyMediaScanner", "(Ljava/lang/String;)V" );
    mNotifyThreadCompletionMethod = env->GetMethodID( clazz, "notifyThreadCompletion", "()V" );
}

SimpleFCam::~SimpleFCam()
{
}

SimpleFCam::LogFlusher SimpleFCam::flush()
{
    return SimpleFCam::LogFlusher( this );
}

bool SimpleFCam::errorCheck()
{
    bool error = false;

    FCam::Event e;
    while( FCam::getNextEvent( &e, FCam::Event::Error ) )
    {
        logStream() << "FCam error: " << e.description << std::endl << flush();
        error = true;
    }

    return error;
}

std::stringstream &SimpleFCam::logStream()
{
    return mLogBuffer;
}


void SimpleFCam::flushLogStream()
{
    // Send the log to the Java activity.
    printToConsole( mLogBuffer.str() );

    // Clear the buffer.
    mLogBuffer.str( "" );
}

void SimpleFCam::launchWorkerThread()
{
    pthread_create( &mWorkerThread, NULL, &workerFunc, ( void * ) this );
}

void SimpleFCam::setOutputDirectory( const char *aOutputDir )
{
    mOutputDirectory = std::string( aOutputDir );
}

void SimpleFCam::saveJPEG( const std::string &filename, FCam::Tegra::Frame &aFrame )
{
    std::stringstream filePathBuilder;
    filePathBuilder << mOutputDirectory << "/" << filename;

    std::string filePath = filePathBuilder.str();

    // Save the image to disk
    FCam::saveJPEG( aFrame, filePath.c_str(), 95 );

    // Ask media scanner to index the file
    notifyMediaScanner( filePath );
}

void SimpleFCam::attachThread()
{
    mJavaVm->AttachCurrentThread( &mJniEnv, NULL );
}

void SimpleFCam::detachThread()
{
    mJniEnv->DeleteGlobalRef( mInstance );

    if( mAssetManagerRef != NULL )
    {
        mJniEnv->DeleteGlobalRef( mAssetManagerRef );
        mNativeAssetManager = NULL;
    }

    mJavaVm->DetachCurrentThread();
}

void SimpleFCam::printToConsole( const std::string &text )
{
    jstring jtext = mJniEnv->NewStringUTF( text.c_str() );
    mJniEnv->CallVoidMethod( mInstance, mPrintToConsoleMethod, jtext );
    mJniEnv->DeleteLocalRef( jtext );
}

void SimpleFCam::notifyMediaScanner( const std::string &path )
{
    jstring jpath = mJniEnv->NewStringUTF( path.c_str() );
    mJniEnv->CallVoidMethod( mInstance, mNotifyMediaScannerMethod, jpath );
    mJniEnv->DeleteLocalRef( jpath );
}

void SimpleFCam::notifyThreadCompletion()
{
    mJniEnv->CallVoidMethod( mInstance, mNotifyThreadCompletionMethod );
}

void *SimpleFCam::workerFunc( void *arg )
{
    std::unique_ptr<SimpleFCam> instance( ( SimpleFCam * ) arg );

    // Attach this thread to the Java VM
    instance->attachThread();

    // Run the FCam application code
    instance->run();

    // Notify the Java layer we have finished running the app
    instance->notifyThreadCompletion();

    // This thread is going to exit - detach it from the JavaVM
    instance->detachThread();

    return NULL;
}

std::stringstream &operator<< ( std::basic_ostream<char> &stream, SimpleFCam::LogFlusher flusher )
{
    return flusher();
}
