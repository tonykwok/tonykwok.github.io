/* Copyright (c) 1995-2010, Stanford University.
 * Copyright (c) 2011-2012, NVIDIA CORPORATION.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FCAM_PLATFORM
#define FCAM_PLATFORM

#include <string>
#include "FCam/Base.h"

/** \file
 * The abstract base class for static platform data.
 */

namespace FCam
{

/** The abstract base class for static platform data. */
class Platform
{
public:
    /** Get the bayer pattern of this sensor when in raw mode. */
    virtual BayerPattern bayerPattern() const = 0;

    /** Produce a 3x4 affine matrix that maps from sensor RGB to
     * linear-luminance sRGB at the given white balance. Given in
     * row-major order. */
    virtual void rawToRGBColorMatrix( int kelvin, float *matrix ) const = 0;

    /** The camera's manufacturer. (e.g. Canon). */
    virtual const std::string &manufacturer() const = 0;

    /** The camera's model. Should also include manufacturer (e.g. Canon 400D). */
    virtual const std::string &model() const = 0;

    /** The smallest value to expect when in raw mode. */
    virtual unsigned short minRawValue() const = 0;

    /** The largest value to expect when in raw mode. */
    virtual unsigned short maxRawValue() const = 0;

    virtual ~Platform() {}
};
}

#endif
