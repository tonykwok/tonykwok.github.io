//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include <memory>
#include <malloc.h>
#include <pthread.h>
#include "Common.h"

#define DEFAULT_THREAD_COUNT 2

void *_aligned_malloc( size_t size, size_t alignSize )
{
    void *ptr = malloc( size + alignSize + sizeof(void *) );
    if( ptr == 0 )
    {
        return 0;
    }

    void **aptr = (void **) ( ( (size_t) ptr + sizeof(void *) + ( alignSize - 1 ) ) & ~( alignSize - 1 ) );
    aptr[-1] = ptr;
    return aptr;
}

void _aligned_free( void *ptr )
{
    if( ptr != 0 )
    {
        free( ( (void **) ptr )[-1] );
    }
}

void RunThreads( THREAD_PROC proc, void *params, int taskCount, int threadNum )
{
    // if number of threads is less or equal zero, set it to default value
    if( threadNum <= 0 )
    {
        // run of default number of threads
        threadNum = DEFAULT_THREAD_COUNT;
    }

    std::unique_ptr<ThreadData<void> []> tdata( new ThreadData<void> [threadNum] );
    std::unique_ptr<pthread_t[]> tid( new pthread_t[threadNum] );

    // current thread task start index
    int taskStartIndex = 0;
    // the number of tasks per thread (rounded up)
    int threadTaskRange = ( taskCount + threadNum - 1 ) / threadNum;

    for( int i = 0; i < threadNum; i++ )
    {
        // initialize data for each thread
        tdata[i].threadIndex = i;
        tdata[i].taskStartIndex = taskStartIndex;
        tdata[i].taskEndIndex = taskStartIndex + threadTaskRange;
        tdata[i].params = params;

        // last thread end range might go out of borders if height is not a multiple of threadNum
        if( tdata[i].taskEndIndex > taskCount )
        {
            tdata[i].taskEndIndex = taskCount;
        }

        taskStartIndex += threadTaskRange;

        // spawn a thread
        pthread_create( &tid[i], 0, proc, &tdata[i] );
    }

    // wait for threads completion
    for( int i = 0; i < threadNum; i++ )
    {
        pthread_join( tid[i], 0 );
    }
}
