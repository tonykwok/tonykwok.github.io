/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <FCam/AutoFocus.h>
#include <FCam/Tegra.h>
#include <FCam/Tegra/AutoFocus.h>

/** \file */

/* Macros for Android logging
 * Use: adb logcat FCAM_EXAMPLE5:*  *:S
 * to see all messages from this app
 */
#if !defined(LOG_TAG)
#define LOG_TAG "FCAM_EXAMPLE5"
#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG  , LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO   , LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN   , LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR  , LOG_TAG, __VA_ARGS__)
#endif
#include <android/log.h>


// Print text in the app's textview
void appPrint( char * str );

static void fcam_print( const char * fmt, ... )
{
    char buf[512];

    va_list arglist;
    va_start( arglist, fmt );
    vsnprintf( buf, 512, fmt, arglist );
    va_end( arglist );

    // Print to the app textview and also send to android log
    LOGD( "%s", buf );
    appPrint( buf );
}

/***********************************************************/
/* Autofocus                                               */
/*                                                         */
/* This example shows how to request streams and deal with */
/* the incoming frames, and also uses the provided         */
/* autofocus routine.                                      */
/***********************************************************/
int main( int argc, char ** argv )
{

    // Devices
    FCam::Tegra::Sensor sensor;
    FCam::Tegra::Lens lens;
    sensor.attach( &lens ); // Attach the lens to the sensor

    // Autofocus supplied by FCam API
    FCam::Tegra::AutoFocus autoFocus( &lens );

    // Shot
    FCam::Tegra::Shot stream1;
    // Set the shot parameters
    stream1.exposure = 50000;
    stream1.gain = 1.0f;

    // Request a resolution, and allocate storage
    stream1.image = FCam::Image( 640, 480, FCam::YUV420p );

    // Enable the sharpness unit
    stream1.sharpness.enabled = true;

    // We will stream until the focus stabilizes
    int count = 0;        // # of frames streamed

    // Ask the autofocus algorithm to start sweeping the lens
    autoFocus.startSweep();

    // Stream until autofocus algorithm completes
    FCam::Frame frame;

    do
    {
        // Stream the updated shot
        sensor.stream( stream1 );

        // Retrieve a frame
        frame = sensor.getFrame();
        assert( frame.shot().id == stream1.id ); // Check the source of the request

        // The lens has tagged each frame with where it was focused
        // during that frame. Let's retrieve it so we can print it out.
        float diopters = frame["lens.focus"];
        fcam_print( "Lens focused at %2.0f cm\n", 100 / diopters );

        // The sensor has attached a sharpness map to each frame.
        // Let's sum up all the values in it so we can print out
        // the total sharpness of this frame.
        int totalSharpness = 0;
        for ( int y = 0; y < frame.sharpness().height(); y++ )
        {
            for ( int x = 0; x < frame.sharpness().width(); x++ )
            {
                totalSharpness += frame.sharpness()( x, y );
            }
        }
        fcam_print( "Total sharpness is %d\n\n", totalSharpness );

        // Call the autofocus algorithm
        // Pass the shot too, it can be updated with
        // a focus stepping action.
        autoFocus.update( frame, &stream1 );

        // Increment frame counter
        count++;
    }
    while ( !autoFocus.idle() );

    fcam_print( "Autofocus chose to focus at %2.0f cm\n\n", 100 / lens.getFocus() );

    // Write out the focused frame
    FCam::saveJPEG( frame, "/data/fcam/example5.jpg" );

    // Order the sensor to stop streaming
    sensor.stopStreaming();
    fcam_print( "Processed %d frames until autofocus completed!\n", count );

    // There may still be shots in the pipeline. Consume them.
    while ( sensor.shotsPending() > 0 ) { frame = sensor.getFrame(); }

    // Check that the pipeline is empty
    assert( sensor.framesPending() == 0 );
    assert( sensor.shotsPending() == 0 );
}
