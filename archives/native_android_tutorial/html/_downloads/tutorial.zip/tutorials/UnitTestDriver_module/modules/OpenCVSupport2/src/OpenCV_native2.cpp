//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#include "OpenCVSupport2/OpenCV_native2.h"

int COpenCVSample2::FeatureDetecTest()
{
    // Specifying a path for a testing image
    std::stringstream path;
    path << "/storage/sdcard0/DCIM/lena.jpg";

    cv::Mat img = cv::imread( path.str() );

    cv::Mat g_img( img.rows, img.cols, CV_8UC1 );

    // convert BGR to Gray
    cv::cvtColor( img, g_img, CV_BGR2GRAY );

    // detect FAST features
    std::vector < cv::KeyPoint > v;
    cv::FastFeatureDetector detector( 50 );
    detector.detect( g_img, v );

    return v.size();

}

cv::Mat COpenCVSample2::runLoadCVImg()
{
    // Specifying a path for a testing image
    std::stringstream path;
    path << "/storage/sdcard0/DCIM/lena.jpg";

    cv::Mat img = cv::imread( path.str() );

    if( img.rows == 0 )
    {
        // If the path was wrong, display error message as a form of cv::Mat
        return errorImage( "Wrong image path!" );
    }

    cv::Mat temp( img );
    img = runOpenCVFeatureDetector( temp );

    // Since OpenCV uses BGR, we have to convert it to RGB for OpenGL side
    cv::Mat rgb_img( img );
    cv::cvtColor( img, rgb_img, CV_BGR2RGB );

    return rgb_img;
}

cv::Mat COpenCVSample2::runOpenCVFeatureDetector( cv::Mat img )
{
    cv::Mat g_img( img.rows, img.cols, CV_8UC1 );

    // convert BGR to Gray
    cv::cvtColor( img, g_img, CV_BGR2GRAY );

    // detect FAST features
    std::vector < cv::KeyPoint > v;
    cv::FastFeatureDetector detector( 50 );
    detector.detect( g_img, v );

    // Draw results
    for( size_t i = 0; i < v.size(); i++ )
    {
        cv::circle( img, cv::Point( v[i].pt.x, v[i].pt.y ), 10, cv::Scalar( 0, 0, 255, 255 ) );
    }

    // Draw texts in opencv
    std::stringstream st1;
    st1 << "Number of features : " << v.size();
    cv::putText( img, st1.str(), cv::Point( 10, 50 ), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar( 0, 255, 0 ) );
    st1.str( std::string() );
    st1 << "This text is drawn from OpenCV";
    cv::putText( img, st1.str(), cv::Point( 10, 80 ), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar( 0, 255, 0 ) );

    return img;
}

cv::Mat COpenCVSample2::errorImage( std::string errmsg )
{
    // Make a black background image
    cv::Mat img = cv::Mat::zeros( 720, 1280, CV_8UC3 );

    // Add message with cv::putText
    std::stringstream sterr;
    sterr << "Loading image failed. Please check out the path";
    cv::putText( img, sterr.str(), cv::Point( img.cols / 2 - 200, img.rows / 2 ), cv::FONT_HERSHEY_PLAIN, 1,
                 cv::Scalar( 0, 255, 0 ) );

    // Since OpenCV uses BGR, we have to convert it to RGB for OpenGL side
    cv::Mat rgb_img( img );
    cv::cvtColor( img, rgb_img, CV_BGR2RGB );

    return rgb_img;
}

