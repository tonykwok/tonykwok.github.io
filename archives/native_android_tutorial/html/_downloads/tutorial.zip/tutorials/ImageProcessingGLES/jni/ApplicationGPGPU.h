//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#ifndef APPLICATIONGPGPU_H_
#define APPLICATIONGPGPU_H_

#include <GLES2/gl2ext.h>
#include <nv_shader/nv_shader.h>
#include <nv_bitfont/nv_bitfont.h>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include "Image.h"
#include "ImagePixelARGB32.h"
#include "BaseMath.h"
#include "Timer.h"
#include "ApplicationGLES.h"

// the size of image diff history buffer
#define MAX_HISTORY_SIZE       200

// stopping condition for the accumulation
// defines the texture size which is small enough
// for system memory download
#define MAX_TEXTURE_SIZE       128

// the timing interval length in msec
#define PERF_SAMPLING_INTERVAL 1000

class ApplicationGPGPU: public ApplicationGLES
{
public:
    // application state
    enum State
    {
        STATE_UNDEFINED, STATE_INIT, STATE_PROCESS, STATE_EXIT,
    };

    ApplicationGPGPU( struct android_app *app, NvEGLUtil *egl )
            : ApplicationGLES( app, egl )
    {
        mCurrentState = STATE_INIT;

        // initialize GLES handlers
        mWarpedDiffProgram = 0;
        mAccumProgram = 0;
        mPlainTextureProgram = 0;
        mPlainColorProgram = 0;

        mSourceImageTexture = 0;
        mImageDiffTexture = 0;
        mTempTexture1 = 0;
        mTempTexture2 = 0;

        mFBO = 0;
        mRBO = 0;
    }

    ~ApplicationGPGPU( void )
    {
        // clean-up fragment program
        if( mWarpedDiffProgram != 0 )
        {
            glDeleteProgram( mWarpedDiffProgram );
        }

        if( mAccumProgram != 0 )
        {
            glDeleteProgram( mAccumProgram );
        }

        if( mPlainColorProgram != 0 )
        {
            glDeleteProgram( mPlainColorProgram );
        }

        if( mPlainTextureProgram != 0 )
        {
            glDeleteProgram( mPlainTextureProgram );
        }

        // clean-up textures
        if( mSourceImageTexture != 0 )
        {
            glDeleteTextures( 1, &mSourceImageTexture );
        }

        if( mImageDiffTexture != 0 )
        {
            glDeleteTextures( 1, &mImageDiffTexture );
        }

        if( mTempTexture1 != 0 )
        {
            glDeleteTextures( 1, &mTempTexture1 );
        }

        if( mTempTexture2 != 0 )
        {
            glDeleteTextures( 1, &mTempTexture2 );
        }

        if( mRBO != 0 )
        {
            glDeleteRenderbuffers( 1, &mRBO );
        }

        if( mFBO != 0 )
        {
            glDeleteFramebuffers( 1, &mFBO );
        }
    }

    bool runStateMachine( void )
    {
        // check if renderer is ready
        if( !mEgl->isReadyToRender( true ) )
        {
            return false;
        }

        // resize gl viewport size
        if( mEgl->checkWindowResized() )
        {
            LOG( "window resize!" );
            glViewport( 0, 0, mEgl->getWidth(), mEgl->getHeight() );
        }

        State nextState = STATE_UNDEFINED;
        switch( mCurrentState )
        {
        case STATE_INIT:
            // load and set up OpenGL resources
            if (!loadResources()) {
                // failed to initialize -> quit
                return true;
            }

            // start capturing samples for performance evaluation
            mTimingIntervalStart = mGlobalTimer.get();
            mLastComputeTime = 0;

            nextState = STATE_PROCESS;
            break;

        case STATE_PROCESS:
            // application idle state -> wait for the back button press to quit
            if( mIsExitRequested )
            {
                nextState = STATE_EXIT;
            }
            else
            {
                double time = mGlobalTimer.get();
                Math::Matrix4x4f transformMatrix;
                transformMatrix.setRotate(
                        Math::Quat( Math::Vec3f( 0.0f, 0.0f, 1.0f ), Math::Sinf( time * 0.001f ) * 10.0f ) );

                // flush the GL pipeline before measuring the timing
                glFinish();
                mGlobalTimer.tic();
                // get scalar image difference
                float diff = getImageSimilarityMeasure( transformMatrix );
                // store the time it took to execute the function
                glFinish();
                // flush the GL pipeline before measuring the timing
                mTimingSamples.push_back( mGlobalTimer.toc() );

                if( time - mTimingIntervalStart > PERF_SAMPLING_INTERVAL )
                {
                    // output to log the timing stats
                    std::sort( mTimingSamples.begin(), mTimingSamples.end() );

                    mLastComputeTime = mTimingSamples[mTimingSamples.size() / 2];
                    mTimingIntervalStart = time;
                    mTimingSamples.clear();
//                    LOG("%.3f", mLastComputeTime);
                }

                // store the difference in a history buffer for visualization
                mImageDifferenceHistory.push_back( diff );
                if( mImageDifferenceHistory.size() > MAX_HISTORY_SIZE )
                {
                    mImageDifferenceHistory.erase( mImageDifferenceHistory.begin() );
                }

                glClearColor( 0.5f, 0.5f, 0.5f, 1.0f );
                glClear (GL_COLOR_BUFFER_BIT);
                // render the difference image
                drawTexturedQuad( mImageDiffTexture, 1.0f );
                // render the difference history chart
                drawImageDifferenceHistoryChart();

                // render the rendering bitfont text overlaid here
                NVBFTextRenderPrep();

                char stringBuffer[128];
                sprintf( stringBuffer, "GPU render time: %.02fms\nImage difference: %.01f", mLastComputeTime,
                         mImageDifferenceHistory.back() );
                NVBFTextSetString( mClockText, stringBuffer );

                NVBFTextRender( mClockText );

                // done rendering overlaid text
                NVBFTextRenderDone();

                // make sure blending is disabled
                glDisable (GL_BLEND);

                mEgl->swap();
            }
            break;

        case STATE_EXIT:
            // application exit state
            break;
        }

        if( nextState != STATE_UNDEFINED )
        {
            // do state transition
            mCurrentState = nextState;
        }

        return mCurrentState == STATE_EXIT;
    }

    void drawImageDifferenceHistoryChart( void )
    {
        int bsize = mImageDifferenceHistory.size();
        if( bsize == 0 )
        {
            return;
        }

        // generate geometry
        float *vertData = new float[2 * 6 * bsize];
        float const stepX = 1.0f / mEgl->getWidth();
        float const stepY = 1.0f / mEgl->getHeight();

        float sx = 0.0f;
        int index = 0;
        for( int i = 0; i < bsize; i++ )
        {
            float value = mImageDifferenceHistory[i] * stepY;
            vertData[index + 0] = sx;
            vertData[index + 1] = 0;
            vertData[index + 2] = sx + stepX;
            vertData[index + 3] = 0;
            vertData[index + 4] = sx + stepX;
            vertData[index + 5] = value;

            vertData[index + 6] = sx + stepX;
            vertData[index + 7] = value;
            vertData[index + 8] = sx;
            vertData[index + 9] = value;
            vertData[index + 10] = sx;
            vertData[index + 11] = 0;

            sx += stepX;
            index += 2 * 6;
        }

        glUseProgram( mPlainColorProgram );

        // setup uniforms
        glUniform4f( glGetUniformLocation( mPlainColorProgram, "uColor" ), 0.3f, 0.3f, 0.3f, 1.0f );

        Math::Matrix4x4f mat;
        mat.setScale( 2.0f );
        mat.applyTranslate( -1.0f );
        glUniformMatrix4fv( glGetUniformLocation( mPlainColorProgram, "uTransformMatrix" ), 1, false, mat.mData );

        int attribPosCoord = glGetAttribLocation( mPlainColorProgram, "aPosition" );
        glVertexAttribPointer( attribPosCoord, 2, GL_FLOAT, GL_FALSE, 0, vertData );
        glEnableVertexAttribArray( attribPosCoord );
        glDrawArrays( GL_TRIANGLES, 0, 6 * bsize );
        glDisableVertexAttribArray( attribPosCoord );

        delete[] vertData;
    }

    float getWindowAspectRatio( void )
    {
        return (float) mEgl->getHeight() / mEgl->getWidth();
    }

    void drawTexturedQuad( GLuint texId, Math::Vec2f const &scale )
    {
        glUseProgram( mPlainTextureProgram );

        // setup uniforms
        glActiveTexture (GL_TEXTURE0);
        glBindTexture( GL_TEXTURE_2D, texId );

        glUniform1i( glGetUniformLocation( mPlainTextureProgram, "uBaseTex" ), 0 );

        Math::Matrix4x4f mat;
        mat.setTranslate( -0.5f );
        mat.applyScale( Math::Vec2f( getWindowAspectRatio() * scale.x * 2.0f, scale.y * -2.0f ) );

        glUniformMatrix4fv( glGetUniformLocation( mPlainTextureProgram, "uTransformMatrix" ), 1, false, mat.mData );

        // render
        drawQuad( mPlainTextureProgram );
    }

private:
    // current application state
    State mCurrentState;

    // global timer instance
    Timer mGlobalTimer;
    double mTimingIntervalStart;
    float mLastComputeTime;
    std::vector<float> mTimingSamples;

    void *mClockText;

    // frame buffer object handler
    GLuint mFBO;
    // render buffer object handler
    GLuint mRBO;

    // fragment program handlers
    GLuint mWarpedDiffProgram;
    GLuint mAccumProgram;
    GLuint mPlainTextureProgram;
    GLuint mPlainColorProgram;

    // texture handlers
    GLuint mSourceImageTexture; // source image
    GLuint mImageDiffTexture; // difference image (between source and transformed images)
    GLuint mTempTexture1, mTempTexture2; // temporary textures used in the accumulation step

    // source image dimensions
    int mSourceImageWidth;
    int mSourceImageHeight;

    // vector storing accumulated difference history (for visualization)
    std::vector<float> mImageDifferenceHistory;
};

#endif /* APPLICATIONGPGPU_H_ */
