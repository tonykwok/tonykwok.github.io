//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//---------------------------------------------------------------------------------- 


package com.nvidia.unittest;

import android.app.Activity;
import android.content.res.AssetManager;
import android.media.MediaScannerConnection;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class UnitTestDriver extends Activity {

    /*
     * UI elements can only be updated by the thread that created them.
     * Callbacks from native code use handlers to notify the proper thread.
     */
    private Handler mNotificationHandler;

    private final static int MSG_COMPLETED = 0x1;
    private final static int MSG_LOG = 0x2;

    private final static int LOG_ASSERT     = Log.ASSERT;
    private final static int LOG_DEBUG      = Log.DEBUG;
    private final static int LOG_ERROR      = Log.ERROR;
    private final static int LOG_INFO       = Log.INFO;
    private final static int LOG_VERBOSE    = Log.VERBOSE;

    private TextView mConsoleText;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * Create the handler that allows us to process messages from a
         * different thread.
         */
        mNotificationHandler = new Handler() {

            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {

                case MSG_LOG:
                    mConsoleText.setText(mConsoleText.getText()
                            + msg.getData().getString("Text"));
                    break;
                    
                case MSG_COMPLETED:                 
                    // Print a message saying we are done and finish onClick.
                    mConsoleText.setText(mConsoleText.getText() + "Click the text to close the app\n\n\n\n\n\n\n");
                    mConsoleText.setOnClickListener(new OnClickListener() {
                        public void onClick(View v) {
                            finish();
                        }
                    });

                    break;
                default:
                    break;
                }

            }
        };

        /*
         * Create a TexconsoleTextiew and set its content. the text is retrieved
         * by calling a native function.
         */
        mConsoleText = new TextView(this);
        setContentView(mConsoleText);

        // invoke the native code - which will launch
        // its own thread.
        launchNativeThread(
                Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES).getPath(), getAssets());
    }

    // append new text to the consoleText TextView
    public void log(String text) {
        Bundle bundle = new Bundle();
        bundle.putString("Text", text);

        Message msg = new Message();
        msg.what = MSG_LOG;
        msg.setData(bundle);
        mNotificationHandler.sendMessage(msg);
    }

    /*
     * notifyThreadCompletion is called when the native FCam thread has finished
     * executing.
     */
    public void notifyThreadCompletion() {
        mNotificationHandler.sendEmptyMessage(MSG_COMPLETED);
    }

    public void notifyMediaScanner(String path) {
        MediaScannerConnection.scanFile(getApplicationContext(),
                new String[] { path }, null, null);
    }

    private native void launchNativeThread(String outputPath,
            AssetManager assetManager);

    // All FCam programs must load the fcamtegrahal library.
    static {
        System.loadLibrary("unittestdriver");
    }

}
