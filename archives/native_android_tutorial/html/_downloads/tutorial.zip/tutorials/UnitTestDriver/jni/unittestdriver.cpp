//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include <jni.h>
#include <memory>
#include "unittestdriver.h"

// This is the main function to run FCam code.
// It will execute on its own thread.
void UnitTestDriver::run()
{
    char * argv[] =
    { ( char * ) "UnitTestDriver" };
    int argc = sizeof( argv ) / sizeof( const char * );

    logStream() << "*** Starting Unit Test ***" << std::endl << flush();

    // Initialize the testing framework
    ::testing::InitGoogleTest( &argc, argv );

    // Add this class as an event listener
    ::testing::UnitTest::GetInstance()->listeners().Append( this );

    // Run all the tests.
    mTestResult = RUN_ALL_TESTS();
}

UnitTestDriver::UnitTestDriver( JNIEnv * env, jobject thiz, jobject jAssetManager )
    : mJavaVm( NULL ), mJniEnv( NULL ), mNativeAssetManager( NULL ), mAssetManagerRef( NULL )
{
    // Grab a reference to the Java VM.
    env->GetJavaVM( &mJavaVm );

    // Access the object class
    jclass clazz = env->GetObjectClass( thiz );

    // Create a persistent reference to the object instance
    mInstance = env->NewGlobalRef( thiz );

    if( jAssetManager != NULL )
    {
        mAssetManagerRef = env->NewGlobalRef( jAssetManager );
        mNativeAssetManager = AAssetManager_fromJava( env, jAssetManager );
    }

    // Get the method IDs for the functions we will be calling in Java
    mPrintToConsoleMethod = env->GetMethodID( clazz, "log", "(Ljava/lang/String;)V" );
    mNotifyThreadCompletionMethod = env->GetMethodID( clazz, "notifyThreadCompletion", "()V" );
}

UnitTestDriver::~UnitTestDriver()
{
}

UnitTestDriver::LogFlusher UnitTestDriver::flush()
{
    return UnitTestDriver::LogFlusher( this );
}

std::stringstream & UnitTestDriver::logStream()
{
    return mLogBuffer;
}

void UnitTestDriver::flushLogStream()
{
    // Send the log to the Java activity.
    printToConsole( mLogBuffer.str() );

    // Clear the buffer.
    mLogBuffer.str( "" );
}

void UnitTestDriver::launchWorkerThread()
{
    pthread_create( &mWorkerThread, NULL, &workerFunc, ( void * ) this );
}

void UnitTestDriver::setOutputDirectory( const char * aOutputDir )
{
    mOutputDirectory = std::string( aOutputDir );
}

void UnitTestDriver::attachThread()
{
    mJavaVm->AttachCurrentThread( &mJniEnv, NULL );
}

void UnitTestDriver::detachThread()
{
    mJniEnv->DeleteGlobalRef( mInstance );

    if( mAssetManagerRef != NULL )
    {
        mJniEnv->DeleteGlobalRef( mAssetManagerRef );
        mNativeAssetManager = NULL;
    }

    mJavaVm->DetachCurrentThread();
}

void UnitTestDriver::printToConsole( const std::string & text )
{
    jstring jtext = mJniEnv->NewStringUTF( text.c_str() );
    mJniEnv->CallVoidMethod( mInstance, mPrintToConsoleMethod, jtext );
    mJniEnv->DeleteLocalRef( jtext );
}

void UnitTestDriver::notifyThreadCompletion()
{
    mJniEnv->CallVoidMethod( mInstance, mNotifyThreadCompletionMethod );
}

void * UnitTestDriver::workerFunc( void * arg )
{
    std::unique_ptr<UnitTestDriver> instance( ( UnitTestDriver * ) arg );

    // Attach this thread to the Java VM
    instance->attachThread();

    // Run the FCam application code
    instance->run();

    // Notify the Java layer we have finished running the app
    instance->notifyThreadCompletion();

    // This thread is going to exit - detach it from the JavaVM
    instance->detachThread();

    return NULL;
}

void UnitTestDriver::OnTestStart( const ::testing::TestInfo & test_info )
{
    logStream() << "*** Test " << test_info.test_case_name() << "." << test_info.name() << " starting" << std::endl
                << flush();
}

// Called after a failed assertion or a SUCCEED() invocation.
void UnitTestDriver::OnTestPartResult( const ::testing::TestPartResult & test_part_result )
{
    logStream() << ( test_part_result.failed() ? "*** Failure" : "Success" ) << " in " << test_part_result.file_name()
                << "." << test_part_result.line_number() << std::endl << test_part_result.summary() << std::endl
                << flush();
}

// Called after a test ends.
void UnitTestDriver::OnTestEnd( const ::testing::TestInfo & test_info )
{
    logStream() << "*** Test " << test_info.test_case_name() << "." << test_info.name() << " ended."
                << ( test_info.result()->Failed() ? "FAILED" : "SUCCESS" ) << std::endl << flush();
}

std::stringstream & operator<<( std::basic_ostream<char> & stream, UnitTestDriver::LogFlusher flusher )
{
    return flusher();
}

