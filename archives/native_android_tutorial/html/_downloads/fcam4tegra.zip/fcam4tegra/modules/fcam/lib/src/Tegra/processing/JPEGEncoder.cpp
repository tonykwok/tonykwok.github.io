/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "FCam/Tegra/processing/JPEGEncoder.h"
#include "FCam/processing/JPEG.h"
#include "../../Debug.h"

namespace FCam
{
namespace Tegra
{

JPEGEncoder::JPEGEncoder() :
    pProduct( NULL ),
    pEncoderHAL( NULL )
{
    pProduct = Hal::System::openProduct();

    if( pProduct.get() != NULL )
    {
        pEncoderHAL = pProduct->getJPEGEncoderHal();
    }
    else
    {
        LOGE( "Failed Hal::System::openProduct() - verify hal versions\n" );
    }

    profile.width = 0;
    profile.height = 0;
    profile.quality = 0;
    profile.thumb_enable = false;
    profile.thumb_width = 0;
    profile.thumb_height = 0;
    profile.thumb_quality = 0;

    pEncoderHAL->open();
}

JPEGEncoder::~JPEGEncoder()
{
    pEncoderHAL->close();
}


bool JPEGEncoder::save( Image img, std::string filename, unsigned int quality )
{
    bool success = true;

    if( img.type() != FCam::YUV420p )
    {
        success = false;
    }

    if( success && (
            img.width() != profile.width ||
            img.height() != profile.height ||
            quality != profile.quality ) )
    {
        profile.width = img.width();
        profile.height = img.height();
        profile.quality = quality;
        dprintf( DBG_MINOR, "Setting JPEG encoder profile to %d %d %d\n",
                 profile.width, profile.height, profile.quality );
        success = pEncoderHAL->configureProfile( profile );
    }

    Hal::IImageEncoder::Frame frame;
    frame.width = img.width();
    frame.height = img.height();
    frame.format = Hal::YUV420p;
    frame.bufferSize = ( frame.width * frame.height ) * 3 / 2;
    frame.pBuffer = img( 0, 0 );
    success = pEncoderHAL->encodeImage( filename.c_str(), frame );

    if( !success )
    {
        dprintf( DBG_MINOR, "JPEGEncoder falling back to sw encoder due to incompatible image type.\n" );
        FCam::saveJPEG( img, filename, quality );
    }

    return true;
}

}
}



