//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include <jni.h>
#include <stdio.h>
#include "simplefcam.h"

#include <FCam/Tegra.h>

// This is the main function to run FCam code.
// It will execute on its own thread.
void SimpleFCam::run()
{
}

SimpleFCam::SimpleFCam( JNIEnv *env, jobject thiz )
    : mJavaVm( NULL ), mJniEnv( NULL )
{
    // Grab a reference to the Java VM.
    env->GetJavaVM( &mJavaVm );

    // Access the object class
    jclass clazz = env->GetObjectClass( thiz );

    // Create a persistent reference to the object instance
    mInstance = env->NewGlobalRef( thiz );

    // Get the method IDs for the functions we will be calling in Java
    mPrintToConsoleMethod = env->GetMethodID( clazz, "printToConsole", "(Ljava/lang/String;)V" );
    mNotifyMediaScannerMethod = env->GetMethodID( clazz, "notifyMediaScanner", "(Ljava/lang/String;)V" );
    mNotifyThreadCompletionMethod = env->GetMethodID( clazz, "notifyThreadCompletion", "()V" );
}

SimpleFCam::~SimpleFCam()
{
}

void SimpleFCam::launchWorkerThread()
{
    pthread_create( &mWorkerThread, NULL, &workerFunc, ( void * ) this );
}

void SimpleFCam::setOutputDirectory( const char *aOutputDir )
{
    snprintf( mOutputDirectory, sizeof( mOutputDirectory ), aOutputDir );
}

void SimpleFCam::saveJPEG( const char *aFileName, FCam::Tegra::Frame &aFrame )
{
    char filePath[1536];
    snprintf( filePath, sizeof( filePath ), "%s/%s", mOutputDirectory, aFileName );

    // Save the image to disk
    FCam::saveJPEG( aFrame, filePath, 95 );

    // Ask media scanner to index the file
    notifyMediaScanner( filePath );
}

void SimpleFCam::attachThread()
{
    mJavaVm->AttachCurrentThread( &mJniEnv, NULL );
}

void SimpleFCam::detachThread()
{
    mJniEnv->DeleteGlobalRef( mInstance );
    mJavaVm->DetachCurrentThread();
}

void SimpleFCam::printToConsole( const char *aText )
{
    jstring text = mJniEnv->NewStringUTF( aText );
    mJniEnv->CallVoidMethod( mInstance, mPrintToConsoleMethod, text );
    mJniEnv->DeleteLocalRef( text );
}

void SimpleFCam::notifyMediaScanner( const char *aFilePath )
{
    jstring jpath = mJniEnv->NewStringUTF( aFilePath );
    mJniEnv->CallVoidMethod( mInstance, mNotifyMediaScannerMethod, jpath );
    mJniEnv->DeleteLocalRef( jpath );
}

void SimpleFCam::notifyThreadCompletion()
{
    mJniEnv->CallVoidMethod( mInstance, mNotifyThreadCompletionMethod );
}

void *SimpleFCam::workerFunc( void *arg )
{
    SimpleFCam *instance = ( SimpleFCam * ) arg;

    // Attach this thread to the Java VM
    instance->attachThread();

    // Run the FCam application code
    instance->run();

    // Notify the Java layer we have finished running the app
    instance->notifyThreadCompletion();

    // This thread is going to exit - detach it from the JavaVM
    instance->detachThread();

    // delete the SimpleFCam instance
    delete instance;

    return NULL;
}
