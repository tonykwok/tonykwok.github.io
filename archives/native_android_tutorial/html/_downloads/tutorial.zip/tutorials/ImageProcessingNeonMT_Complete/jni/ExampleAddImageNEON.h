//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef EXAMPLEADDIMAGENEON_H_
#define EXAMPLEADDIMAGENEON_H_

#include <arm_neon.h>
#include "Common.h"

NO_INLINE
void AddImage8( uint8_t *dst, uint8_t const *src1, uint8_t const *src2, int width, int height )
{
    int index = 0;
    // iterate over rows
    for( int y = 0; y < height; y++ )
    {
        // iterate over pixels in a row
        for( int x = 0; x < width; x++ )
        {
            // sum pixel values
            int t = src1[index] + src2[index];
            // clamp the sum if it is larger than 8-bit integer can represent
            dst[index] = t > 255 ? 255 : t;
            //  move over to the next pixel
            index++;
        }
    }
}


NO_INLINE
void AddImage8AlignedNEON( uint8_t *dst, uint8_t const *src1, uint8_t const *src2, int width, int height )
{
    // compute the number of vector words that fit in each row
    int const vectorNumberPerRow = width / 16;
    // iterate over rows
    for( int y = 0; y < height; y++ )
    {
        // iterate over *vectors* of pixels in a row
        for( int i = 0; i < vectorNumberPerRow; i++ )
        {
            // prefetch 64-bytes (2 cache lines on Tegra 3) ahead of the current location in the source images
            __builtin_prefetch(src1 + 64);
            __builtin_prefetch(src2 + 64);

            // load 16 pixels to vector a
            uint8x16_t a = vld1q_u8( src1 );
            // load 16 pixels to vector b
            uint8x16_t b = vld1q_u8( src2 );
            // perform 8-bit element-wise addition with saturation of vector data
            uint8x16_t r = vqaddq_u8( a, b );
            // store the resulting vector in the destination image
            vst1q_u8( dst, r );

            // shift the source and destination pointers by 16 pixels we have just processed
            src1 += 16;
            src2 += 16;
            dst += 16;
        }
    }
}


class AddImage8Processor
{
public:
    // base 2 logarithm of the numbers of elements (pixels) in a vector
    // trait needed by RunVectorizedLoop() template function
    enum
    {
        VECTOR_LOG2_LENGTH = 4 // 16 pixels in a vector
    };

    // initialize source and destination pointers
    AddImage8Processor( uint8_t *dst, uint8_t const *src1, uint8_t const *src2 )
            : mDst( dst ), mSrc1( src1 ), mSrc2( src2 )
    {
    }

    // scalar loop processor -> start and end indices can have arbitrary values
    FORCE_INLINE void runScalarLoop( int start, int end, int baseOffset ) const
    {
        // compute local source/dest pointers
        uint8_t const *src1 = mSrc1 + baseOffset;
        uint8_t const *src2 = mSrc2 + baseOffset;
        uint8_t *dst = mDst + baseOffset;

        // iterate over columns of pixels
        for( int i = start; i < end; i++ )
        {
            // sum pixel values
            int t = src1[i] + src2[i];
            // clamp the sum if it is larger than 8-bit integer can represent
            dst[i] = t > 255 ? 255 : t;
        }
    }

    // vector loop processor -> (start + baseOffset) and (end + baseOffset) indices
    // must be a multiple of 2^VECTOR_LOG2_LENGTH (2^4=16 in this case)
    FORCE_INLINE void runVectorLoop( int start, int end, int baseOffset ) const
    {
        // shift the range by base offset
        start += baseOffset;
        end += baseOffset;

        // compute local source/dest pointers
        uint8_t const *src1 = mSrc1 + start;
        uint8_t const *src2 = mSrc2 + start;
        uint8_t *dst = mDst + start;

        // convert element count to vector count
        // note: (end - start) is always a multiple of 16
        end = start + ( end - start ) / 16;

        for( int i = start; i < end; i++ )
        {
            // prefetch 64-bytes (2 cache lines on Tegra 3) ahead of the current location in the source images
            __builtin_prefetch(src1 + 64);
            __builtin_prefetch(src2 + 64);

            // load 16 pixels to vector a
            uint8x16_t a = vld1q_u8( src1 );
            // load 16 pixels to vector b
            uint8x16_t b = vld1q_u8( src2 );
            // perform 8-bit element wise addition with saturation of vectors
            uint8x16_t r = vqaddq_u8( a, b );
            // store the resulting vector in the destination image
            vst1q_u8( dst, r );

            // shift the source and destination pointers by 16 pixels we have just processed
            src1 += 16;
            src2 += 16;
            dst += 16;
        }
    }

private:
    // pointer to destination image data
    uint8_t *mDst;
    // pointer to 1st source image data
    uint8_t const *mSrc1;
    // pointer to 2nd source image data
    uint8_t const *mSrc2;
};


NO_INLINE
void AddImage8UnalignedNEON( uint8_t *dst, uint8_t const *src1, uint8_t const *src2, int width, int height )
{
    // instantiate a row processing class with source and destination pointers
    AddImage8Processor processor( dst, src1, src2 );

    // index of the 1st pixel in current row
    int baseOffset = 0;
    // iterate over rows
    for( int y = 0; y < height; y++ )
    {
        // invoke a method that uses scalar and vector processing functions
        // of the row processor class to compute pixel values in the current row
        RunVectorizedLoop( processor, 0, width, baseOffset );
        // shift the offset to the next row
        baseOffset += width;
    }
}
#endif /* EXAMPLEADDIMAGENEON_H_ */
