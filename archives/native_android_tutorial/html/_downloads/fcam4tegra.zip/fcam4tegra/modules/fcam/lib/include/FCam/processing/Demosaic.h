/* Copyright (c) 1995-2010, Stanford University.
 * Copyright (c) 2011-2012, NVIDIA CORPORATION.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FCAM_DEMOSAIC_H
#define FCAM_DEMOSAIC_H

/** \file
 * Converting RAW data to RGB24 by demosiacking and gamma correcting. */

#include "../Frame.h"

namespace FCam
{

/** Demosaic, white balance, and gamma correct a raw frame, and
 * return a slightly smaller RGB24 format image. At least four
 * pixels are lost from each side of the image, more if necessary
 * to maintain the following constraint on the output size: The
 * output will have a width that is a multiple of 40, and a height
 * which is a multiple of 24. In order to color correct, this uses
 * the frame's shot's custom color matrix if it exists. Otherwise,
 * it uses the frame's platform's \ref Platform::rawToRGBColorMatrix
 * method to retrieve the correct white-balanced color conversion
 * matrix. */
Image demosaic( Frame src, float contrast = 50.0f,
                bool denoise = true, int blackLevel = 25,
                float gamma = 2.2f );


/** Create a low-resolution representation of the input image
 * frame. For a RAW image, this means a fast combined
 * demosaic/downsample and the application of the full
 * post-processing pipeline to create a representative image. */
Image makeThumbnail( Frame src, const Size &thumbSize = Size( 640, 480 ),
                     float contrast = 50.0f, int blackLevel = 25,
                     float gamma = 2.2f );
}

#endif
