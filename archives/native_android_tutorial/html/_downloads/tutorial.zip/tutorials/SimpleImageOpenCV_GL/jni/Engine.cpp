//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include "Engine.h"

// Includes for GL and EGL
#include <EGL/egl.h>
#include <EGL/eglplatform.h>
#include <GLES2/gl2.h>

// Includes for the NVIDIA helper libraries
#include <nv_and_util/nv_native_app_glue.h>
#include <nv_egl_util/nv_egl_util.h>
#include <nv_glesutil/nv_images.h>
#include <nv_bitfont/nv_bitfont.h>
#include <nv_shader/nv_shader.h>

// Define packed colors
NvPackedColor activeColor   = NV_PACKED_COLOR( 250, 180, 50, 255 );
NvPackedColor deactiveColor = NV_PACKED_COLOR( 255, 255, 255, 255 );

Engine::Engine( NvEGLUtil &egl, struct android_app *app )
    : mEgl( egl ), mApp( app ), mResizePending( false ), mActiveMode( true ),
      mForceRender( FRAMES_TO_RENDER ), mUiInitialized( false )
{
    // Save a pointer to the engine in the Android app
    app->userData = this;

    // Save pointers to the implementation of the callback functions in the
    // Android app
    app->onAppCmd     = &Engine::handleCmdThunk;
    app->onInputEvent = &Engine::handleInputThunk;

    // Initialize the nv_shader library
    nv_shader_init( app->activity->assetManager );

    // Initialize all the UI components
    mClockText   = NULL;
    mUiPauseText = NULL;
    mUiButton[0] = NULL;
    mUiButton[1] = NULL;
    mHitButton   = 0;

    // Initialize the mDrawRect and mRectShader objects
    mDrawRect      = NULL;
    mRectShader[0] = NULL;
    mRectShader[1] = NULL;

    // Initialize the texture
    mImgTexture    = 0;
    // Initialize the time counter
    mTimeVal = 0.0;
}


Engine::~Engine()
{
    // Free the allocated BitFonts
    NVBFTextFree( mUiButton[0] );
    NVBFTextFree( mUiButton[1] );
    NVBFTextFree( mUiPauseText );
    NVBFTextFree( mClockText );
    NVBFCleanup();

    // Delete the texture
    glDeleteTextures( 1, &mImgTexture );

    // release capture device
    mCapture.release();
}


void Engine::handleCmdThunk( struct android_app *app, int32_t cmd )
{
    // Get a pointer to the Engine we stored in the Android app
    Engine *engine = ( Engine * ) app->userData;
    if( engine )
    {
        engine->handleCommand( cmd );
    }
}


void Engine::handleCommand( int cmd )
{
    switch( cmd )
    {
    case APP_CMD_INIT_WINDOW:
        // The window is being shown, get it ready.
        // Note that on ICS, the EGL size will often be correct for the new size here,
        // but on HC it will not be.  We need to defer checking the new res until the
        // first render with the new surface!

    case APP_CMD_WINDOW_RESIZED:
        // A command to resize the window was issued, we need to
        // redraw it with its new size.
        mEgl.setWindow( mApp->window );
        requestForceRender();
        break;

    case APP_CMD_TERM_WINDOW:
        // The window is being hidden or closed, clean it up.
        mEgl.setWindow( NULL );
        break;

    case APP_CMD_GAINED_FOCUS:
        // The app window gained focus we need to start rendering it.
        requestForceRender();
        break;

    case APP_CMD_LOST_FOCUS:
        // The app window lost focus so we need to pause it.

    case APP_CMD_PAUSE:
        // Move out of active mode if we are in it. But if we are
        // in another dialog mode, leave it as-is.
        if( mActiveMode )
        {
            setActiveMode( false );
        }
        // Note that we still want to render in background.
        requestForceRender();
        break;

    case APP_CMD_CONFIG_CHANGED:
        // ICS does not appear to require this, but on GB phones,
        // not having this causes rotation changes to be delayed or
        // ignored when we're in a non-rendering mode like autopause.
        // The forced renders appear to allow GB to process the rotation.
        requestForceRender();
        break;
    }
}


/**
 * Process the next input event.
 */
int32_t Engine::handleInputThunk( struct android_app *app, AInputEvent *event )
{
    // Get a pointer to the Engine we stored in the Android app
    Engine *engine = ( Engine * ) app->userData;
    if( !engine ) { return 0; }
    return engine->handleInput( event );
}


int Engine::handleInput( AInputEvent *event )
{
    //We only handle motion events (touchscreen) and key (button/key) events
    int32_t eventType = AInputEvent_getType( event );

    if( eventType == AINPUT_EVENT_TYPE_MOTION )
    {
        int32_t action = AMOTION_EVENT_ACTION_MASK & AMotionEvent_getAction( ( const AInputEvent * )event );

        int32_t mx = AMotionEvent_getX( event, 0 );
        int32_t my = AMotionEvent_getY( event, 0 );

        if( isActiveMode() )
        {
            // Check if the touch was inside of the first button...
            if( mUiButtonZone[0].inside( mx, my ) )
            {
                mHitButton = 0;
                // ``CAM`` button calls a camera capture function here
                mUseCVCam = true;
            }
            // ... or the second
            else if( mUiButtonZone[1].inside( mx, my ) )
            {
                mHitButton = 1;
                mUseCVCam = false;

                // ``IMAGE`` button calls a load image function, and
                // a function to update a texture here.
                updateCVTexture( mImgTexture, mCV.runLoadCVImg() );
            }
        }
        else
        {
            // A tap on the screen takes us out of autopause into active mode if
            // we were paused.  No other touch processing is done.
            if( action == AMOTION_EVENT_ACTION_DOWN )
            {
                setActiveMode( true );
                return 0;
            }
        }
        return 1;
    }
    else if( eventType == AINPUT_EVENT_TYPE_KEY )
    {
        int32_t code = AKeyEvent_getKeyCode( ( const AInputEvent * ) event );

        // if we are in active mode, we eat the back button and move into
        // pause mode.  If we are already in pause mode, we allow the back
        // button to be handled by the OS, which means we'll be shut down
        if( ( code == AKEYCODE_BACK ) && mActiveMode )
        {
            setActiveMode( false );
            return 1;
        }
    }

    return 0;
}


void Engine::updateFrame( bool interactible, long deltaTime )
{
    if( interactible )
    {
        // Each frame, we check to see if the window has resized.  While the
        // various events we get _should_ cover this, in practice, it appears
        // that the safest move across all platforms and OSes is to check at
        // the top of each frame
        checkWindowResized();

        // Time stands still when we're auto-paused, and we don't
        // automatically render
        if( mActiveMode )
        {
            // The time needs to advance in active mode.
            advanceTime( deltaTime );

            // This will try to set up EGL if it isn't set up
            // When we first set up EGL completely, we also load our GLES resources
            // If these are already set up or we succeed at setting them all up now, then
            // we go ahead and render.
            renderFrame( true );
        }
        else if( isForcedRenderPending() )  // forced rendering when needed for UI, etc.
        {
            // This forces to render.
            renderFrame( true );
        }
    }
    else
    {
        // Even if we are not interactible, we may be visible, so we
        // HAVE to do any forced renderings if we can.  We must also
        // check for resize, since that may have been the point of the
        // forced render request in the first place!
        if( isForcedRenderPending() && mEgl.isReadyToRender( false ) )
        {
            checkWindowResized();
            renderFrame( false );
        }
    }
}


bool Engine::renderFrame( bool allocateIfNeeded )
{
    // Check that EGL is ready to render. If allocateIfNeeded
    // try to also allocate the rendering surface and bind it
    // to the context.
    if( !mEgl.isReadyToRender( allocateIfNeeded ) )
    {
        return false;
    }

    // Make sure that the UI is initialized
    if( !initUI() )
    {
        LOGW( "Could not initialize UI - assets may be missing!" );
        ANativeActivity_finish( mApp->activity );
        return false;
    }
    resizeIfNeeded();

    // Set up viewport
    glViewport( ( GLint )0, ( GLint )0,
                ( GLsizei )( mEgl.getWidth() ), ( GLsizei )( mEgl.getHeight() ) );

    // Clear buffers as necessary
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    /* Do some rendering here */
    // Based on the button that is selected choose the shader that should be used...
    mDrawRect->setShader( mRectShader[1].get() );
    // ... and pass the texture to the shader.
    mDrawRect->draw( mImgTexture );

    // OpenCV Camera
    if( mUseCVCam )
    {
        // grab the openCV camera:
        if( !mCapture.grab() )
        {
            LOGI( "CV: cannot grab frame" );
            mUseCVCam = false;
        }
        // retrieve the frame from the openCV camera:
        cv::Mat frameimg;
        if( !mCapture.retrieve( frameimg, CV_CAP_ANDROID_COLOR_FRAME_RGB ) )
        {
            LOGI( "CV:: cannot retrieve frame -- break" );
            mUseCVCam = false;
        }
        // Bind the texture with the frameimg.
        // updateCVTexture( mImgTexture, frameimg );
        updateCVTexture( mImgTexture, mCV.runOpenCVFeatureDetector( frameimg ) );

        frameimg.release();
    }





    // Render the rendering bitfont text overlaid here.
    NVBFTextRenderPrep();

    // Update the clock.
    if( mClockText )
    {
        // Set the correct color depending on the mActiveMode
        NVBFTextSetMultiplyColor( mClockText,
                                  mActiveMode ? activeColor : deactiveColor );
        NVBFTextRender( mClockText );

        // We update the clock text >after< rendering, so it will change on pause.
        int mins = mTimeVal / 60;
        float secs = ( float )mTimeVal - mins * 60;
        char str[32];
        sprintf( str, "%03d:%05.2f", mins, secs );
        NVBFTextSetString( mClockText, str );
    }

    // Render the buttons.
    if( !mActiveMode )
    {
        NVBFTextRender( mUiPauseText );
    }
    else
    {
        NVBFTextSetMultiplyColor( mUiButton[mHitButton], activeColor );
        NVBFTextSetMultiplyColor( mUiButton[( mHitButton + 1 ) % 2], deactiveColor );
        NVBFTextRender( mUiButton[0] );
        NVBFTextRender( mUiButton[1] );
    }

    // Done rendering overlaid text.
    NVBFTextRenderDone();

    if( mForceRender > 0 ) { mForceRender--; }

    // Swap the buffers, which indicates we're done with rendering this frame
    mEgl.swap();

    return true;
}


bool Engine::initUI()
{
    // The UI might have been initialized already
    if( mUiInitialized )
    {
        return true;
    }

    LOGD( "Initializing UI" );

    // Initialize the NVIDIA bitfonts
    const int NUM_FONTS = 2;
    static NvBool fontsSplit[NUM_FONTS] = {1, 1}; // all are split
    static const char *fontFiles[NUM_FONTS] = { "courier+lucida_256.dds", "utahcond+bold_1024.dds" };
    if( NVBFInitialize( NUM_FONTS, ( const char ** )fontFiles, fontsSplit, 0 ) )
    {
        LOGW( "Could not initialize NvBitFont" );
        return false;
    }

    // Allocate the text for the clock and set its properties
    mClockText = NVBFTextAlloc();
    NVBFTextSetFont( mClockText, 1 ); // should look up by font file name.
    NVBFTextSetSize( mClockText, 32 );
    NVBFTextSetColor( mClockText, NV_PC_PREDEF_WHITE );
    NVBFTextSetString( mClockText, "000:00.00" );

    // Allocate the text for the text of the autopause mode and set its properties
    mUiPauseText = NVBFTextAlloc();
    NVBFTextSetFont( mUiPauseText, 2 ); // should look up by font file name.
    NVBFTextSetSize( mUiPauseText, 32 );
    NVBFTextSetColor( mUiPauseText, NV_PC_PREDEF_WHITE );
    NVBFTextSetString( mUiPauseText,
                       NVBF_COLORSTR_RED NVBF_STYLESTR_BOLD "Auto-pause:\n" NVBF_STYLESTR_NORMAL
                       NVBF_COLORSTR_BLUE "Press back to quit\nTap window to resume" );

    // UI Buttons
    mUiButton[0] = NVBFTextAlloc();
    NVBFTextSetFont( mUiButton[0], 2 ); // should look up by font file name.
    NVBFTextSetSize( mUiButton[0], 48 );
    NVBFTextSetColor( mUiButton[0], NV_PC_PREDEF_WHITE );
    NVBFTextSetShadow( mUiButton[0], 5, NV_PC_PREDEF_BLACK );
    NVBFTextSetString( mUiButton[0], NVBF_STYLESTR_BOLD "CAM" );

    mUiButton[1] = NVBFTextAlloc();
    NVBFTextSetFont( mUiButton[1], 2 ); // should look up by font file name.
    NVBFTextSetSize( mUiButton[1], 48 );
    NVBFTextSetColor( mUiButton[1], NV_PC_PREDEF_WHITE );
    NVBFTextSetShadow( mUiButton[1], 5, NV_PC_PREDEF_BLACK );
    NVBFTextSetString( mUiButton[1], NVBF_STYLESTR_BOLD "IMAGE" );

    // Set the correct button as active.
    mHitButton = 1;
    NVBFTextSetMultiplyColor( mUiButton[mHitButton], activeColor );

    // Load the texture image
    mImgTexture = NvCreateTextureFromDDSEx( "nvidia_green.dds", false, false, NULL, NULL, NULL, NULL );

    // Allocate the objects
    mDrawRect.reset( new DrawRect );
    mRectShader[0].reset( new RectShader( "filter" ) );
    mRectShader[0]->setImageSize( 1366.0, 720.0,
                                  RectShader::STORAGE_TOP_FIRST, RectShader::ASPECT_RATIO_STRETCH );
    mRectShader[1].reset( new RectShader( "plain" ) );
    mRectShader[1]->setImageSize( 1366.0, 720.0,
                                  RectShader::STORAGE_TOP_FIRST, RectShader::ASPECT_RATIO_STRETCH );

    mUseCVCam = false;

    // Open the OpenCV camera  0 for frontal and 1 for backward camera
    mCapture.open( CV_CAP_ANDROID + 0 );
    if( !mCapture.isOpened() )
    {
        LOGI( "CV: OpenCV camera was not opened correctly" );
    }
    LOGI( "CV: OpenCV camera was opened correctly" );

    // set the properties of the OpenCV camera
    mCapture.set( CV_CAP_PROP_AUTOGRAB, 1 );
    mCapture.set( CV_CAP_PROP_FRAME_WIDTH, 640 );
    mCapture.set( CV_CAP_PROP_FRAME_HEIGHT, 480 );

    LOGI( "CV: OpenCV camera setup done" );


    mUiInitialized = true;

    return true;
}


bool Engine::resizeIfNeeded()
{
    // Do we need to resize?
    if( !mResizePending )
    {
        return false;
    }

    // Get the target height and width
    int w = mEgl.getWidth();
    int h = mEgl.getHeight();
    int textHeight = ( w > h ) ? ( h / 16 ) : ( w / 16 );

    // Change the resolution to the correct width and height
    NVBFSetScreenRes( w, h );

    // Also update the size of the characters and their location
    if( mClockText )
    {
        NVBFTextSetSize( mClockText, textHeight );
        NVBFTextCursorAlign( mClockText, NVBF_ALIGN_LEFT, NVBF_ALIGN_TOP );
        NVBFTextCursorPos( mClockText, 10, 10 );
    }
    if( mUiPauseText )
    {
        NVBFTextSetSize( mUiPauseText, textHeight );
        NVBFTextCursorAlign( mUiPauseText, NVBF_ALIGN_CENTER, NVBF_ALIGN_BOTTOM );
        NVBFTextCursorPos( mUiPauseText, w / 2, h / 2 );
    }
    if( mUiButton[0] )
    {
        NVBFTextSetSize( mUiButton[0], textHeight );
        NVBFTextCursorAlign( mUiButton[0], NVBF_ALIGN_RIGHT, NVBF_ALIGN_BOTTOM );
        NVBFTextCursorPos( mUiButton[0], w - textHeight * 4, h - 10 );
        mUiButtonZone[0].set( w - textHeight * 6, h - 10 - textHeight, textHeight * 2, textHeight );

    }
    if( mUiButton[1] )
    {
        NVBFTextSetSize( mUiButton[1], textHeight );
        NVBFTextCursorAlign( mUiButton[1], NVBF_ALIGN_RIGHT, NVBF_ALIGN_BOTTOM );
        NVBFTextCursorPos( mUiButton[1], w - textHeight, h - 10 );
        mUiButtonZone[1].set( w - textHeight * 3, h - 10 - textHeight, textHeight * 2, textHeight );
    }

    if( mRectShader[0].get() != nullptr )
    {
        mRectShader[0]->setViewportAspectRatio( ( float ) w, float( h ) );
    }
    if( mRectShader[1].get() != nullptr )
    {
        mRectShader[1]->setViewportAspectRatio( ( float ) w, float( h ) );
    }

    mResizePending = false;

    return true;
}


void Engine::setActiveMode( bool running )
{
    if( mActiveMode != running )
    {
        requestForceRender();
    }
    mActiveMode = running;
}


bool Engine::checkWindowResized()
{
    if( mEgl.checkWindowResized() )
    {
        mResizePending = true;
        requestForceRender();
        LOGI( "Window size change %dx%d", mEgl.getWidth(), mEgl.getHeight() );
        return true;
    }
    return false;
}


// Update a texture with OpenCV image (Mat)
void Engine::updateCVTexture( GLuint imgTexture, cv::Mat img )
{
    // The images we get from the camera or read from opencv are byte aligned.
    glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );

    // Update the texture
    glBindTexture( GL_TEXTURE_2D, imgTexture );
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, img.cols, img.rows, 0, GL_RGB, GL_UNSIGNED_BYTE, img.data );
    glBindTexture( GL_TEXTURE_2D, 0 );

    // Update the shader
    mRectShader[1]->setImageSize( img.cols, img.rows,
                                  RectShader::STORAGE_TOP_FIRST, RectShader::ASPECT_RATIO_KEEP );
}
