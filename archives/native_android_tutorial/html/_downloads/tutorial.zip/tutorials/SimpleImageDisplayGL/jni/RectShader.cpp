//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include "RectShader.h"
#include <GLES2/gl2ext.h>

// NVIDIA helper include
#include <nv_shader/nv_shader.h>

RectShader::RectShader( const char *shaderName )
{
    // Load the fragment and vertex shaders.
    mProgram = nv_load_program( shaderName );

    // Compile, link, and attach the shader to the program.
    glUseProgram( mProgram );

    // Get pointers to the attributes in the program.
    mPosAttrib = glGetAttribLocation( mProgram, "aPos" );
    mUvAttrib  = glGetAttribLocation( mProgram, "aUV" );

    // Set up the texture sampler to texture unit 0
    GLint texUni = glGetUniformLocation( mProgram, "uTex" );
    glUniform1i( texUni, 0 );

    // Get the location of the uniforms we will be udpating
    mViewOrigUniform = glGetUniformLocation( mProgram, "uViewMin" );
    mViewDimUniform = glGetUniformLocation( mProgram, "uViewDim" );
    mDUniform       = glGetUniformLocation( mProgram, "uD" );

    // Initialize some default values for aspect ratio and uniforms.
    mViewportAspectRatio = 1.0f;
    mRectAspectRatio = 1.0f;
    mTexelDelta[0] = mTexelDelta[1] = 1.0f;
    mZeroRowPos = STORAGE_TOP_FIRST;
    mAspectBehavior = ASPECT_RATIO_KEEP;

    updateClipRegion();
}

RectShader::~RectShader()
{
    // Delete the program object
    glDeleteProgram( mProgram );
}

void RectShader::bind( const GLfloat vertices[8], const GLfloat uvs[8] )
{
    // Install the program object as a part of the current rendering state.
    glUseProgram( mProgram );

    // Disable VBO's (vertex buffer objects) for attributes.
    glBindBuffer( GL_ARRAY_BUFFER, 0 );
    glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 );

    // Set the attribute mPosAttrib with the vertices in the screen coordinates...
    glVertexAttribPointer( mPosAttrib, 2, GL_FLOAT, GL_FALSE, 0, vertices );
    // ... and enable it.
    glEnableVertexAttribArray( mPosAttrib );

    // Set the attribute mUvAttrib with the vertices in the GL coordinates...
    glVertexAttribPointer( mUvAttrib, 2, GL_FLOAT, GL_FALSE, 0, uvs );
    // ... and enable it.
    glEnableVertexAttribArray( mUvAttrib );

    // Update the uniforms
    glUniform2f( mViewOrigUniform, mViewOrig[0], mViewOrig[1] );
    glUniform2f( mViewDimUniform,  mViewDim[0] , mViewDim[1] );
    glUniform2f( mDUniform, mTexelDelta[0], mTexelDelta[1] );
}

void RectShader::setViewportAspectRatio( float width, float height )
{
    // Update the viewport aspect ration
    mViewportAspectRatio = width / height;

    // Update the viewport region the image will cover.
    updateClipRegion();
}

void RectShader::setImageSize( float width, float height, ImageRowStorage zeroRowPos, ImageAspectRatio aspect )
{
    // Update the rectangle aspect ratio
    mRectAspectRatio = width / height;
    mZeroRowPos = zeroRowPos;
    mAspectBehavior = aspect;

    // Update the texel delta.
    mTexelDelta[0] = 1.0f / width;
    mTexelDelta[1] = 1.0f / height;

    // Update the viewport region the image will cover.
    updateClipRegion();
}

void RectShader::updateClipRegion()
{
    if( mAspectBehavior == ASPECT_RATIO_KEEP )
    {
        if( mViewportAspectRatio > mRectAspectRatio )
        {
            // Viewport is wider than rectangle
            // Use entire viewport height and clip width
            mViewOrig[0] = -1.0f + ( mViewportAspectRatio - mRectAspectRatio ) / 2.0f;
            mViewOrig[1] = -1.0f;
            mViewDim[0] =  2.0f - ( mViewportAspectRatio - mRectAspectRatio );
            mViewDim[1] =  2.0f;
        }
        else
        {
            // Viewport is taller than rectangle
            // Use entire viewport width and clip height
            mViewOrig[0] = -1.0f;
            mViewOrig[1] = -1.0f + ( 1.0f / mViewportAspectRatio - 1.0f / mRectAspectRatio ) / 2.0f;
            mViewDim[0] =  2.0f;
            mViewDim[1] =  2.0f - ( 1.0f / mViewportAspectRatio - 1.0f / mRectAspectRatio );
        }
    }
    else
    {
        mViewOrig[0] = mViewOrig[1] = -1.0f;
        mViewDim[0] = mViewDim[1] = 2.0f;
    }

    // If zero row is at the top, we need to flip the vertical signs
    if( mZeroRowPos == STORAGE_TOP_FIRST )
    {
        mViewOrig[1] = -mViewOrig[1];
        mViewDim[1] = -mViewDim[1];
    }
}

void RectShader::getOrigUniform( GLfloat origin[2] ) const
{
    origin[0] = mViewOrig[0];
    origin[1] = mViewOrig[1];
}

void RectShader::getDimUniform( GLfloat dim[2] ) const
{
    dim[0] = mViewDim[0];
    dim[1] = mViewDim[1];
}
