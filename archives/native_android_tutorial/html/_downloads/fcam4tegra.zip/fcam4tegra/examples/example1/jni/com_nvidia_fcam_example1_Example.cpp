/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <jni.h>
#include <pthread.h>

extern int main( int argc, char * argv[] );

/* A structure that holds the methods ID of the Java functions that the app
 * can call */
struct fields_t
{
    jmethodID   completionCb;     // example has finished executing.
};

static JavaVM * gJavaVM;
static jclass   exampleJClass;
static jobject  exampleInstance;
static fields_t fields;
static pthread_t fcamthread;

void jniAttachThread()
{
    JNIEnv * env;
    int status = gJavaVM->AttachCurrentThread( &env, NULL );
}

void jniDetachThread()
{
    gJavaVM->DetachCurrentThread();
}

void notifyCompletion()
{
    JNIEnv * env;
    gJavaVM->GetEnv(( void ** ) &env, JNI_VERSION_1_4 );
    env->CallVoidMethod( exampleInstance, fields.completionCb );
}

void deleteGlobalRefs()
{
    JNIEnv * env;
    gJavaVM->GetEnv(( void ** ) &env, JNI_VERSION_1_4 );
    env->DeleteGlobalRef( exampleInstance );
    exampleInstance = NULL;
}


#ifdef __cplusplus
extern "C" {
#endif

    jint JNI_OnLoad( JavaVM * vm, void * reserved )
    {
        // Cache the java vm
        gJavaVM = vm;
        return JNI_VERSION_1_4;
    }

    void * fcam_thread_( void * arg )
    {
        jniAttachThread();
        main( 0, NULL );
        notifyCompletion();
        deleteGlobalRefs();
        jniDetachThread();
        pthread_exit( NULL );
        return NULL;
    }

    /*
     * Class:     com_nvidia_fcam_example1_Example
     * Method:    run
     * Signature: ()I
     */
    JNIEXPORT jint JNICALL Java_com_nvidia_fcam_example1_Example_run
    ( JNIEnv * env, jobject thiz )
    {

        // Register the Java based instance, class and methods we need to later call.
        exampleInstance = env->NewGlobalRef( thiz );
        exampleJClass   = ( jclass )env->NewGlobalRef( env->GetObjectClass( thiz ) );
        fields.completionCb = env->GetMethodID( exampleJClass, "onCompletion", "()V" );

        // Launch the fcamera thread
        pthread_create( &fcamthread, NULL, fcam_thread_, NULL );

    }

#ifdef __cplusplus
}
#endif
