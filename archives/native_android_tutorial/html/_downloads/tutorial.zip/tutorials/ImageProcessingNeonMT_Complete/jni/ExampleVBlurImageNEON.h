//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef EXAMPLEVBLURIMAGENEON_H_
#define EXAMPLEVBLURIMAGENEON_H_

#include <arm_neon.h>
#include "Common.h"


NO_INLINE
void VBlurImage8( uint8_t *dst, uint8_t const *src, int const width, int const height, int const lineStride,
                  int const startY, const int endY )
{
    // blur weights
    uint16_t const weights[] = { 1, 3, 5, 3, 1 };
    // weight sum
    int const weightsSum = 13;
    // kernel size
    int const ksize = sizeof( weights ) / sizeof( weights[0] );

    // weight sum fractional precision
    int const weightsNormShift = 7;
    // 1.0 represented as fixed point number
    float const weightsNorm = (float) ( 1 << weightsNormShift );
    // inverse of weight sum (fixed-point)
    float const iwsum = weightsNorm / weightsSum;
    // blur weights in fixed point precision
    uint16_t const iweights[] =
    { (uint16_t) ( weights[0] * iwsum ), (uint16_t) ( weights[1] * iwsum ), (uint16_t) ( weights[2] * iwsum ),
      (uint16_t) ( weights[3] * iwsum ), (uint16_t) ( weights[4] * iwsum ) };

    // shift source and destination pointers to the start row
    dst += startY * lineStride;

    // loop over a range of rows
    for( int y = startY; y < endY; y++ )
    {
        // we start integrating at current pixel y position minus half of the kernel size
        int istart = y - ( ksize / 2 );
        // we end integrating at current pixel y position plus half of the kernel size
        int iend = y + ( ksize / 2 ) + 1;

        // compute row start offset
        int rowStartOffset = istart * lineStride;

        if( istart >= 0 && iend < height )
        {
            // integration happens completely inside of the image (no clipping)

            for( int x = 0; x < width; x++ )
            {
                // current pixel offset
                int currentOffset = rowStartOffset + x;
                // pixel accumulator
                int accum = 0;
                // accumulate weighted pixel values from neighboring rows
                for( int i = 0; i < ksize; i++ )
                {
                    accum += iweights[i] * src[currentOffset];
                    // shift to the next row
                    currentOffset += lineStride;
                }

                // write out the accumulator divided by the sum of weights
                dst[x] = static_cast<uint8_t>( accum >> weightsNormShift );
            }
        }
        else
        {
            // integration goes outside the image (clip)
            int woffset = istart;

            // clip if we go outside of the image
			if( istart < 0 )    { 
				istart = 0;
				rowStartOffset = 0;    
			}
            if( iend > height ) { iend = height; }

            // compute temporary *normalized* weights for this row
            uint16_t tweights[ksize];

            // weights sum needed for normalization
            int wsum = weights[istart - woffset];
            for( int i = istart + 1; i < iend; i++ )
            {
                wsum += weights[i - woffset];
            }

            // normalize weights
            float wnorm = weightsNorm / wsum;
            for( int i = istart; i < iend; i++ )
            {
                tweights[i - istart] = static_cast<uint16_t>( weights[i - woffset] * wnorm );
            }

            // process pixels in a row
            for( int x = 0; x < width; x++ )
            {
                // current pixel offset
                int currentOffset = rowStartOffset + x;
                // pixel accumulator
                int accum = 0;
                // accumulate weighted pixel values from neighboring rows
                for( int i = istart; i < iend; i++ )
                {
                    accum += tweights[i - istart] * src[currentOffset];
                    // shift to the next row
                    currentOffset += lineStride;
                }

                // write out the accumulator divided by the sum of weights
                dst[x] = static_cast<uint8_t>( accum >> weightsNormShift );
            }
        }

        // shift to the next row of destination image
        dst += lineStride;
    }
}


#define INIT_16BIT_ACCUMULATORS( a1, a2 ) \
    uint16x8_t a1 = vmovq_n_u16( 0 ); \
    uint16x8_t a2 = vmovq_n_u16( 0 )

#define ACCUMULATE_16_8BIT_WEIGHTED( data, a1, a2, weight ) \
    /* load 16x8-bit uint pixels to a vector */ \
    uint8x16_t p_u8 = vld1q_u8( data ); \
    /* extract the first 8 and the last 8 to separate vectors */ \
    uint8x8_t lp_u8 = vget_low_u8( p_u8 ); \
    uint8x8_t hp_u8 = vget_high_u8( p_u8 ); \
    /* convert (expand) their format from 8x8-bit uint into 8x16-bit uint */ \
    uint16x8_t lp_u16 = vmovl_u8( lp_u8 ); \
    uint16x8_t hp_u16 = vmovl_u8( hp_u8 ); \
    /* multiply by scalar weight and add to accumulators */ \
    a1 = vmlaq_n_u16( a1, lp_u16, weight ); \
    a2 = vmlaq_n_u16( a2, hp_u16, weight )

#define STORE_ACCUMULATORS_TO_16_8BIT( a1, a2, dst ) \
    /* normalize the accumulators back to 8-bit range by shifting decimal point to right */ \
    a1 = vshrq_n_u16( a1, weightsNormShift ); \
    a2 = vshrq_n_u16( a2, weightsNormShift ); \
    /* convert accumulators format from 8x16-bit uint into 8x8-bit uint, high-order bits not needed */ \
    uint8x8_t laccum_u8 = vmovn_u16( a1 ); \
    uint8x8_t haccum_u8 = vmovn_u16( a2 ); \
    /* combine two 8x8-bit accumulators into one 16x8-bit accumulator */ \
    uint8x16_t accum_u8 = vcombine_u8( laccum_u8, haccum_u8 ); \
    /* store the resulting vector in the destination image */ \
    vst1q_u8( dst, accum_u8 )


NO_INLINE
void VBlurImage8AlignedNEON( uint8_t *dst, uint8_t const *src, int const width, int const height, int const lineStride,
                             int const startY, int const endY )
{
    // blur weights
    uint16_t const weights[] = { 1, 3, 5, 3, 1 };
    // weight sum
    int const weightsSum = 13;
    // kernel size
    int const ksize = sizeof( weights ) / sizeof( weights[0] );

    // weight sum fractional precision
    int const weightsNormShift = 7;
    // 1.0 represented as fixed point number
    float const weightsNorm = (float) ( 1 << weightsNormShift );
    // inverse of weight sum (fixed-point)
    float const iwsum = weightsNorm / weightsSum;
    // blur weights in fixed point precision
    uint16_t const iweights[] =
    { (uint16_t) ( weights[0] * iwsum ), (uint16_t) ( weights[1] * iwsum ), (uint16_t) ( weights[2] * iwsum ),
      (uint16_t) ( weights[3] * iwsum ), (uint16_t) ( weights[4] * iwsum ) };

    // compute the number of vector words that fit in each row
    int const vectorNumberPerRow = width / 16;

    // shift source and destination pointers to the start row
    src += startY * lineStride;
    dst += startY * lineStride;

    // loop over a range of rows
    for( int y = startY; y < endY; y++ )
    {
        // we start integrating at current pixel y position minus half of the kernel size
        int istart = y - ( ksize / 2 );
        // we end integrating at current pixel y position plus half of the kernel size
        int iend = y + ( ksize / 2 ) + 1;

        if( istart >= 0 && iend < height )
        {
            // integration happens completely inside of the image (no clipping)
            // this is a major case executed for most of the image rows

            int rowStartOffset = -( ksize / 2 ) * lineStride;

            // iterate over all vectors in a row
            for( int x = 0; x < vectorNumberPerRow; x++, src += 16, dst += 16 )
            {
                // shift the source pointer to the top row
                uint8_t const *sourceData = src + rowStartOffset;

                // initialize two 8x16-bit accumulators so we can accumulate 16 pixels at a time
                INIT_16BIT_ACCUMULATORS( laccum_u16, haccum_u16 );

                for( int i = 0; i < ksize; i++, sourceData += lineStride )
                {
                    // prefetch 64-bytes (2 cache lines on Tegra 3) ahead of the current location in the source image
                    __builtin_prefetch(sourceData + 64);
                    ACCUMULATE_16_8BIT_WEIGHTED( sourceData, laccum_u16, haccum_u16, iweights[i] );
                }

                STORE_ACCUMULATORS_TO_16_8BIT( laccum_u16, haccum_u16, dst );
            }
        }
        else
        {
            // integration goes outside the image (clip)
            // this is minor case executed for top and bottom-most rows in the image

            int woffset = istart;
            // clip if we go outside of the image
			if( istart < 0 )    { 
				istart = 0;
			}
            if( iend > height ) { iend = height; }

            // compute temporary *normalized* weights for this row
            uint16_t tweights[ksize];

            // weights sum needed for normalization
            int wsum = weights[istart - woffset];
            for( int i = istart + 1; i < iend; i++ )
            {
                wsum += weights[i - woffset];
            }

            float wnorm = weightsNorm / wsum;
            for( int i = istart; i < iend; i++ )
            {
                tweights[i - istart] = static_cast<uint16_t>( weights[i - woffset] * wnorm );
            }

            int rowStartOffset = ( istart - y ) * lineStride;

            for( int x = 0; x < vectorNumberPerRow; x++, src += 16, dst += 16 )
            {
                uint8_t const *sourceData = src + rowStartOffset;

                // initialize two 8x16-bit accumulators so we can accumulate 16 pixels at a time
                INIT_16BIT_ACCUMULATORS( laccum_u16, haccum_u16 );

                // iterate over all vectors in a row
                for( int i = istart; i < iend; i++, sourceData += lineStride )
                {
                    // prefetch 64-bytes (2 cache lines on Tegra 3) ahead of the current location in the source image
                    __builtin_prefetch(sourceData + 64);
                    ACCUMULATE_16_8BIT_WEIGHTED( sourceData, laccum_u16, haccum_u16, tweights[i - istart] );
                }

                STORE_ACCUMULATORS_TO_16_8BIT( laccum_u16, haccum_u16, dst );
            }
        }

        // correct data pointers by the difference between image width and row stride
        src += lineStride - width;
        dst += lineStride - width;
    }
}

#endif /* EXAMPLEVBLURIMAGENEON_H_ */
