/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "../Debug.h"
#include "Statistics.h"

namespace FCam
{
namespace Tegra
{

FCam::SharpnessMap Statistics::evaluateVariance( FCam::SharpnessMapConfig mapCfg, FCam::Image im )
{
    if( !mapCfg.enabled ) { return SharpnessMap(); }

    Rect region;
    region.x = 0;
    region.y = 0;
    region.width = im.size().width;
    region.height = im.size().height;

    // Make sure we don't take more than MAX_VARIANCE_SAMPLES samples
    // to avoid integer overflow.
    int subsample = 1;
    int samplesX, samplesY;

    samplesX = im.size().width;
    samplesY = im.size().height;
    while( samplesX * samplesY > MAX_VARIANCE_SAMPLES )
    {
        samplesX  = samplesX >> 1;
        samplesY  = samplesY >> 1;
        subsample = subsample << 1;
    }

    SharpnessMap s( Size( 1, 1 ), 1 );
    s( 0, 0, 0 ) = evaluateVariance( im, region, subsample );

    return s;
}

int Statistics::evaluateVariance( Image im, Rect region, int subsample )
{
    // Boundary check
    if( region.x < 0 || region.x >= im.size().width ||
        region.y < 0 || region.y >= im.size().height )
    {
        return 0.0f;
    }

    Rect boundaries = region;
    if( region.x + region.width >= im.size().width )
    {
        boundaries.width = im.size().width - region.x - 1;
    }

    if( region.y + region.height >= im.size().height )
    {
        boundaries.height = im.size().height - region.y - 1;
    }

    int sumX2, sumX, samples;
    sumX2 = sumX = samples = 0;

    for( int j = boundaries.y; j < boundaries.y + boundaries.height; j += subsample )
    {
        unsigned char *dataPtr = im( boundaries.x, j );

        for( int i = boundaries.x; i < boundaries.x + boundaries.width; i += subsample )
        {
            sumX    += dataPtr[0];
            sumX2   += dataPtr[0] * dataPtr[0];
            dataPtr += subsample;
            samples++;
        }
    }

    int expX2 = sumX2 / samples;
    int expX  = sumX / samples;
    return    expX2 - expX * expX;
}



Histogram Statistics::evaluateYUVHistogram( const HistogramConfig &histoCfg, Image im )
{
    return evaluateYUVHistogram( histoCfg, im.getPlane( Y8 ), im.getPlane( U8 ), im.getPlane( V8 ) );
}

Histogram Statistics::evaluateYUVHistogram( const HistogramConfig &histoCfg,
                                            Image imY,
                                            Image imU,
                                            Image imV )
{

    unsigned buckets    = 1;
    unsigned reqbuckets = histoCfg.buckets;
    unsigned shiftbits = 0;
    unsigned bucketsize = 0;

    // Compute a power of two buckets from histogram config
    while( reqbuckets > 1 )
    {
        buckets = buckets << 1;
        reqbuckets = reqbuckets >> 1;
    }

    bucketsize = 256 / buckets;
    while( bucketsize > 1 )
    {
        shiftbits++;
        bucketsize = bucketsize >> 1;
    }

    // Compute boundaries in uv plane (divide by 2)
    Rect boundaries = histoCfg.region;

    if( boundaries.width == 0 || boundaries.height == 0 )
    {
        boundaries.width = imY.width();
        boundaries.height = imY.height();
    }

    // Compute subsample factor
    int samplesX = boundaries.width  >> 1;
    int samplesY = boundaries.height >> 1;
    int subsample = 2; // uv are already subsampled by 2.
    while( samplesX * samplesY > MAX_HISTOGRAM_SAMPLES )
    {
        samplesX  = samplesX >> 1;
        samplesY  = samplesY >> 1;
        subsample = subsample << 1;
    }

    int subsample2 = subsample >> 1;
    Histogram histo( buckets, 3, histoCfg.region, YpUV );

    for( int j = boundaries.y; j < boundaries.y + boundaries.height; j += subsample )
    {
        unsigned char *dataYPtr = imY( boundaries.x, j );
        unsigned char *dataUPtr = imU( boundaries.x / 2, j / 2 );
        unsigned char *dataVPtr = imV( boundaries.x / 2, j / 2 );

        for( int i = boundaries.x; i < boundaries.x + boundaries.width; i += subsample )
        {
            histo( dataYPtr[0] >> shiftbits, 0 )++;
            histo( dataUPtr[0] >> shiftbits, 1 )++;
            histo( dataVPtr[0] >> shiftbits, 2 )++;

            dataYPtr += subsample;
            dataUPtr += subsample2;
            dataVPtr += subsample2;
        }
    }

    return histo;
}

Histogram Statistics::evaluateHWHistogram( const HistogramConfig &histoCfg, const Hal::Statistics &stats )
{
    dprintf( 4, "bins %d\n", stats.histogramBins );

    const int buckets  = stats.histogramBins;
    const int channels = 4; //RGrGbB
    const Rect region( stats.histogramWindow[0], stats.histogramWindow[2],
                       stats.histogramWindow[1], stats.histogramWindow[3] );

    Histogram histo( buckets, channels, region, RGrGbB );
    for( unsigned int bin = 0; bin < buckets; bin++ )
    {
        histo( bin, 0 ) = stats.histogramBayer[bin][0];
        histo( bin, 1 ) = stats.histogramBayer[bin][1];
        histo( bin, 2 ) = stats.histogramBayer[bin][2];
        histo( bin, 3 ) = stats.histogramBayer[bin][3];
    }

    return histo;
}

}
}
