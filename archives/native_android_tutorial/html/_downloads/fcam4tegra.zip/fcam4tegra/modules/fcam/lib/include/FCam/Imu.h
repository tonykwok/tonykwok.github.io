/* Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef FCAM_IMU_H
#define FCAM_IMU_H

/** \file
 * An abstract base class for IMU devices.
 *
 * The device may implement one or more of the following sensors:
 *   Gyroscope - Reports angular velocity in three axes.  Units are
 *     radians/second.  Tags are "gyroX", "gyroY", and "gyroZ".
 *   Accelerometer - Reports acceleration in three axes.  Units are meters/s^2.
 *     Tags are "accX", "accY", "accZ".
 *   Orientation - A sensor (generally a synthetic sensor implemented in
 *     software) which provides orientation as a
 *     <a href=http://en.wikipedia.org/wiki/Quaternion_rotation>quaternion</a>.
 *     Tags are "quat1", "quat2", "quat3", and "quat4", corresponding to the
 *     four elements of a quaternion.
 *
 * Tags are vectors of floats, and all vectors for a given sensor type are
 * guaranteed to have the same length.
 */

#include "Device.h"

namespace FCam
{
class Imu : public Device
{
public:
    // Methods common to all devices
    virtual void tagFrame( Frame ) = 0;
    virtual void handleEvent( const Event &e ) = 0;

    /** Possible sensor types */
    enum ImuSensor
    {
        GYRO,
        ACCELEROMETER,
        ORIENTATION
    };

    /** Determines whether or not a particular sensor type is available.
     * \return True if the specified sensor type is available, false
     * otherwise.
     */
    virtual bool available( ImuSensor s ) = 0;

    /** Enables a sensor.
     *  Enables the specified sensor type, so that future frames will be
     *  tagged with data for this sensor.
     */
    virtual void enable( ImuSensor s ) = 0;

    /** Disables a sensor.
     * Disables the specified sensor type, so that future frames will not
     * be tagged with data from this sensor.  Depending on the
     * implementation, this may or may not physically disable the
     * underlying hardware device.
     */
    virtual void disable( ImuSensor s ) = 0;

    /** Sets a sampling rate hint.
     * Sets the desired number of samples per second, which determines the
     * number of samples returned in the tag.  This is only a hint, and the
     * implementation may return a different number of samples, or may
     * interpolate data to make up the requested number of samples.
     * Setting the rate to 0 forces the device to return exactly 1 sample
     * per frame.
     * \param rate Sample rate, in samples/second.
     */
    virtual void setRate( int rate ) = 0;
};

} // END FCam namespace

#endif
