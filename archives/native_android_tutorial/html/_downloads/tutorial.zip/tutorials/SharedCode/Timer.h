//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef TIMER_H_
#define TIMER_H_

#include <stack>
#include <stdint.h>

/**
 * @file
 * Definition of Timer.
 */

/**
 * High-precision timer implementation. The time between function calls
 * can be measured in two ways: by measuring absolute time increments
 * with get() function or by calling matlab style tic()/toc() functions.
 */
class Timer
{
public:
    /**
     * Default constructor.
     */
    Timer( void );

    /**
     * Default destructor.
     */
    ~Timer( void )
    {
    }
    /**
     * Gets current time value and pushes it on the stack.
     */
    void tic( void );

    /**
     * Measures time between toc() and last call to tic(). Technically the function
     * pops the tic() time from the stack and returns a different between current time
     * and tic() value.
     * @return time difference between toc() and last call to tic()
     */
    double toc( void );

    /**
     * Gets the absolute time that has passed since the
     * construction of this Timer object (in milliseconds).
     * @return time in milliseconds
     */
    double get( void );

private:
    int64_t mStartupTime; /**< Start-up time */
#ifdef _WIN32
    double mFrequency; /**< Inverse of timer frequency */
#endif
    std::stack<int64_t> mTimeStampStack; /**< Stack storing time stamps of tic() calls */
};

#endif /* TIMER_H_ */
