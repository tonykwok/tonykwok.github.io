//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef UNITTESTDRIVER_H_
#define UNITTESTDRIVER_H_

#include <jni.h>
#include <gtest/gtest.h>
#include <sstream>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <pthread.h>

class UnitTestDriver: public ::testing::EmptyTestEventListener
{
public:
    UnitTestDriver( JNIEnv * env, jobject thiz, jobject jAssetManager );
    ~UnitTestDriver();

    // Set the output directory
    void setOutputDirectory( const char * aOutputDir );

    // creates the worker thread
    void launchWorkerThread();

    // worker thread entry point
    void run();

    //
    // GTest event listeners
    //

    // Called before a test starts.
    virtual void OnTestStart( const ::testing::TestInfo & test_info );

    // Called after a failed assertion or a SUCCEED() invocation.
    virtual void OnTestPartResult( const ::testing::TestPartResult & test_part_result );

    // Called after a test ends.
    virtual void OnTestEnd( const ::testing::TestInfo & test_info );

protected:

    // A convenience class to flush the log using str operators <<.
    class LogFlusher
    {
    public:
        LogFlusher( UnitTestDriver * parent )
            : mParent( parent )
        {}


        std::stringstream & operator()() const
        {
            mParent->flushLogStream();
            return mParent->logStream();
        }

    private:

        UnitTestDriver * mParent;
    };

    static void * workerFunc( void * arg );

    // Returns the stream we are using for logging
    std::stringstream & logStream();

    LogFlusher flush();

    // Flush the log
    void flushLogStream();

    // Attach thread to Java VM  and get the thread JNIEnv.
    void attachThread();

    // Detach thread from Java VM.
    void detachThread();

    // Calls the Java Activity to print the text
    void printToConsole( const std::string & text );

    // Calls the Java Activity to notify the thread finished.
    void notifyThreadCompletion();

    // Process Java VM
    JavaVM * mJavaVm;

    // Worker thread JNI Env.
    JNIEnv * mJniEnv;

    jobject mInstance;
    jmethodID mPrintToConsoleMethod;
    jmethodID mNotifyThreadCompletionMethod;

    // Asset manager object and reference
    jobject mAssetManagerRef;
    AAssetManager * mNativeAssetManager;

    // File output directory
    std::string mOutputDirectory;

    // Log stream
    std::stringstream mLogBuffer;

    // Worker thread handle
    pthread_t mWorkerThread;

    // Stores the test result
    int mTestResult;

    // Auxiliary function to flush the log using <<.
    friend std::stringstream & operator<<( std::basic_ostream<char> & stream, UnitTestDriver::LogFlusher flusher );
};

#endif /* UNITTESTDRIVER_H_ */
