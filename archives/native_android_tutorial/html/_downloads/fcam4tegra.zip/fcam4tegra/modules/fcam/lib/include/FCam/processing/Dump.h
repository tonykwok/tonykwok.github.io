/* Copyright (c) 1995-2010, Stanford University.
 * Copyright (c) 2011-2012, NVIDIA CORPORATION.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FCAM_DUMP_H
#define FCAM_DUMP_H

#include "../Frame.h"
#include <string>

/** \file
 * Loading and saving files as raw data dumps.
 */

namespace FCam
{

/** Save a UYVY, RGB24, or RAW dump file.
 * For saving uncompressed image data in a very basic image format:
 *  Header: 5 4-byte integers representing frames, width, height, channels, and type.
 *  Frames will always be 1. Type is either:
 *
 *  - 2 = 8-bit data, such as UYVY or RGB24 data.
 *  - 4 = 16-bit, such as RAW sensor pixel values, in a Bayer mosaic.
 *
 *  Channels will be 3 for RGB24, 2 for UYVY, 1 for RAW data.
 */

void saveDump( Frame frame, std::string filename );
void saveDump( Image frame, std::string filename );

/** Load a UYVY, RGB24, or RAW dump file. */
Image loadDump( std::string filename );

}

#endif
