/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef FCAM_TEGRA_CAMERA_HAL
#define FCAM_TEGRA_CAMERA_HAL

#include "ManagedObject.h"

/** \file
 * The main hal include file for FCam::Tegra. */

/* WARNING: This is the only hal header that the FCam
 * implementation will need to include. AVOID
 * dependencies on any non-NDK Android headers.
 * Must include Time.h before include this file.
 */

/* Expected usage:
 * 1. Grab a reference to an IProduct interface
 *     IProduct *prod = System::openProduct();
 * 2. Open a CameraHal instance:
 *     ICamera *camhal = prod->openCameraHal(....);
 *     you need to pass an ICameraObserver object that
 *     implements two functions: onFrame(...) and
 *     readyToCapture();
 *
 */

namespace FCam
{
namespace Tegra
{
namespace Hal
{

enum
{
    MAX_SENSORMODES         = 16,
};

enum FrameFormat
{
    YUV420p         = 0,
    RAW,
    UNKNOWN
};

enum StereoCamera
{
    STEREO_LEFT     = 0,
    STEREO_RIGHT    = 1,
    STEREO_BOTH     = 2
};

// This is an enum to simplify opening a specific camera
// Will be revisited when we implement proper camera enumeration
enum SystemCameraIndex
{
    CAMERA_MAIN       = 0,    // Main system camera, always present
    CAMERA_REAR          ,    // The rear camera, on stereo system this is also the left camera
    CAMERA_REAR_LEFT     ,    // On rear stereo capable system, the rear left camera
    CAMERA_REAR_RIGHT    ,    // On rear stereo capable system, the rear right camera
    CAMERA_REAR_STEREO   ,    // The rear stereo camera pair.
    CAMERA_FRONT         ,    // The front camera
    CAMERA_FRONT_LEFT    ,    // On front stereo capable systems, the front left  camera
    CAMERA_FRONT_RIGHT   ,    // On front stereo capable systems, the front right camera
    CAMERA_FRONT_STEREO  ,    // On front stereo capable systems, the stereo camera pair
    CAMERA_ARRAYSIZE
};

struct CameraFrameParams
{
    Time                   captureStartTime;    // Timestamp estimated the frame started.
    Time                   captureDoneTime;     // Timestamp reported by the driver at completion of frame
    Time                   fillBufferDoneTime;  // Timestamp for fillBufferDone call.
    int                    iso;                 // Queried iso at StillCaptureProcessing time
    int                    exposure;            // Queried exposure at StillCaptureProcessing time
    int                    wb;                  // Queried white balance at StillCaptureProcessing time
    int                    focusPos;            // focuser position at StillCaptureProcessing time
    int                    frameTime;           // Estimated frame time based on sensor mode.
};

struct CameraMode
{
    int  width;
    int  height;
    bool streaming;

    FrameFormat type;
    bool useGraphicBuffers;

    StereoCamera stereoMode;                     // Unused currently.

    CameraMode(): width( 0 ), height( 0 ),
        streaming( false ),
        type( UNKNOWN ),
        useGraphicBuffers( false ),
        stereoMode( STEREO_LEFT ) {};
};

struct Statistics
{
    unsigned int statsWindow[4];
    unsigned int meanBayer[4];
    unsigned int maxBayer[4];
    unsigned int clippedSensorLow;
    unsigned int clippedSensorHigh;

    unsigned int histogramWindow[4];
    unsigned int histogramBins;
    unsigned int histogramBayer[256][4];
};

struct CameraFrame
{
    unsigned char   *pBuffer;
    size_t  bufferSize;             // Number of bytes in the buffer
    size_t  bufferWidth;            // buffer width including padding
    size_t  bufferHeight;           // buffer height including padding
    size_t  width;                  // actual image width
    size_t  height;                 // actual image height
    FrameFormat format;
    CameraFrameParams params;
};

// Each Tegra platform can have a different imager/focuser.
// Define a set of structures to contain this information.
// Platform.cpp will include the corresponding platform definitions
// according to the makefile

/** A SensorConfig instance is returned to the Sensor. DO NOT
 *  use SensorConfig directly, use the Sensor functions instead.
 *  There is no guarantee that this class will be supported on
 *  future versions of the FCam::Tegra API. */
class SensorConfig
{
public:
    SensorConfig();
    struct ModeDesc
    {
        int width;
        int height;
        float fMinExposure;             // Min exposure in seconds
        float fMaxExposure;             // Max exposure in seconds
        float fMinFrameRate;            // Min frame rate
        float fMaxFrameRate;            // Max frame rate
        float fRowReadoutTime;          // Readout time.
    };

    ModeDesc modes[MAX_SENSORMODES];
    int      numberOfModes;

    float   fMinGain;
    float   fMaxGain;
    int     lensConfigIndex;            // Index of the lens config for this sensor
    int     exposureLatency;            // how many frames do we need to skip after setting the exposure
    int     gainLatency;                // how many frames do we need to skip after changing the gain.
    unsigned int sensorId;              // id of the hw sensor to use
    int     sensorMode;                 // sensor mode

    char   *psCameraName;               //
    int     cameraDirection;            // angle wrt to user control - 0 looks at user
};

/** A LensConfig instance is returned to the Lens. DO NOT
 *  use LensConfig directly, use the Lens member functions instead.
 *  There is no guarantee that this class will be supported on
 *  future versions of the FCam::Tegra API. */
class LensConfig
{
public:
    LensConfig();

    char   *psFocuserName;
    char   *psLensName;
    int     iFocusMinPosition;              // Min Tick
    int     iFocusMaxPosition;              // Max Tick
    float   fFarFocusDiopter;
    float   fNearFocusDiopter;
    float   fFocusDioptersPerTick;          // What is the change in diopters when we move the lens 1 tick
    float   fMinFocusSpeed;                 // Ticks per second
    float   fMaxFocusSpeed;                 // Ticks per second
    int     iFocusLatency;                  // In microseconds
    int     iFocusSettleTime;               // In microsecond
    float   fMinZoomFocalLength;            // In mm
    float   fMaxZoomFocalLength;            // In mm
    float   fMinZoomSpeed;
    float   fMaxZoomSpeed;
    int     iZoomLatency;
    float   fNarrowAperture;
    float   fWideAperture;
    float   fMinApertureSpeed;
    float   fMaxApertureSpeed;
    int     iApertureLatency;
};

class ICameraObserver
{
public:
    virtual void onFrame( CameraFrame *frame ) = 0;
    virtual void readyToCapture() = 0;

    virtual ~ICameraObserver() {};
};

class ICamera : public ManagedObject
{
public:

    ICamera( ICameraObserver *pObserver, unsigned int id ) {}

    virtual ~ICamera();

    virtual bool open() = 0;;
    virtual bool close() = 0;

    virtual const SensorConfig &getSensorConfig() = 0;
    virtual const LensConfig   &getLensConfig() = 0;

    /** Initiate a focuser change to position pos. Returns true if success, false otherwise*/
    virtual bool setFocuserPosition( int pos ) = 0;

    /** Request the current focuser position */
    virtual bool getFocuserPosition( int *pos ) = 0;

    /** Set sensor frame time in microsec - must fall in range of sensor's peak frame rate.
      * Use 0 for auto. In auto mode peak frame rate is favored by the camera driver, so exposure
      * time will be capped by this frame time*/
    virtual bool setSensorFrameTime( int frameTime ) = 0;

    /** Get sensor frame time in microsec*/
    virtual bool getSensorFrameTime( int *frameTime ) = 0;

    /** Set exposure time in microseconds. Use exposure -1 for AUTO */
    virtual bool setSensorExposure( int exposure ) = 0;

    /** Get exposure time in microseconds. Sets exposure == -1 for  AUTO*/
    virtual bool getSensorExposure( int *exposure ) = 0;

    /** Set the sensor gain. Use iso == -1 for AUTO */
    virtual bool setSensorEffectiveISO( int iso ) = 0;

    /** Get the sensor gain. Set iso == -1 for AUTO */
    virtual bool getSensorEffectiveISO( int *iso ) = 0;

    /** Set whitebalance temperature in Kelvin */
    virtual bool setISPWhiteBalance( int whiteBalance ) = 0;

    /** Get Image statistics */
    virtual bool getImageStatistics( Statistics *stats ) = 0;

    /** Sets up the capture for the current still image */
    virtual bool setCaptureMode( CameraMode m ) = 0;

    virtual float setFlashForStillCapture( float brightness, int duration ) = 0;

    /** Set the flash into torch mode with the given brightness.
     *  A brightness of 0 will turn the torch off.
     *  A brightness greater than 0 will turn the torch on and leave
     *  it on until a new call comes to turn it off.
     *  Returns the actual intensity the flash was set to */
    virtual float setFlashTorchMode( float brightness ) = 0;

    /** initiate single shot capture */
    virtual bool capture() = 0;
    virtual bool burstCapture( int numFrames ) = 0;
    virtual bool startStreaming() = 0;
    virtual bool stopStreaming() = 0;

    virtual float fps() = 0;
};

class IVideoEncoder : public ManagedObject
{
public:

    enum AVCLevel
    {
        AVCLevel31  = 0,
        AVCLevel32,
        AVCLevel40,
        AVCLevel41,
        AVCLevel42
    };

    struct Profile
    {
        int width;
        int height;
        int bps;
        AVCLevel level;
        int fps;
    };

    struct Frame
    {
        unsigned char   *pBuffer;
        size_t  bufferSize;
        int     width;
        int     height;
        FrameFormat format;
    };

    IVideoEncoder() {}
    virtual ~IVideoEncoder() {};

    virtual bool open() = 0;
    virtual bool close() = 0;
    virtual bool configureProfile( Profile profile ) = 0;

    virtual bool beginStream( const char *filename ) = 0;
    virtual bool endStream() = 0;

    // Encode a frame into the video stream.
    virtual bool encode( Frame buffer ) = 0;
};

class IImageEncoder : public ManagedObject
{
public:

    struct Profile
    {
        unsigned int width;
        unsigned int height;
        unsigned int quality;   // Quality 1-100

        /* Note - thumbnail is not currently supported */
        bool thumb_enable;
        unsigned int thumb_width;
        unsigned int thumb_height;
        unsigned int thumb_quality;
    };

    struct Frame
    {
        unsigned char   *pBuffer;
        size_t  bufferSize;
        unsigned int width;
        unsigned int height;
        FrameFormat format;
    };

    IImageEncoder() {}
    virtual ~IImageEncoder() {}

    virtual bool open() = 0;
    virtual bool close() = 0;
    virtual bool configureProfile( Profile profile ) = 0;

    // Encode a full sized image
    virtual bool encodeImage( const char *filename, Frame buffer ) = 0;

};

class IProduct : public ManagedObject
{
public:

    IProduct() {};
    virtual ~IProduct() {};

    virtual unsigned int numberOfCameras() = 0;

    // Returns the hal for the requested camera - if not such camera exists in this system
    // it return null.
    virtual managed_ptr<ICamera> getCameraHal( ICameraObserver *pObserver, SystemCameraIndex index ) = 0;

    // Returns the hal for the H264 encoder
    virtual managed_ptr<IVideoEncoder> getH264EncoderHal()
    {
        return managed_ptr<IVideoEncoder>();
    }

    // Returns the hal for the jpeg encoder
    virtual managed_ptr<IImageEncoder> getJPEGEncoderHal()
    {
        return managed_ptr<IImageEncoder>();
    }

};

class System
{
public:
    static managed_ptr<IProduct> openProduct( unsigned int hal = FCAM_HAL_VERSION );
};

}
}
}


#endif
