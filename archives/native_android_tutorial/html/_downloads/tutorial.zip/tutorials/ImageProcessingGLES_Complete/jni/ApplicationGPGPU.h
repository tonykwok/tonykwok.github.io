//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#ifndef APPLICATIONGPGPU_H_
#define APPLICATIONGPGPU_H_

#include <GLES2/gl2ext.h>
#include <nv_shader/nv_shader.h>
#include <nv_bitfont/nv_bitfont.h>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>
#include "Image.h"
#include "ImagePixelARGB32.h"
#include "BaseMath.h"
#include "Timer.h"
#include "ApplicationGLES.h"

// the size of image diff history buffer
#define MAX_HISTORY_SIZE       200

// stopping condition for the accumulation
// defines the texture size which is small enough
// for system memory download
#define MAX_TEXTURE_SIZE       128

// the timing interval length in msec
#define PERF_SAMPLING_INTERVAL 1000

class ApplicationGPGPU: public ApplicationGLES
{
public:
    // application state
    enum State
    {
        STATE_UNDEFINED, STATE_INIT, STATE_PROCESS, STATE_EXIT,
    };

    ApplicationGPGPU( struct android_app *app, NvEGLUtil *egl )
            : ApplicationGLES( app, egl )
    {
        mCurrentState = STATE_INIT;

        // initialize GLES handlers
        mWarpedDiffProgram = 0;
        mAccumProgram = 0;
        mPlainTextureProgram = 0;
        mPlainColorProgram = 0;

        mSourceImageTexture = 0;
        mImageDiffTexture = 0;
        mTempTexture1 = 0;
        mTempTexture2 = 0;

        mFBO = 0;
        mRBO = 0;
    }

    ~ApplicationGPGPU( void )
    {
        // clean-up fragment program
        if( mWarpedDiffProgram != 0 )
        {
            glDeleteProgram( mWarpedDiffProgram );
        }

        if( mAccumProgram != 0 )
        {
            glDeleteProgram( mAccumProgram );
        }

        if( mPlainColorProgram != 0 )
        {
            glDeleteProgram( mPlainColorProgram );
        }

        if( mPlainTextureProgram != 0 )
        {
            glDeleteProgram( mPlainTextureProgram );
        }

        // clean-up textures
        if( mSourceImageTexture != 0 )
        {
            glDeleteTextures( 1, &mSourceImageTexture );
        }

        if( mImageDiffTexture != 0 )
        {
            glDeleteTextures( 1, &mImageDiffTexture );
        }

        if( mTempTexture1 != 0 )
        {
            glDeleteTextures( 1, &mTempTexture1 );
        }

        if( mTempTexture2 != 0 )
        {
            glDeleteTextures( 1, &mTempTexture2 );
        }

        if( mRBO != 0 )
        {
            glDeleteRenderbuffers( 1, &mRBO );
        }

        if( mFBO != 0 )
        {
            glDeleteFramebuffers( 1, &mFBO );
        }
    }

    // compute difference image between an image and its perspective transformed copy
    void generateDifferenceImage( Math::Matrix4x4f const &transformMatrix )
    {
        // bind the FBO
        glBindFramebuffer( GL_FRAMEBUFFER, mFBO );

        // attach output texture to the framebuffer
        glFramebufferTexture2D( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, mImageDiffTexture, 0 );
        glViewport( 0, 0, mSourceImageWidth, mSourceImageHeight );

        // clear the output texture
        glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
        glClear( GL_COLOR_BUFFER_BIT );

        // activate warping fragment program
        glUseProgram( mWarpedDiffProgram );

        // setup uniforms
        glActiveTexture( GL_TEXTURE0 );
        glBindTexture( GL_TEXTURE_2D, mSourceImageTexture );

        glActiveTexture( GL_TEXTURE1 );
        glBindTexture( GL_TEXTURE_2D, mSourceImageTexture );

        glUniform1i( glGetUniformLocation( mWarpedDiffProgram, "uBaseTex" ), 0 );
        glUniform1i( glGetUniformLocation( mWarpedDiffProgram, "uWarpedTex" ), 1 );

        // scale quad to span from -1 to 1 in normalized device coordinate space
        Math::Matrix4x4f viewMatrix;
        viewMatrix.setScale( 2.0f );
        viewMatrix.applyTranslate( -1.0f );
        viewMatrix *= transformMatrix;

        // pass a normalizer for windows coordinates (gl_FragCoord), we need to access reference
        // unwarped image from warped image renderer
        glUniform2f( glGetUniformLocation( mWarpedDiffProgram, "uFragCoordNorm" ), 1.0f / mSourceImageWidth,
                     1.0f / mSourceImageHeight );

        glUniformMatrix4fv( glGetUniformLocation( mWarpedDiffProgram, "uTransformMatrix" ), 1, false,
                            viewMatrix.mData );

        // render difference image into a texture
        drawQuad( mWarpedDiffProgram );
    }

    void drawQuad( GLuint shader, float texCoordScale = 1.0f )
    {
        // 2D vertex position data
        float const vertPositionData[] =
        { 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f };

        // per vertex 2D coordinates inside the texture
        float const textureCoordData[] =
        { texCoordScale, texCoordScale, 0.0f, texCoordScale, texCoordScale, 0.0f, 0.0f, 0.0f };

        // drawing quad
        int attribPosCoord = glGetAttribLocation( shader, "aPosition" );
        int attribTexCoord = glGetAttribLocation( shader, "aTexCoord" );

        glVertexAttribPointer( attribPosCoord, 2, GL_FLOAT, GL_FALSE, 0, vertPositionData );
        glVertexAttribPointer( attribTexCoord, 2, GL_FLOAT, GL_FALSE, 0, textureCoordData );
        glEnableVertexAttribArray( attribPosCoord );
        glEnableVertexAttribArray( attribTexCoord );
        glDrawArrays( GL_TRIANGLE_STRIP, 0, 4 );
        glDisableVertexAttribArray( attribPosCoord );
        glDisableVertexAttribArray( attribTexCoord );
    }

    // scale-down and accumulate the difference image before downloading to system memory
    float getImageSimilarityMeasure( Math::Matrix4x4f const &transformMatrix )
    {
        // generate difference image
        generateDifferenceImage( transformMatrix );
        // bind the FBO
        glBindFramebuffer( GL_FRAMEBUFFER, mFBO );
        // activate the accumulation fragment program
        glUseProgram( mAccumProgram );
        glViewport( 0, 0, mSourceImageWidth, mSourceImageHeight );

        // setup uniforms
        glUniform2f( glGetUniformLocation( mAccumProgram, "uHalfTexelSize" ), 0.5f / mSourceImageWidth,
                     0.5f / mSourceImageHeight );

        glActiveTexture( GL_TEXTURE0 );
        glUniform1i( glGetUniformLocation( mAccumProgram, "uBaseTex" ), 0 );

        GLuint srcTexture = mImageDiffTexture;
        GLuint dstTexture = mTempTexture1;
        int srcWidth = mSourceImageWidth;
        int srcHeight = mSourceImageHeight;
        float dstScale = 1.0f;

        // ping-pong style accumulation
        while( srcWidth > MAX_TEXTURE_SIZE && srcHeight > MAX_TEXTURE_SIZE )
        {
            // attach output texture to the framebuffer
            glFramebufferTexture2D( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, dstTexture, 0 );

            // setup uniforms
            glBindTexture( GL_TEXTURE_2D, srcTexture );

            // set transformation matrix
            Math::Matrix4x4f viewMatrix;
            viewMatrix.setScale( dstScale );
            viewMatrix.applyTranslate( -1.0f );
            glUniformMatrix4fv( glGetUniformLocation( mAccumProgram, "uTransformMatrix" ), 1, false, viewMatrix.mData );

            // render difference image into a texture
            drawQuad( mAccumProgram, dstScale );

            // swap source with destination textures
            if( dstTexture == mTempTexture1 )
            {
                srcTexture = mTempTexture1;
                dstTexture = mTempTexture2;
            }
            else
            {
                srcTexture = mTempTexture2;
                dstTexture = mTempTexture1;
            }

            // next source texture will have dimensions of current destination
            srcWidth /= 2;
            srcHeight /= 2;

            // scale down the next destination
            dstScale *= 0.5f;
        }

        // output final pass to the RBO and read-back results

        // attach RBO to the FBO for final output
        glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, mRBO );

        // last accumulation shader call
        glBindTexture( GL_TEXTURE_2D, srcTexture );

        // set transformation matrix
        Math::Matrix4x4f viewMatrix;
        viewMatrix.setScale( dstScale );
        viewMatrix.applyTranslate( -1.0f );
        glUniformMatrix4fv( glGetUniformLocation( mAccumProgram, "uTransformMatrix" ), 1, false, viewMatrix.mData );

        // render difference image into a texture
        drawQuad( mAccumProgram, dstScale );

        // next source texture will have dimensions of current destination
        srcWidth /= 2;
        srcHeight /= 2;

        // read-back the result from current texture attached to the framebuffer
        Image<IPF_argb32> image( srcWidth, srcHeight );
        glReadPixels( 0, 0, srcWidth, srcHeight, GL_RGBA, GL_UNSIGNED_BYTE, image.getRawPointer() );

        // here we store final accumulated difference between images
        float diff = 0.0f;
        // sum up pixel differences over RGB channels
        int isize = srcWidth * srcHeight;
        for( int i = 0; i < isize; i++ )
        {
            ImagePixelARGB32 pixel( image[i] );
            diff += pixel[0];
            diff += pixel[1];
            diff += pixel[2];
        }

        // normalize by the number of accumulated samples
        diff /= isize * 3;

        // unbind FBO
        glBindFramebuffer( GL_FRAMEBUFFER, 0 );

        // restore the default viewport size
        glViewport( 0, 0, mEgl->getWidth(), mEgl->getHeight() );

        return diff;
    }

    static void RevertColorChannels( Image<IPF_argb32> &bitmap )
    {
        // converts BGRA to ARGB and back
        // we need it to convert between OpenGL and Windows Bitmap pixel formats
        int isize = bitmap.getWidth() * bitmap.getHeight();
        for( int i = 0; i < isize; i++ )
        {
            ImagePixelARGB32 pixel( bitmap[i] );
            bitmap[i] = ImagePixelARGB32( pixel[0], pixel[1], pixel[2], 255 );
        }
    }

    bool loadResources( void )
    {
        // initialize the NVIDIA bitfonts
        NvBool fontSplit = 1;
        const char *fontFile = "utahcond+bold_1024.dds";
        if( NVBFInitialize( 1, &fontFile, &fontSplit, 0 ) )
        {
            LOG( "could not initialize NvBitFont!" );
            return false;
        }

        // allocate the text for the clock and set its properties
        mClockText = NVBFTextAlloc();
        NVBFTextSetFont( mClockText, 1 ); // should look up by font file name.
        NVBFTextSetSize( mClockText, 32 );
        NVBFTextCursorAlign( mClockText, NVBF_ALIGN_LEFT, NVBF_ALIGN_TOP );
        NVBFTextCursorPos( mClockText, 10, 10 );
        NVBFTextSetColor( mClockText, NV_PC_PREDEF_WHITE );
        NVBFTextSetShadow( mClockText, 5, NV_PC_PREDEF_BLACK );

        // load test image
        glGenTextures( 1, &mSourceImageTexture );
        glBindTexture( GL_TEXTURE_2D, mSourceImageTexture );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
        {
            Image<IPF_argb32> bitmap;
            bitmap.loadImage( "lena.bmp" );

            // convert texture BGRA to RGBA OpenGL texture format
            RevertColorChannels( bitmap );

            mSourceImageWidth = bitmap.getWidth();
            mSourceImageHeight = bitmap.getHeight();
            LOG( "loaded %ix%i input image", mSourceImageWidth, mSourceImageHeight );

            glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, mSourceImageWidth, mSourceImageHeight, 0, GL_RGBA,
                          GL_UNSIGNED_BYTE, bitmap.getRawPointer() );
        }

        // setup output diff texture
        glGenTextures( 1, &mImageDiffTexture );
        glBindTexture( GL_TEXTURE_2D, mImageDiffTexture );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, mSourceImageWidth, mSourceImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                      0 );

        // setup temporary texture for accumulated difference image
        glGenTextures( 1, &mTempTexture1 );
        glBindTexture( GL_TEXTURE_2D, mTempTexture1 );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, mSourceImageWidth, mSourceImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                      0 );

        glGenTextures( 1, &mTempTexture2 );
        glBindTexture( GL_TEXTURE_2D, mTempTexture2 );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, mSourceImageWidth, mSourceImageHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE,
                      0 );

        // init shader loader
        nv_shader_init( mNativeAppInstance->activity->assetManager );

        // load image warping shader
        mWarpedDiffProgram = nv_load_program( "warped_diff" );
        // load difference accumulation shader
        mAccumProgram = nv_load_program( "accum4" );
        // load shader drawing textured quad
        mPlainTextureProgram = nv_load_program( "plain_tex" );
        // load shader drawing color filled quad
        mPlainColorProgram = nv_load_program( "plain_col" );

        // setup OpenGL
        glDisable( GL_CULL_FACE );
        glDisable( GL_BLEND );

        // create FBO
        glGenFramebuffers( 1, &mFBO );

        // create and configure RBO
        glGenRenderbuffers( 1, &mRBO );
        glBindRenderbuffer( GL_RENDERBUFFER, mRBO );
        glRenderbufferStorage( GL_RENDERBUFFER, GL_RGBA8_OES, mSourceImageWidth, mSourceImageHeight );

        return true;
    }

    bool runStateMachine( void )
    {
        // check if renderer is ready
        if( !mEgl->isReadyToRender( true ) )
        {
            return false;
        }

        // resize gl viewport size
        if( mEgl->checkWindowResized() )
        {
            LOG( "window resize!" );
            glViewport( 0, 0, mEgl->getWidth(), mEgl->getHeight() );
        }

        State nextState = STATE_UNDEFINED;
        switch( mCurrentState )
        {
        case STATE_INIT:
            // load and set up OpenGL resources
            if( !loadResources() )
            {
                // failed to initialize -> quit
                return true;
            }

            // start capturing samples for performance evaluation
            mTimingIntervalStart = mGlobalTimer.get();
            mLastComputeTime = 0;

            nextState = STATE_PROCESS;
            break;

        case STATE_PROCESS:
            // application idle state -> wait for the back button press to quit
            if( mIsExitRequested )
            {
                nextState = STATE_EXIT;
            }
            else
            {
                double time = mGlobalTimer.get();
                Math::Matrix4x4f transformMatrix;
                transformMatrix.setRotate(
                        Math::Quat( Math::Vec3f( 0.0f, 0.0f, 1.0f ), Math::Sinf( time * 0.001f ) * 10.0f ) );

                // flush the GL pipeline before measuring the timing
                glFinish();
                mGlobalTimer.tic();
                // get scalar image difference
                float diff = getImageSimilarityMeasure( transformMatrix );
                // store the time it took to execute the function
                glFinish();
                // flush the GL pipeline before measuring the timing
                mTimingSamples.push_back( mGlobalTimer.toc() );

                if( time - mTimingIntervalStart > PERF_SAMPLING_INTERVAL )
                {
                    // output to log the timing stats
                    std::sort( mTimingSamples.begin(), mTimingSamples.end() );

                    mLastComputeTime = mTimingSamples[mTimingSamples.size() / 2];
                    mTimingIntervalStart = time;
                    mTimingSamples.clear();
//                    LOG("%.3f", mLastComputeTime);
                }

                // store the difference in a history buffer for visualization
                mImageDifferenceHistory.push_back( diff );
                if( mImageDifferenceHistory.size() > MAX_HISTORY_SIZE )
                {
                    mImageDifferenceHistory.erase( mImageDifferenceHistory.begin() );
                }

                glClearColor( 0.5f, 0.5f, 0.5f, 1.0f );
                glClear( GL_COLOR_BUFFER_BIT );
                // render the difference image
                drawTexturedQuad( mImageDiffTexture, 1.0f );
                // render the difference history chart
                drawImageDifferenceHistoryChart();

                // render the rendering bitfont text overlaid here
                NVBFTextRenderPrep();

                char stringBuffer[128];
                sprintf( stringBuffer, "GPU render time: %.02fms\nImage difference: %.01f", mLastComputeTime,
                         mImageDifferenceHistory.back() );
                NVBFTextSetString( mClockText, stringBuffer );

                NVBFTextRender( mClockText );

                // done rendering overlaid text
                NVBFTextRenderDone();

                // make sure blending is disabled
                glDisable( GL_BLEND );

                mEgl->swap();
            }
            break;

        case STATE_EXIT:
            // application exit state
            break;
        }

        if( nextState != STATE_UNDEFINED )
        {
            // do state transition
            mCurrentState = nextState;
        }

        return mCurrentState == STATE_EXIT;
    }

    void drawImageDifferenceHistoryChart( void )
    {
        int bsize = mImageDifferenceHistory.size();
        if( bsize == 0 )
        {
            return;
        }

        // generate geometry
        float *vertData = new float[2 * 6 * bsize];
        float const stepX = 1.0f / mEgl->getWidth();
        float const stepY = 1.0f / mEgl->getHeight();

        float sx = 0.0f;
        int index = 0;
        for( int i = 0; i < bsize; i++ )
        {
            float value = mImageDifferenceHistory[i] * stepY;
            vertData[index + 0] = sx;
            vertData[index + 1] = 0;
            vertData[index + 2] = sx + stepX;
            vertData[index + 3] = 0;
            vertData[index + 4] = sx + stepX;
            vertData[index + 5] = value;

            vertData[index + 6] = sx + stepX;
            vertData[index + 7] = value;
            vertData[index + 8] = sx;
            vertData[index + 9] = value;
            vertData[index + 10] = sx;
            vertData[index + 11] = 0;

            sx += stepX;
            index += 2 * 6;
        }

        glUseProgram( mPlainColorProgram );

        // setup uniforms
        glUniform4f( glGetUniformLocation( mPlainColorProgram, "uColor" ), 0.3f, 0.3f, 0.3f, 1.0f );

        Math::Matrix4x4f mat;
        mat.setScale( 2.0f );
        mat.applyTranslate( -1.0f );
        glUniformMatrix4fv( glGetUniformLocation( mPlainColorProgram, "uTransformMatrix" ), 1, false, mat.mData );

        int attribPosCoord = glGetAttribLocation( mPlainColorProgram, "aPosition" );
        glVertexAttribPointer( attribPosCoord, 2, GL_FLOAT, GL_FALSE, 0, vertData );
        glEnableVertexAttribArray( attribPosCoord );
        glDrawArrays( GL_TRIANGLES, 0, 6 * bsize );
        glDisableVertexAttribArray( attribPosCoord );

        delete[] vertData;
    }

    float getWindowAspectRatio( void )
    {
        return (float) mEgl->getHeight() / mEgl->getWidth();
    }

    void drawTexturedQuad( GLuint texId, Math::Vec2f const &scale )
    {
        glUseProgram( mPlainTextureProgram );

        // setup uniforms
        glActiveTexture( GL_TEXTURE0 );
        glBindTexture( GL_TEXTURE_2D, texId );

        glUniform1i( glGetUniformLocation( mPlainTextureProgram, "uBaseTex" ), 0 );

        Math::Matrix4x4f mat;
        mat.setTranslate( -0.5f );
        mat.applyScale( Math::Vec2f( getWindowAspectRatio() * scale.x * 2.0f, scale.y * -2.0f ) );

        glUniformMatrix4fv( glGetUniformLocation( mPlainTextureProgram, "uTransformMatrix" ), 1, false, mat.mData );

        // render
        drawQuad( mPlainTextureProgram );
    }

private:
    // current application state
    State mCurrentState;

    // global timer instance
    Timer mGlobalTimer;
    double mTimingIntervalStart;
    float mLastComputeTime;
    std::vector<float> mTimingSamples;

    void *mClockText;

    // frame buffer object handler
    GLuint mFBO;
    // render buffer object handler
    GLuint mRBO;

    // fragment program handlers
    GLuint mWarpedDiffProgram;
    GLuint mAccumProgram;
    GLuint mPlainTextureProgram;
    GLuint mPlainColorProgram;

    // texture handlers
    GLuint mSourceImageTexture; // source image
    GLuint mImageDiffTexture; // difference image (between source and transformed images)
    GLuint mTempTexture1, mTempTexture2; // temporary textures used in the accumulation step

    // source image dimensions
    int mSourceImageWidth;
    int mSourceImageHeight;

    // vector storing accumulated difference history (for visualization)
    std::vector<float> mImageDifferenceHistory;
};

#endif /* APPLICATIONGPGPU_H_ */
