$NDKROOT/ndk-build NDK_PROJECT_PATH=$(pwd) NDK_MODULE_PATH=$(pwd)/.. PREBUILD=1 NDK_DEBUG=1 -j 4
echo Copying obj/local/armeabi-v7a/libFCam.a to prebuilt/debug/lib/armeabi-v7a/libFCam.a
cp obj/local/armeabi-v7a/libFCam.a prebuilt/debug/lib/armeabi-v7a/libFCam.a
echo Copying obj/local/armeabi-v7a/libjpeg.a to prebuilt/debug/lib/armeabi-v7a/libjpeg.a
cp obj/local/armeabi-v7a/libjpeg.a prebuilt/debug/lib/armeabi-v7a/libjpeg.a

