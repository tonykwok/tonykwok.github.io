var class_f_cam_1_1_platform =
[
    [ "~Platform", "class_f_cam_1_1_platform.html#ac776452d01272ffdb00a6912c8b33aa6", null ],
    [ "bayerPattern", "class_f_cam_1_1_platform.html#ab8749378b4fae43a67e38d6df203f104", null ],
    [ "rawToRGBColorMatrix", "class_f_cam_1_1_platform.html#a27f5a05dbbce12b78d0cc347bcbe1e3d", null ],
    [ "manufacturer", "class_f_cam_1_1_platform.html#a2bae5d38a6fdad63b94cf7acbdf6eb82", null ],
    [ "model", "class_f_cam_1_1_platform.html#af4d1561e22849aa6adcdebf4cf542955", null ],
    [ "minRawValue", "class_f_cam_1_1_platform.html#ae7b4fbf839de1528ddad49b69a65899c", null ],
    [ "maxRawValue", "class_f_cam_1_1_platform.html#ac79dcdd02f1ab48812f500acc904a335", null ]
];