//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef COMMON_H_
#define COMMON_H_

#ifdef ANDROID
#include <android/log.h>
#define LOG(x,...) __android_log_print(ANDROID_LOG_DEBUG,"tutorial",x,##__VA_ARGS__)
#else
#include <stdio.h>
#define LOG(x,...) fprintf(stdout,x"\n",##__VA_ARGS__)
#endif

typedef unsigned long ulong;
typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned char uchar;

#define NO_INLINE __attribute__ ((noinline))
#define FORCE_INLINE __attribute__((always_inline)) inline

#define CACHELINE_ALIGNMENT 64

#define GCC_VERSION (__GNUC__*10000+__GNUC_MINOR__*100+__GNUC_PATCHLEVEL__)
/* Test for GCC > 4.7.0 */
#if GCC_VERSION < 40700
#define __builtin_assume_aligned(x,s) (x)
#endif

void *_aligned_malloc( size_t size, size_t alignSize );
void _aligned_free( void *ptr );

// return an integer with last n bits as 1, other bits are 0
#define LAST_BITS(n)     ((1<<(n))-1)
// find the largest number aligned to b bits that is at most as large as n
#define ALIGN_END(n,b)   ((n)&~LAST_BITS(b))
// find how much to add to n to get to next number aligned to b bits
#define ALIGN_START(n,b) (((1<<(b))-(n))&LAST_BITS(b))
/*
 * a helper function that executes operator class over the specified range of elements
 * and automatically takes care of unaligned memory and length values which are not
 * multiple of vector size
 */
template<class T> FORCE_INLINE void RunVectorizedLoop( T const &processor, int loopStart, int loopEnd,
                                                       int baseOffset = 0 )
{
    // start address alignment fix
    int start0 = loopStart + ALIGN_START( baseOffset + loopStart, T::VECTOR_LOG2_LENGTH );
    if( start0 > loopEnd )
    {
        start0 = loopEnd;
    }
    // run scalar computation for unaligned elements
    processor.runScalarLoop( loopStart, start0, baseOffset );
    // vector count fix
    int end0 = start0 + ALIGN_END( loopEnd - start0, T::VECTOR_LOG2_LENGTH );
    // run vector computation for aligned elements
    processor.runVectorLoop( start0, end0, baseOffset );
    // run scalar computation for the remainder of elements
    processor.runScalarLoop( end0, loopEnd, baseOffset );
}

typedef void *(*THREAD_PROC)( void * );

template<typename T> struct ThreadData
{
    int taskStartIndex, taskEndIndex;
    int threadIndex;
    T const *params;
};

void RunThreads( THREAD_PROC proc, void *params, int taskCount, int threadCount );

#endif /* COMMON_H_ */
