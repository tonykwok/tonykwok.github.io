//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#include "Engine.h"

// Includes for GL and EGL
#include <EGL/egl.h>
#include <EGL/eglplatform.h>
#include <GLES2/gl2.h>

// Includes for the NVIDIA helper libraries
#include <nv_and_util/nv_native_app_glue.h>
#include <nv_egl_util/nv_egl_util.h>
#include <nv_bitfont/nv_bitfont.h>
#include <nv_shader/nv_shader.h>


Engine::Engine( NvEGLUtil &egl, struct android_app *app )
    : mEgl( egl ), mApp( app ), mResizePending( false ), mActiveMode( true ),
      mForceRender( FRAMES_TO_RENDER ), mUiInitialized( false )
{
    // Save a pointer to the engine in the Android app
    app->userData = this;

    // Save pointers to the implementation of the callback functions in the
    // Android app
    app->onAppCmd     = &Engine::handleCmdThunk;
    app->onInputEvent = &Engine::handleInputThunk;

    // Initialize the nv_shader library
    nv_shader_init( app->activity->assetManager );

    // Initialize the pointers to the bftext objects
    mUiText[0] = NULL;
    mUiText[1] = NULL;
}


Engine::~Engine()
{
    // Free the allocated BitFonts
    NVBFTextFree( mUiText[1] );
    NVBFTextFree( mUiText[0] );
    NVBFCleanup();
}


void Engine::handleCmdThunk( struct android_app *app, int32_t cmd )
{
    // Get a pointer to the Engine we stored in the Android app
    Engine *engine = ( Engine * ) app->userData;
    if( engine ) { engine->handleCommand( cmd ); }
}


void Engine::handleCommand( int cmd )
{
    switch( cmd )
    {
    case APP_CMD_INIT_WINDOW:
        // The window is being shown, get it ready.
        // Note that on ICS, the EGL size will often be correct for the new size here,
        // but on HC it will not be.  We need to defer checking the new res until the
        // first render with the new surface! Fall through to the window resize case.

    case APP_CMD_WINDOW_RESIZED:
        // A command to resize the window was issued, we need to
        // redraw it with its new size.
        mEgl.setWindow( mApp->window );
        requestForceRender();
        break;

    case APP_CMD_TERM_WINDOW:
        // The window is being hidden or closed, clean it up.
        mEgl.setWindow( NULL );
        break;

    case APP_CMD_GAINED_FOCUS:
        // The app window gained focus we need to start rendering it.
        requestForceRender();
        break;

    case APP_CMD_LOST_FOCUS:
        // The app window lost focus so we need to pause it.
        // Fall through to the command pause case.

    case APP_CMD_PAUSE:
        // Move out of active mode if we are in it. But if we are
        // in another dialog mode, leave it as-is.
        if( mActiveMode )
        {
            setActiveMode( false );
        }
        // Note that we still want to render in background.
        requestForceRender();
        break;

    case APP_CMD_CONFIG_CHANGED:
        // ICS does not appear to require this, but on GB phones,
        // not having this causes rotation changes to be delayed or
        // ignored when we're in a non-rendering mode like autopause.
        // The forced renders appear to allow GB to process the rotation.
        requestForceRender();
        break;
    }
}


/**
 * Process the next input event.
 */
int32_t Engine::handleInputThunk( struct android_app *app, AInputEvent *event )
{
    // Get a pointer to the Engine we stored in the Android app
    Engine *engine = ( Engine * ) app->userData;
    if( !engine ) { return 0; }
    return engine->handleInput( event );
}


int Engine::handleInput( AInputEvent *event )
{
    // We only handle motion events (touchscreen) and key (button/key) events
    int32_t eventType = AInputEvent_getType( event );

    if( eventType == AINPUT_EVENT_TYPE_MOTION )
    {
        int32_t action = AMOTION_EVENT_ACTION_MASK & AMotionEvent_getAction( ( const AInputEvent * ) event );

        // A tap on the screen takes us out of autopause into active mode if
        // we were paused.  No other touch processing is done.
        if( action == AMOTION_EVENT_ACTION_DOWN )
        {
            setActiveMode( true );
            return 0;
        }

        mTouchX = AMotionEvent_getX( event, 0 );
        mTouchY = AMotionEvent_getY( event, 0 );

        return 1;
    }
    else if( eventType == AINPUT_EVENT_TYPE_KEY )
    {
        int32_t code = AKeyEvent_getKeyCode( ( const AInputEvent * ) event );

        // If we are in active mode, we eat the back button and move into
        // pause mode.  If we are already in pause mode, we allow the back
        // button to be handled by the OS, which means we'll be shut down.
        if( ( code == AKEYCODE_BACK ) && mActiveMode )
        {
            setActiveMode( false );
            return 1;
        }
    }
    return 0;
}


void Engine::updateFrame( bool interactible )
{
    if( interactible )
    {
        // Each frame, we check to see if the window has resized.  While the
        // various events we get _should_ cover this, in practice, it appears
        // that the safest move across all platforms and OSes is to check at
        // the top of each frame.
        checkWindowResized();

        // Time stands still when we're auto-paused, and we don't
        // automatically render.
        if( mActiveMode )
        {
            // This will try to set up EGL if it isn't set up.
            // When we first set up EGL completely, we also load our GLES resources.
            // If these are already set up or we succeed at setting them all up now, then
            // we go ahead and render.
            renderFrame( true );
        }
        else if( isForcedRenderPending() ) // forced rendering when needed for UI, etc.
        {
            // This forces to change the text when paused.
            renderFrame( true );
        }
    }
    else
    {
        // Even if we are not interactive, we may be visible, so we
        // HAVE to do any forced renderings if we can.  We must also
        // check for resize, since that may have been the point of the
        // forced render request in the first place!

        // Basically it still renders even if the application is not in focus.
        if( isForcedRenderPending() && mEgl.isReadyToRender( false ) )
        {
            checkWindowResized();
            renderFrame( false );
        }
    }
}


bool Engine::renderFrame( bool allocateIfNeeded )
{
    // Check that EGL is ready to render. If allocateIfNeeded
    // try to also allocate the rendering surface and bind it
    // to the context.
    if( !mEgl.isReadyToRender( allocateIfNeeded ) )
    {
        return false;
    }

    // Make sure that the UI is initialized
    if( !initUI() )
    {
        LOGW( "Could not initialize UI - assets may be missing!" );
        ANativeActivity_finish( mApp->activity );
        return false;
    }
    resizeIfNeeded();

    // Set up viewport
    glViewport( ( GLint ) 0, ( GLint ) 0,
                ( GLsizei )( mEgl.getWidth() ), ( GLsizei )( mEgl.getHeight() ) );

    // Set the clear color...
    glClearColor( ( ( float ) mTouchX ) / ( ( float ) mEgl.getWidth() ), 0,
                  ( ( float ) mTouchY ) / ( ( float ) mEgl.getHeight() ), 1 );
    // ...and clear.
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    /* Do some rendering here */
    // ...

    // Render the bitfont text overlaid here
    NVBFTextRenderPrep();
    void *uiText = mUiText[mActiveMode ? 1 : 0];
    if( uiText ) { NVBFTextRender( uiText ); }

    // Done rendering overlaid text.
    NVBFTextRenderDone();

    if( mForceRender > 0 ) { mForceRender--; }

    // Swap the buffers, which indicates we're done with rendering this frame
    mEgl.swap();

    return true;
}


bool Engine::initUI()
{
    // The UI might have been initialized already
    if( mUiInitialized ) { return true; }

    LOGD( "Initializing UI" );

    // Initialize the NVIDIA bitfonts
    const int NUM_FONTS = 2;
    static NvBool fontsSplit[NUM_FONTS] = { 1, 1 }; // all are split
    static const char *fontFiles[NUM_FONTS] = { "courier+lucida_256.dds", "utahcond+bold_1024.dds" };
    if( NVBFInitialize( NUM_FONTS, ( const char ** ) fontFiles, fontsSplit, 0 ) )
    {
        LOGW( "Could not initialize NvBitFont" );
        return false;
    }

    // Allocate the text for the paused mode and set its properties
    mUiText[0] = NVBFTextAlloc();
    NVBFTextSetFont( mUiText[0], 2 ); // should look up by font file name
    NVBFTextSetSize( mUiText[0], 32 );
    NVBFTextSetColor( mUiText[0], NV_PC_PREDEF_WHITE );
    NVBFTextSetString( mUiText[0],
                       NVBF_COLORSTR_RED NVBF_STYLESTR_BOLD "Auto-pause:\n" NVBF_STYLESTR_NORMAL
                       NVBF_COLORSTR_BLUE "Press back to quit\nTap window to resume" );

    // Allocate the text for the active mode and set its properties
    mUiText[1] = NVBFTextAlloc();
    NVBFTextSetFont( mUiText[1], 2 ); // should look up by font file name
    NVBFTextSetSize( mUiText[1], 32 );
    NVBFTextSetColor( mUiText[1], NV_PC_PREDEF_WHITE );
    NVBFTextSetString( mUiText[1], NVBF_COLORSTR_GREEN "Active mode!" );

    mUiInitialized = true;

    return true;
}


bool Engine::resizeIfNeeded()
{
    // Do we need to resize?
    if( !mResizePending ) { return false; }

    // Get the target height and width
    int w = mEgl.getWidth();
    int h = mEgl.getHeight();
    int textHeight = ( w > h ) ? ( h / 16 ) : ( w / 16 );

    // Change the resolution to the correct width and height
    NVBFSetScreenRes( w, h );

    // Also update the size of the characters and their location
    if( mUiText[0] )
    {
        NVBFTextSetSize( mUiText[0], textHeight );
        NVBFTextCursorAlign( mUiText[0], NVBF_ALIGN_CENTER, NVBF_ALIGN_BOTTOM );
        NVBFTextCursorPos( mUiText[0], w / 2, h / 2 );
    }
    if( mUiText[1] )
    {
        NVBFTextSetSize( mUiText[1], textHeight );
        NVBFTextCursorAlign( mUiText[1], NVBF_ALIGN_CENTER, NVBF_ALIGN_CENTER );
        NVBFTextCursorPos( mUiText[1], w / 2, h / 2 );
    }

    mResizePending = false;

    return true;
}


void Engine::setActiveMode( bool running )
{
    if( mActiveMode != running )
    {
        requestForceRender();
    }
    mActiveMode = running;
}


bool Engine::checkWindowResized()
{
    if( mEgl.checkWindowResized() )
    {
        mResizePending = true;
        requestForceRender();
        LOGI( "Window size change %dx%d", mEgl.getWidth(), mEgl.getHeight() );
        return true;
    }
    return false;
}

