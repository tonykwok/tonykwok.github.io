//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef FCAM_BEEPER_H
#define FCAM_BEEPER_H

/** \file */

#include <string>

#include <FCam/FCam.h>
#include <FCam/Action.h>
#include <FCam/Device.h>

// for native asset manager
#include <sys/types.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>

// for native audio
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>


/*
 * A synchronized beeper example. As a device,
 * it inherits from FCam::Device, and declares
 * nested classes that inherit from CopyableAction
 */
class SoundPlayer : public FCam::Device
{

public:


    SoundPlayer( AAssetManager * mgr );
    ~SoundPlayer();

    /*
     * An action representing the playback of a .WAV file.
     */
    class SoundAction : public FCam::CopyableAction<SoundAction>
    {
    public:

        /* The enum to return as type() */
        enum
        {
            SoundPlay = CustomAction + 1,
        };

        /* Constructors and destructor */
        ~SoundAction();
        SoundAction( SoundPlayer * b );
        SoundAction( SoundPlayer * b, int time );
        SoundAction( const SoundAction & );

        /* Implementation of doAction() as required */
        void doAction();

        /* Load the specified file into buffer and prepares playback */
        void setAsset( const char * asset );

        /* Return the underlying device */
        SoundPlayer * getPlayer() const
        {
            return player;
        }

        int type() const
        {
            return SoundPlay;
        }

    protected:

        SoundPlayer * player;
        std::string assetname;
    };

    /* Normally, this is where a device would add metadata tags to a
     * just-created frame , based on the timestamps in the
     * Frame. However, we don't have anything useful to add here, so
     * tagFrame does nothing. */
    void tagFrame( FCam::Frame ) {}

    /* Play an application asset*/
    bool playAsset( const char * asset );

    /* Returns latency in microseconds */
    int getLatency();

    void handleEvent( const FCam::Event & ) {};

protected:

    static bool createEngine();
    static bool destroyEngine();

    // Asset manager..
    AAssetManager * mgr;

    // Acquired an engine ref
    bool acquiredEngineRef;

    // file descriptor player interfaces
    SLObjectItf fdPlayerObject;
    SLPlayItf fdPlayerPlay;
    SLSeekItf fdPlayerSeek;
    SLMuteSoloItf fdPlayerMuteSolo;
    SLVolumeItf fdPlayerVolume;
};

#endif

