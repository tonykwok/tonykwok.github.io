var class_f_cam_1_1_tegra_1_1_platform =
[
    [ "Platform", "class_f_cam_1_1_tegra_1_1_platform.html#a0c5819ff0f33ada30513ebf729b7c19a", null ],
    [ "~Platform", "class_f_cam_1_1_tegra_1_1_platform.html#ae8f7a50de57fe6c28fef41d3a4a7dfd2", null ],
    [ "bayerPattern", "class_f_cam_1_1_tegra_1_1_platform.html#ad3b1899d2e64ec3a26b33f78dde8d134", null ],
    [ "rawToRGBColorMatrix", "class_f_cam_1_1_tegra_1_1_platform.html#a2fb53c39fa62bd778618e9b4d281d045", null ],
    [ "manufacturer", "class_f_cam_1_1_tegra_1_1_platform.html#ab1b3a23e0a9f92d76184411dea89071f", null ],
    [ "model", "class_f_cam_1_1_tegra_1_1_platform.html#a81d83a242d33ec59d13a9a2b22320b87", null ],
    [ "minRawValue", "class_f_cam_1_1_tegra_1_1_platform.html#a1be4b5382b15f4b86e08d18d2d8879ad", null ],
    [ "maxRawValue", "class_f_cam_1_1_tegra_1_1_platform.html#a6ad8cd5cd6c5f829b0d698ac79455655", null ],
    [ "instance", "class_f_cam_1_1_tegra_1_1_platform.html#a848adba4370e19bfa8475481e0724844", null ]
];