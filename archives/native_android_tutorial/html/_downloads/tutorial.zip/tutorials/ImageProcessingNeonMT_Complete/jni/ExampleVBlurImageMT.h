//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef EXAMPLEVBLURIMAGEMT_H_
#define EXAMPLEVBLURIMAGEMT_H_

#include "ExampleVBlurImageNEON.h"

typedef struct
{
    // source and destination image size
    int width, height;
    // pointer to destination image data
    uint8_t *dst;
    // pointer to source image data
    uint8_t const *src;
} VBlurImage8Data;


static void *VBlurImage8ThreadProc( void *ptr )
{
    ThreadData<VBlurImage8Data> const *tdata = static_cast<ThreadData<VBlurImage8Data> const *>( ptr );
    VBlurImage8Data const *params = tdata->params;

    // invoke image processing on the image area assigned to the current thread
    VBlurImage8( params->dst, params->src, params->width, params->height, params->width, tdata->taskStartIndex,
                 tdata->taskEndIndex );
    return 0;
}


NO_INLINE
void VBlurImage8MT( uint8_t *dst, uint8_t const *src, int width, int height )
{
    // set up shared thread data (pointers to source and destination images and their size)
    VBlurImage8Data params;
    params.src    = src;
    params.dst    = dst;
    params.width  = width;
    params.height = height;

    // execute VBlurImage8ThreadProc() in parallel
    // the thread count is set to zero (auto-detect) and the granularity
    // of task is set to the number of image rows
    RunThreads( VBlurImage8ThreadProc, &params, height, 0 );
}


static void *VBlurImage8ThreadProcNEON( void *ptr )
{
    ThreadData<VBlurImage8Data> const *tdata = static_cast<ThreadData<VBlurImage8Data> const *>( ptr );
    VBlurImage8Data const *params = tdata->params;

    // invoke image processing on the image area assigned to the current thread
    VBlurImage8AlignedNEON( params->dst, params->src, params->width, params->height, params->width,
                            tdata->taskStartIndex, tdata->taskEndIndex );
    return 0;
}


NO_INLINE
void VBlurImage8NEON_MT( uint8_t *dst, uint8_t const *src, int width, int height )
{
    // set up shared thread data (pointers to source and destination images and their size)
    VBlurImage8Data params;
    params.src = src;
    params.dst = dst;
    params.width = width;
    params.height = height;

    // execute VBlurImage8ThreadProcNEON() in parallel
    // the thread count is set to zero (auto-detect) and the granularity
    // of task is set to the number of image rows
    RunThreads( VBlurImage8ThreadProcNEON, &params, height, 0 );
}


static void *VBlurImage8ThreadProcTiledNEON( void *ptr )
{
    ThreadData<VBlurImage8Data> const *tdata = reinterpret_cast<ThreadData<VBlurImage8Data> const *>( ptr );
    VBlurImage8Data const *params = tdata->params;

    // tile size set to 256x256 pixels
    int const tileSize = 256;

    // scan-line order for tile processing
    // TODO: space filling curve might improve the performance

    // row range
    int const startY = tdata->taskStartIndex;
    int const endY   = tdata->taskEndIndex;

    // image size
    int const imageWidth  = params->width;
    int const imageHeight = params->height;

    uint8_t const *src = params->src;
    uint8_t *dst       = params->dst;

    // iterate over rows of tiles
    for( int y = startY; y < endY; y += tileSize )
    {
        // clip end y coordinate of tiles in current row
        // if it goes out of valid row range
        int ey = y + tileSize;
        ey = ey > endY ? endY : ey;

        // iterate over a row of tiles
        for( int x = 0; x < imageWidth; x += tileSize )
        {
            // clip tile end x coordinate if it goes out of image
            int ex = x + tileSize;
            ex = ex > imageWidth ? imageWidth : ex;

            // execute NEON kernel for the current tile
            VBlurImage8AlignedNEON( dst + x, src + x, ex - x, imageHeight, imageWidth, y, ey );
        }
    }

    return 0;
}


NO_INLINE
void VBlurImage8NEON_MT_TILED( uint8_t *dst, uint8_t const *src, int width, int height )
{
    // set up shared thread data (pointers to source and destination images and their size)
    VBlurImage8Data params;
    params.src = src;
    params.dst = dst;
    params.width = width;
    params.height = height;

    // execute VBlurImage8ThreadProcTiledNEON() in parallel
    // the thread count is set to zero (auto-detect) and the granularity
    // of task is set to the number of image rows
    RunThreads( VBlurImage8ThreadProcTiledNEON, &params, height, 0 );
}

#endif /* EXAMPLEVBLURIMAGEMT_H_ */
