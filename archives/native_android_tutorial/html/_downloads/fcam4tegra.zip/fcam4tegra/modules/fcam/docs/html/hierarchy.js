var hierarchy =
[
    [ "FCam::Action", "class_f_cam_1_1_action.html", [
      [ "FCam::CopyableAction< ApertureAction >", "class_f_cam_1_1_copyable_action.html", [
        [ "FCam::Lens::ApertureAction", "class_f_cam_1_1_lens_1_1_aperture_action.html", null ]
      ] ],
      [ "FCam::CopyableAction< FireAction >", "class_f_cam_1_1_copyable_action.html", [
        [ "FCam::Flash::FireAction", "class_f_cam_1_1_flash_1_1_fire_action.html", null ]
      ] ],
      [ "FCam::CopyableAction< FocusAction >", "class_f_cam_1_1_copyable_action.html", [
        [ "FCam::Lens::FocusAction", "class_f_cam_1_1_lens_1_1_focus_action.html", null ]
      ] ],
      [ "FCam::CopyableAction< FocusSteppingAction >", "class_f_cam_1_1_copyable_action.html", [
        [ "FCam::Lens::FocusSteppingAction", "class_f_cam_1_1_lens_1_1_focus_stepping_action.html", null ]
      ] ],
      [ "FCam::CopyableAction< TorchAction >", "class_f_cam_1_1_copyable_action.html", [
        [ "FCam::Tegra::Flash::TorchAction", "class_f_cam_1_1_tegra_1_1_flash_1_1_torch_action.html", null ]
      ] ],
      [ "FCam::CopyableAction< ZoomAction >", "class_f_cam_1_1_copyable_action.html", [
        [ "FCam::Lens::ZoomAction", "class_f_cam_1_1_lens_1_1_zoom_action.html", null ]
      ] ],
      [ "FCam::CopyableAction< Derived >", "class_f_cam_1_1_copyable_action.html", null ]
    ] ],
    [ "FCam::AsyncFileWriter", "class_f_cam_1_1_async_file_writer.html", null ],
    [ "FCam::AutoFocus", "class_f_cam_1_1_auto_focus.html", [
      [ "FCam::Tegra::AutoFocus", "class_f_cam_1_1_tegra_1_1_auto_focus.html", null ]
    ] ],
    [ "FCam::Event", "class_f_cam_1_1_event.html", null ],
    [ "FCam::EventGenerator", "class_f_cam_1_1_event_generator.html", [
      [ "FCam::_Frame", "struct_f_cam_1_1___frame.html", [
        [ "FCam::_DNGFrame", "class_f_cam_1_1___d_n_g_frame.html", null ]
      ] ],
      [ "FCam::Device", "class_f_cam_1_1_device.html", [
        [ "FCam::Flash", "class_f_cam_1_1_flash.html", [
          [ "FCam::Tegra::Flash", "class_f_cam_1_1_tegra_1_1_flash.html", null ]
        ] ],
        [ "FCam::Lens", "class_f_cam_1_1_lens.html", [
          [ "FCam::Tegra::Lens", "class_f_cam_1_1_tegra_1_1_lens.html", null ]
        ] ],
        [ "FCam::Sensor", "class_f_cam_1_1_sensor.html", [
          [ "FCam::Tegra::Sensor", "class_f_cam_1_1_tegra_1_1_sensor.html", null ]
        ] ]
      ] ]
    ] ],
    [ "FCam::Flash::Tags", "class_f_cam_1_1_flash_1_1_tags.html", null ],
    [ "FCam::Frame", "class_f_cam_1_1_frame.html", [
      [ "FCam::DNGFrame", "class_f_cam_1_1_d_n_g_frame.html", null ],
      [ "FCam::Tegra::Frame", "class_f_cam_1_1_tegra_1_1_frame.html", null ]
    ] ],
    [ "FCam::Histogram", "class_f_cam_1_1_histogram.html", null ],
    [ "FCam::HistogramConfig", "class_f_cam_1_1_histogram_config.html", null ],
    [ "FCam::Image", "class_f_cam_1_1_image.html", null ],
    [ "FCam::Lens::Tags", "struct_f_cam_1_1_lens_1_1_tags.html", null ],
    [ "FCam::Platform", "class_f_cam_1_1_platform.html", [
      [ "FCam::_DNGFrame", "class_f_cam_1_1___d_n_g_frame.html", null ],
      [ "FCam::Tegra::Platform", "class_f_cam_1_1_tegra_1_1_platform.html", null ]
    ] ],
    [ "FCam::Rect", "struct_f_cam_1_1_rect.html", null ],
    [ "FCam::SharpnessMap", "class_f_cam_1_1_sharpness_map.html", null ],
    [ "FCam::SharpnessMapConfig", "class_f_cam_1_1_sharpness_map_config.html", null ],
    [ "FCam::Shot", "class_f_cam_1_1_shot.html", [
      [ "FCam::Tegra::Shot", "class_f_cam_1_1_tegra_1_1_shot.html", null ]
    ] ],
    [ "FCam::Size", "struct_f_cam_1_1_size.html", null ],
    [ "FCam::TagValue", "class_f_cam_1_1_tag_value.html", null ],
    [ "FCam::Tegra::Hal::LensConfig", "class_f_cam_1_1_tegra_1_1_hal_1_1_lens_config.html", null ],
    [ "FCam::Tegra::Hal::managed_ptr< T >", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr.html", null ],
    [ "FCam::Tegra::Hal::SensorConfig", "class_f_cam_1_1_tegra_1_1_hal_1_1_sensor_config.html", null ],
    [ "FCam::Time", "class_f_cam_1_1_time.html", null ],
    [ "FCam::TSQueue< T >", "class_f_cam_1_1_t_s_queue.html", null ],
    [ "FCam::Tegra::Hal::managed_ptr< Hal::ICamera >", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr.html", null ],
    [ "FCam::Tegra::Hal::managed_ptr< Hal::IImageEncoder >", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr.html", null ],
    [ "FCam::Tegra::Hal::managed_ptr< Hal::IProduct >", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr.html", null ],
    [ "FCam::Tegra::Hal::managed_ptr< Hal::IVideoEncoder >", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr.html", null ],
    [ "FCam::TSQueue< _Frame * >", "class_f_cam_1_1_t_s_queue.html", null ],
    [ "FCam::TSQueue< Frame >", "class_f_cam_1_1_t_s_queue.html", null ]
];