$NDKROOT/ndk-build NDK_MODULE_PATH=$(pwd)/.. NDK_PROJECT_PATH=$(pwd) PREBUILD=1 NDK_DEBUG=0 -j 4
echo Copying obj/local/armeabi-v7a/libFCam.a to prebuilt/release/lib/armeabi-v7a/libFCam.a
cp obj/local/armeabi-v7a/libFCam.a prebuilt/release/lib/armeabi-v7a/libFCam.a
echo Copying obj/local/armeabi-v7a/libjpeg.a to prebuilt/release/lib/armeabi-v7a/libjpeg.a
cp obj/local/armeabi-v7a/libjpeg.a prebuilt/release/lib/armeabi-v7a/libjpeg.a

