//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef _IMAGE_H
#define _IMAGE_H

#include "Common.h"
#include <string.h>

#define IP_MATH_EPSILON 1e-20f

class ImagePixelARGB32;

typedef enum
{
    IPF_char, IPF_uchar, IPF_short, IPF_ushort, IPF_int, IPF_uint, IPF_float, IPF_double, IPF_argb32
} ImagePixelFormat;

template<ImagePixelFormat> struct ImagePixelFormatTrait;
template<> struct ImagePixelFormatTrait<IPF_char>
{
    typedef char type;
};
template<> struct ImagePixelFormatTrait<IPF_uchar>
{
    typedef uchar type;
};
template<> struct ImagePixelFormatTrait<IPF_short>
{
    typedef short type;
};
template<> struct ImagePixelFormatTrait<IPF_ushort>
{
    typedef ushort type;
};
template<> struct ImagePixelFormatTrait<IPF_int>
{
    typedef int type;
};
template<> struct ImagePixelFormatTrait<IPF_uint>
{
    typedef uint type;
};
template<> struct ImagePixelFormatTrait<IPF_float>
{
    typedef float type;
};
template<> struct ImagePixelFormatTrait<IPF_double>
{
    typedef double type;
};
template<> struct ImagePixelFormatTrait<IPF_argb32>
{
    typedef ImagePixelARGB32 type;
};

// ======================================================================================================
// IMAGE CONTAINER
// ======================================================================================================

template<ImagePixelFormat T> class Image
{
public:
    typedef typename ImagePixelFormatTrait<T>::type PixelDataType;

    static ImagePixelFormat getPixelType()
    {
        return T;
    }

    Image( void )
            : mData( 0 ), mDataSize( 0 ), mWidth( 0 ), mHeight( 0 )
    {
    }

    Image( const Image<T> &t )
            : mData( 0 ), mDataSize( 0 ), mWidth( 0 ), mHeight( 0 )
    {
        ( *this ) = t;
    }

    template<ImagePixelFormat U> Image( const Image<U> &t )
            : mData( 0 ), mDataSize( 0 ), mWidth( 0 ), mHeight( 0 )
    {
        ( *this ) = t;
    }

    Image( int x, int y )
            : mData( 0 ), mDataSize( 0 ), mWidth( 0 ), mHeight( 0 )
    {
        set( x, y );
    }

    Image( int width, int height, PixelDataType *ptr )
            : mData( ptr ), mDataSize( 0 ), mWidth( width ), mHeight( height )
    {
    }

    ~Image( void )
    {
        if( mData != 0 && mDataSize != 0 )
        {
            _aligned_free( mData );
        }
    }

    Image<T> &operator=( Image<T> const &t )
    {
        set( t.mWidth, t.mHeight );

        if( t.mData != 0 )
        {
            memcpy( mData, t.mData, mWidth * mHeight * sizeof(PixelDataType) );
        }

        return *this;
    }

    template<ImagePixelFormat U> Image<T> &operator=( Image<U> const &t )
    {
        set( t.width(), t.height() );
        int isize = mWidth * mHeight;
        typename Image<U>::PixelDataType const *sptr =
                reinterpret_cast<typename Image<U>::PixelDataType const *>( __builtin_assume_aligned(t.getRawPointer(),
                        CACHELINE_ALIGNMENT) );
        PixelDataType *dptr = reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < isize; i++ )
        {
            dptr[i] = sptr[i];
        }

        return *this;
    }

    PixelDataType &operator()( int x, int y )
    {
        return mData[y * mWidth + x];
    }

    const PixelDataType &operator()( int x, int y ) const
    {
        return mData[y * mWidth + x];
    }

    PixelDataType &operator[]( int index )
    {
        return mData[index];
    }

    const PixelDataType &operator[]( int index ) const
    {
        return mData[index];
    }

    void operator*=( PixelDataType value )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] *= value;
        }
    }

    void operator+=( PixelDataType value )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] -= value;
        }
    }

    void operator-=( PixelDataType value )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] -= value;
        }
    }

    void operator*=( const Image<T> &t )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        PixelDataType const *__restrict sptr =
                reinterpret_cast<PixelDataType const *>( __builtin_assume_aligned(t.mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] *= sptr[i];
        }
    }

    void operator+=( const Image<T> &t )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        PixelDataType const *__restrict sptr =
                reinterpret_cast<PixelDataType const *>( __builtin_assume_aligned(t.mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] += sptr[i];
        }
    }

    void operator-=( const Image<T> &t )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        PixelDataType const *__restrict sptr =
                reinterpret_cast<PixelDataType const *>( __builtin_assume_aligned(t.mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] -= sptr[i];
        }
    }

    void set( int x, int y )
    {
        int newDataSize = x * y;
        if( newDataSize > mDataSize )
        {
            if( mData != 0 && mDataSize != 0 )
            {
                _aligned_free( mData );
            }

            mDataSize = newDataSize;
            mData = reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(
                    _aligned_malloc(sizeof(PixelDataType) * newDataSize, CACHELINE_ALIGNMENT), CACHELINE_ALIGNMENT) );
        }

        mWidth = x;
        mHeight = y;
    }

    void clear( PixelDataType value )
    {
        int size = mWidth * mHeight;
        PixelDataType *__restrict dptr =
                reinterpret_cast<PixelDataType *>( __builtin_assume_aligned(mData, CACHELINE_ALIGNMENT) );
        for( int i = 0; i < size; i++ )
        {
            dptr[i] = value;
        }
    }

    void copyTo( Image<T> &dest, int sx = 0, int sy = 0, int swidth = -1, int sheight = -1 )
    {
        if( swidth < 0 )
        {
            swidth = mWidth;
        }

        if( sheight < 0 )
        {
            sheight = mHeight;
        }

        if( swidth + sx > dest.mWidth )
        {
            swidth = dest.mWidth - sx;
        }

        if( sheight + sy > dest.mHeight )
        {
            sheight = dest.mHeight - sy;
        }

        int sindex = 0;
        int dindex = sy * dest.mWidth + sx;
        for( int y = 0; y < sheight; y++ )
        {
            memcpy( dest.mData + dindex, mData + sindex, swidth * sizeof(PixelDataType) );
            sindex += mWidth;
            dindex += dest.mWidth;
        }
    }

    void mirrorX( void )
    {
        int hh = mHeight >> 1;
        PixelDataType *buf = new PixelDataType[mWidth];

        for( int i = 0; i < hh; i++ )
        {
            PixelDataType *l1 = mData + i * mWidth;
            PixelDataType *l2 = mData + ( mHeight - 1 - i ) * mWidth;

            memcpy( buf, l1, mWidth * sizeof(PixelDataType) );
            memcpy( l1, l2, mWidth * sizeof(PixelDataType) );
            memcpy( l2, buf, mWidth * sizeof(PixelDataType) );
        }

        delete[] buf;
    }

    void swapSurface( Image<T> &b )
    {
        PixelDataType *tdata = mData;
        mData = b.mData;
        b.mData = tdata;

        int tmp = mDataSize;
        mDataSize = b.mDataSize;
        b.mDataSize = tmp;

        tmp = mWidth;
        mWidth = b.mWidth;
        b.mWidth = tmp;

        tmp = mHeight;
        mHeight = b.mHeight;
        b.mHeight = tmp;
    }

    void loadImage( const char *name );
    void writeImage( const char *name );

    const PixelDataType *getRawPointer( void ) const
    {
        return mData;
    }

    PixelDataType *getRawPointer( void )
    {
        return mData;
    }

    uint getAllocatedDataSize( void ) const
    {
        return mDataSize * sizeof(PixelDataType);
    }

    // SDBM hash function
#define HASH_BYTE(hash,c) ((c)+((hash)<<6)+((hash)<<16)-(hash))

    uint getDataHash( void ) const
    {
        if( mData == 0 )
        {
            return 0;
        }

        uchar const *ptr = reinterpret_cast<uchar const *>( mData );
        int length = sizeof(PixelDataType) * mWidth * mHeight;
        uint hash = 0;
        while( length != 0 )
        {
            uint c = *ptr++;
            hash = HASH_BYTE(hash, c);
            length--;
        }

        return hash;
    }

    int const &getWidth( void ) const
    {
        return mWidth;
    }

    int const &getHeight( void ) const
    {
        return mHeight;
    }

private:
    PixelDataType *__restrict mData;
    int mDataSize;
    int mWidth, mHeight;
};

#ifdef ANDROID
void SetupImageFileReader( struct android_app *app );
#endif

#endif
