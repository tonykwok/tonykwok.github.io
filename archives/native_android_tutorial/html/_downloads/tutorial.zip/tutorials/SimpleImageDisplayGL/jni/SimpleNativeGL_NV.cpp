//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

// EGL and GL includes
#include <EGL/egl.h>
#include <EGL/eglplatform.h>
#include <GLES2/gl2.h>

// NVIDIA helper includes
#include <android/log.h>
#include <nv_and_util/nv_native_app_glue.h>
#include <nv_egl_util/nv_egl_util.h>

#include <memory>

#include "Engine.h"

/**
 * This is the main entry point of a native application that is using
 * android_native_app_glue.  It runs in its own thread, with its own
 * event loop for receiving input events and doing other things.
 */
void android_main( struct android_app *app )
{
    // Make sure glue isn't stripped.
    app_dummy();

    std::unique_ptr<NvEGLUtil> egl( NvEGLUtil::create() );
    if( !egl )
    {
        // if we have a basic EGL failure, we need to exit immediately; nothing else we can do
        nv_app_force_quit_no_cleanup( app );
        return;
    }

    std::unique_ptr<Engine> engine( new Engine( *egl, app ) );

    long lastTime = egl->getSystemTime();

    // loop waiting for stuff to do.

    while( nv_app_status_running( app ) )
    {
        // Read all pending events.
        int ident;
        int events;
        struct android_poll_source *source;

        // If not rendering, we will block forever waiting for events.
        // If animating, we loop until all events are read, then continue
        // to draw the next frame of animation.
        while( ( ident = ALooper_pollAll( ( ( nv_app_status_focused( app ) && engine->isActiveMode() ) ? 1 : 250 ),
                                          NULL, &events, ( void ** ) &source ) ) >= 0 )
        {
            // If we timed out, then there are no pending messages.
            if( ident == ALOOPER_POLL_TIMEOUT ) { break; }

            // Process this event.
            if( source != NULL )                { source->process( app, source ); }

            // Check if we are exiting.  If so, dump out.
            if( !nv_app_status_running( app ) ) { break; }
        }

        long currentTime = egl->getSystemTime();

        // Clamp time - it must not go backwards, and we don't
        // want it to be more than a half second to avoid huge
        // delays causing issues.  Note that we do not clamp to above
        // zero because some tools will give us zero delta.
        long deltaTime = currentTime - lastTime;
        if     ( deltaTime < 0 )    { deltaTime = 0; }
        else if( deltaTime > 500 )  { deltaTime = 500; }
        lastTime = currentTime;

        // Update the frame, which optionally updates time and animations,
        // and renders.
        engine->updateFrame( nv_app_status_interactable( app ), deltaTime );
    }
}
