/* Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * Tegra hardware implementation of the IMU device, which uses the Android NDK
 * libraries to get data from the sensors.
 */

#include <cmath>
#include <string>
#include <pthread.h>
#include "FCam/Frame.h"
#include "FCam/Event.h"
#include "FCam/Tegra/Imu.h"

namespace FCam
{
namespace Tegra
{

int Imu::dummyCallback( int fd, int events, void *data )
{
    // The Looper code insists that we have a callback. If we put NULL, we
    // get a message "Invalid attempt to set NULL callback but not allowed
    // for this Looper".
    // We can't process the data here, since we don't have a timestamp
    return( 1 ); // Must return 1 to keep callback connected
    // TODO: What happens if we return 0?
}

Imu::Imu() :
    // Create empty circular buffers for the data
    mGyroHistory( HIST_LEN ), mAccHistory( HIST_LEN ), mOrientHistory( HIST_LEN ),
    // If mFusedOrientation is true, then the code will use the gyro and
    // accelerometer together to produce an orientation estimate.  On
    // devices where the accelerometer doesn't work (e.g, Cardhu with the
    // Invensense 5.x gyro driver), setting this to false will just integrate
    // the gyro and ignore the accelerometer.
    // Either way, the accelerometer tags will still be applied if enabled.
    mFusedOrientation( false )
{
    mLogData = false;
    mGyroLogFile = mAccLogFile = mOrientLogFile = NULL;
    mRate = 100;

    mGyroXBias = mGyroYBias = mGyroZBias = 0.0f;
    mCalibrating = false;

    ASensorManager *sensorManager = ASensorManager_getInstance();
    ASensorList sensors;
    int numSensors;

    // Print out a list of sensors visible to the NDK
    /*
    numSensors = ASensorManager_getSensorList(sensorManager, &sensors);
    for(int i = 0; i < numSensors && sensors[i] != NULL; i++){
        const ASensor* s = sensors[i];
        LOGI("Sensor - Type: %d, Name: %s, Vendor: %s, Min delay: %d",
                ASensor_getType(s), ASensor_getName(s), ASensor_getVendor(s),
                ASensor_getMinDelay(s));
    }
    //*/

    // Get the default sensors from Android
    const ASensor *gyro = ASensorManager_getDefaultSensor( sensorManager, ASENSOR_TYPE_GYROSCOPE );
    const ASensor *accelerometer = ASensorManager_getDefaultSensor( sensorManager, ASENSOR_TYPE_ACCELEROMETER );

    ALooper *looper = ALooper_prepare( 0 ); // Get the looper for our thread
    mGyroQueue = ASensorManager_createEventQueue( sensorManager, looper, GYRO_QUEUE,
                                                  Imu::dummyCallback, NULL );
    mAccQueue = ASensorManager_createEventQueue( sensorManager, looper, ACC_QUEUE,
                                                 Imu::dummyCallback, NULL );

    ASensorEventQueue_enableSensor( mGyroQueue, gyro );
    ASensorEventQueue_setEventRate( mGyroQueue, gyro, 0 );
    ASensorEventQueue_enableSensor( mAccQueue, accelerometer );
    ASensorEventQueue_setEventRate( mAccQueue, accelerometer, 0 );
    /*
            const ASensor* orientation = ASensorManager_getDefaultSensor(sensorManager, ASENSOR_TYPE_ROTATION_VECTOR);
            mOrientQueue = ASensorManager_createEventQueue(sensorManager, looper, ORIENTATION_QUEUE,
                    Imu::dummyCallback, NULL);
            ASensorEventQueue_enableSensor(mOrientQueue, orientation);
            ASensorEventQueue_setEventRate(mOrientQueue, orientation, 0);
    */
    // For some reason, we have to enable a rotation vector sensor or else
    // we won't get the full rate (or anything at all?) out.
    // So even if we're doing our own integration, enable the RV sensor.
    if( true )
    {
        //if(mFusedOrientation){
        // The default rotation vector sensor (from the Invensense MPL)
        // produces bad data, so use the Android sensor instead.
        // Unfortunately, that means we have to search for it.
        const ASensor *orientation = 0;
        numSensors = ASensorManager_getSensorList( sensorManager, &sensors );
        for( int i = 0; i < numSensors && sensors[i] != NULL; i++ )
        {
            const ASensor *s = sensors[i];
            if( ASensor_getType( s ) == ASENSOR_TYPE_ROTATION_VECTOR &&
                strcmp( ASensor_getVendor( s ), "Google Inc." ) == 0 )
            {
                orientation = s;
            }
        }
        mOrientQueue = ASensorManager_createEventQueue( sensorManager, looper,
                                                        ORIENTATION_QUEUE, Imu::dummyCallback, NULL );

        ASensorEventQueue_enableSensor( mOrientQueue, orientation );
        ASensorEventQueue_setEventRate( mOrientQueue, orientation, 0 );
    }

    // Mark all sensors on by default
    mGyroEnabled = mAccEnabled = mOrientEnabled = true;

    // Set up a thread to read data from the sensors.
    // We don't hold on to it, or try to pause it when the sensors are
    // disabled.  We just let it go, and we all die together when the
    // app closes.
    pthread_t thread;
    pthread_attr_t attr;
    pthread_attr_init( &attr );
    pthread_create( &thread, &attr, updateThread, ( void * )this );
}

Imu::~Imu()
{
    endLogging();
}

bool Imu::available( ImuSensor s )
{
    if( s == GYRO ||
        s == ACCELEROMETER ||
        s == ORIENTATION )
    {
        return true;
    }
    return false;
}

/**
 * Note that if logging is already running, the newly-enabled sensor will not be logged.
 */
void Imu::enable( ImuSensor s )
{
    if( s == GYRO ) { mGyroEnabled = true; }
    if( s == ACCELEROMETER ) { mGyroEnabled = true; }
    if( s == ORIENTATION ) { mGyroEnabled = true; }
}

void Imu::disable( ImuSensor s )
{
    if( s == GYRO ) { mGyroEnabled = false; }
    if( s == ACCELEROMETER ) { mAccEnabled = false; }
    if( s == ORIENTATION ) { mOrientEnabled = false; }
}

void Imu::setRate( int rate )
{
    if( rate < 0 )
    {
        mRate = 0;
    }
    else
    {
        mRate = rate;
    }
}

void *Imu::updateThread( void *obj )
{
    Imu *imu = ( Imu * )obj;
    while( 1 )
    {
        imu->update();
        // We don't have an exact timing constraint, so just give up
        // control for a while.
        // Would it be better to set a timer?  If nothing else is running,
        // does this end up running the CPU all the time, creating a busy wait?
        sched_yield();
    }
    return obj; // We'll never return
}

void Imu::update( void )
{
    // Drain events from the queues to the circular buffers
    ASensorEvent event;
    while( ASensorEventQueue_getEvents( mGyroQueue, &event, 1 ) > 0 )
    {
        // First, do calibration if requested
        if( mCalibrating )
        {
            doCalibration( event.acceleration.x, event.acceleration.y, event.acceleration.z );
        }

        GyroState s;
        // Convert the nanosecond count to seconds and microseconds
        s.time = Time( ( event.timestamp / 1000000000 ),
                       ( event.timestamp / 1000 ) % 1000000 ) - IMU_LAG;
        s.xVel = event.acceleration.x - mGyroXBias; // Gyro X angular velocity
        s.yVel = event.acceleration.y - mGyroYBias; // Gyro Y angular velocity
        s.zVel = event.acceleration.z - mGyroZBias; // Gyro Z angular velocity
        mGyroHistory.push( s );

        // Log the data to a file if we've been asked to
        if( mGyroEnabled && mGyroLogFile )
        {
            fprintf( mGyroLogFile, "%d, %06d, %0.3f, %0.3f, %0.3f\n",
                     s.time.s(), s.time.us(),
                     event.acceleration.x, event.acceleration.y, event.acceleration.z );
            // These are gyro values, but they are in the acceleration struct fields
        }

        if( !mFusedOrientation )
        {
            // If we're using the gyro alone for orientation, do the
            // integration and store the result.
            OrientationState o;
            if( mOrientHistory.size() > 0 )
            {
                o = integrateGyro( s, mOrientHistory[0] );
            }
            else
            {
                // There's nothing in the history, so initialize it
                o.time = s.time;
                o.q[0] = 1.0f;
                o.q[1] = o.q[2] = o.q[3] = 0.0f;
            }
            mOrientHistory.push( o );
            // Log the orientation just like any other
            if( mOrientEnabled && mOrientLogFile )
            {
                fprintf( mOrientLogFile, "%d, %06d, %0.5f, %0.5f, %0.5f, %0.5f\n",
                         o.time.s(), o.time.us(),
                         o.q[0], o.q[1], o.q[2], o.q[3] );
            }
        }
    }

    while( ASensorEventQueue_getEvents( mAccQueue, &event, 1 ) > 0 )
    {
        AccState s;
        s.time = Time( ( event.timestamp / 1000000000 ),
                       ( event.timestamp / 1000 ) % 1000000 ) - IMU_LAG;
        s.xAcc = event.acceleration.x;
        s.yAcc = event.acceleration.y;
        s.zAcc = event.acceleration.z;
        mAccHistory.push( s );

        if( mAccEnabled && mAccLogFile )
        {
            fprintf( mAccLogFile, "%d, %06d, %0.3f, %0.3f, %0.3f\n",
                     s.time.s(), s.time.us(),
                     event.acceleration.x, event.acceleration.y, event.acceleration.z );
        }
    }

    if( mFusedOrientation )
    {
        while( ASensorEventQueue_getEvents( mOrientQueue, &event, 1 ) > 0 )
        {
            OrientationState s;
            s.time = Time( ( event.timestamp / 1000000000 ),
                           ( event.timestamp / 1000 ) % 1000000 ) - IMU_LAG;
            rotationToQuaternion( event.data, s.q );
            mOrientHistory.push( s );

            if( mOrientEnabled && mOrientLogFile )
            {
                fprintf( mOrientLogFile, "%d, %06d, %0.5f, %0.5f, %0.5f, %0.5f\n",
                         s.time.s(), s.time.us(),
                         s.q[0], s.q[1], s.q[2], s.q[3] );
            }
        }
    }

    // Finally, cleanup the log files if logging has ended
    // We do this here to be sure that we're not busy writing them when the
    // file gets closed.
    if( !mLogData )
    {
        if( mGyroLogFile ) { fclose( mGyroLogFile ); }
        if( mAccLogFile ) { fclose( mAccLogFile ); }
        if( mOrientLogFile ) { fclose( mOrientLogFile ); }
        mGyroLogFile = mAccLogFile = mOrientLogFile = NULL;
    }
}

void Imu::tagFrame( FCam::Frame f )
{
    if( mGyroEnabled || mAccEnabled || mOrientEnabled )
    {
        /* First, calculate the number of intermediate points to return based
         * on the requested sample rate and the frame time.
         *
         * If interpPoints is 1, then a single interpolated sample will be
         * returned, which corresponds to the beginning of the exposure.
         * Otherwise, sample points will be placed at the beginning and end of
         * the exposure, and evenly spaced in between.
         */
        int nInterpPoints = ( f.exposureEndTime() - f.exposureStartTime() ) * mRate / 1000000;

        std::vector<Time> interpPoints;

        // Linearly space the interpolation points throughout the exposure time
        if( nInterpPoints <= 1 )
        {
            // One point is a special case. We'll also lump in zero and negative
            // values here, since there's nothing else reasonable to do with them.
            interpPoints.push_back( f.exposureStartTime() );
        }
        else
        {
            int step = ( f.exposureEndTime() - f.exposureStartTime() ) / ( nInterpPoints - 1 );
            for( int i = 0; i < nInterpPoints; i++ )
            {
                FCam::Time t = f.exposureStartTime() + ( step * i ); // Calculate the timestamp
                interpPoints.push_back( t );
            }
        }

        // Save the times as tags, so that the user can reference the results
        // to actual time values without having to guess.
        std::vector<int> timeOffsets;
        for( int i = 0; i < nInterpPoints; i++ )
        {
            timeOffsets.push_back( interpPoints[i] - f.exposureStartTime() );
        }
        f["imu.sampletime"] = timeOffsets;

        // Now tag the frames, if the sensors are enabled
        if( mGyroEnabled ) { tagGyro( f, interpPoints ); }
        if( mAccEnabled ) { tagAccelerometer( f, interpPoints ); }
        if( mOrientEnabled ) { tagOrientation( f, interpPoints ); }
    }

}

Imu::OrientationState Imu::integrateGyro( GyroState g, OrientationState prev )
{
    OrientationState now;
    now.time = g.time;
    float dt = now.time - prev.time;
    dt = dt / 1000000; // Convert from us to seconds

    float x = -g.xVel;
    float y =  g.yVel;
    float z =  g.zVel;

    // Integrate the gyro movements directly as a quaternion.
    // See the MATLAB script "quaternion_int.m" and the paper
    // http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.110.5134
    // for more details.
    now.q[0] = prev.q[0] + 0.5 * dt * ( x * -prev.q[1] + y * -prev.q[2] + z * -prev.q[3] );
    now.q[1] = prev.q[1] + 0.5 * dt * ( x *  prev.q[0] + y * -prev.q[3] + z *  prev.q[2] );
    now.q[2] = prev.q[2] + 0.5 * dt * ( x *  prev.q[3] + y *  prev.q[0] + z * -prev.q[1] );
    now.q[3] = prev.q[3] + 0.5 * dt * ( x * -prev.q[2] + y *  prev.q[1] + z *  prev.q[0] );

    // Normalize to keep a unit quaternion
    // If we were super-concerned about efficiency, we could do this only
    // once in a while, or only when the norm hit a threshold.
    float magnitude = sqrt( now.q[0] * now.q[0] + now.q[1] * now.q[1] +
                            now.q[2] * now.q[2] + now.q[3] * now.q[3] );
    now.q[0] = now.q[0] / magnitude;
    now.q[1] = now.q[1] / magnitude;
    now.q[2] = now.q[2] / magnitude;
    now.q[3] = now.q[3] / magnitude;
    return( now );
}

void Imu::handleEvent( const FCam::Event &e )
{ }

void Imu::tagGyro( Frame f, std::vector<Time> interpPoints )
{
    // Vectors which will eventually be applied as tags
    std::vector<float> xvals, yvals, zvals;

    // Make sure the IMU history isn't empty
    if( mGyroHistory.size() <= 0 )
    {
        for( size_t i = 0; i < interpPoints.size(); i++ )
        {
            xvals.push_back( 0.0f ); // Create a vector of zeros instead
        }
        f["imu.gyrox"] = f["imu.gyroy"] = f["imu.gyroz"] = xvals;
        error( Event::ImuHistoryError, "Gyro history is empty, can't tag frame!" );

        return;
    }

    // Using the list of times, calculate the actual value at each
    for( size_t point = 0; point < interpPoints.size(); point++ )
    {
        // Step backward through time (moving forward through the buffer)
        size_t i;
        for( i = 0; i < mGyroHistory.size(); i++ )
        {
            // If the desired time is earlier than this time, keep looking
            if( interpPoints[point] < mGyroHistory[i].time ) { continue; }

            // If not, then this is the sample immediately preceding
            if( i > 0 )
            {
                // If this isn't the first point, then we have two samples
                // to interpolate between. interp will be 0 if the point
                // equals the earlier sample; 1 if it equals the later.
                float interp = float( interpPoints[point] - mGyroHistory[i].time ) /
                               ( mGyroHistory[i - 1].time - mGyroHistory[i].time );
                // (1 - interp) * earlier + interp * later
                xvals.push_back( ( 1 - interp )*mGyroHistory[i].xVel + interp * mGyroHistory[i - 1].xVel );
                yvals.push_back( ( 1 - interp )*mGyroHistory[i].yVel + interp * mGyroHistory[i - 1].yVel );
                zvals.push_back( ( 1 - interp )*mGyroHistory[i].zVel + interp * mGyroHistory[i - 1].zVel );
                break;
            }
            else
            {
                // All samples in the history are older than what we're looking for,
                // so just use the latest sample without interpolation.
                // For low sample rates, this is not an uncommon occurrence, because
                // frames are generally tagged very quickly after they are shot.
                xvals.push_back( mGyroHistory[0].xVel );
                yvals.push_back( mGyroHistory[0].yVel );
                zvals.push_back( mGyroHistory[0].zVel );
            }
        } // END stepping through mGyroHistory
        if( i == mGyroHistory.size() )
        {
            // If we got to the end without finding a sample from before
            // our target time, then we ran out of history.  Use the oldest
            // sample without interpolation, and print a warning.
            xvals.push_back( mGyroHistory[mGyroHistory.size() - 1].xVel );
            yvals.push_back( mGyroHistory[mGyroHistory.size() - 1].yVel );
            zvals.push_back( mGyroHistory[mGyroHistory.size() - 1].zVel );

            error( Event::ImuHistoryError,
                   "Gyro reading at time %d %d is unknown - ran out of history",
                   interpPoints[point].s(), interpPoints[point].us() );
            /*
            LOGW("Requested: %d.%06d, latest: %d.%06d",
                 interpPoints[0].s(), interpPoints[0].us(),
                 mGyroHistory[i].time.s(), mGyroHistory[i].time.us());
            LOGW("EST: %d.%06d", f.exposureStartTime().s(), f.exposureStartTime().us());
            LOGW("EET: %d.%06d", f.exposureEndTime().s(), f.exposureEndTime().us());
            */
        }
    }

    // Now assign the vectors to the tags
    f["imu.gyrox"] = xvals;
    f["imu.gyroy"] = yvals;
    f["imu.gyroz"] = zvals;
}


void Imu::rotationToQuaternion( float *rot, float *quat )
{
    // We could equivalently do cos(asin(sqrt(x^2 + y^2 + z^2))), but
    // this is more computationally efficient.
    quat[0] = 1.0f - rot[0] * rot[0] - rot[1] * rot[1] - rot[2] * rot[2];
    quat[0] = quat[0] > 0 ? sqrt( quat[0] ) : 0;
    quat[1] = rot[0];
    quat[2] = rot[1];
    quat[3] = rot[2];
}


void Imu::tagAccelerometer( Frame f, std::vector<Time> interpPoints )
{
    // Vectors which will eventually be applied as tags
    std::vector<float> xvals, yvals, zvals;

    // Make sure the IMU history isn't empty
    if( mAccHistory.size() <= 0 )
    {
        for( size_t i = 0; i < interpPoints.size(); i++ )
        {
            xvals.push_back( 0.0f ); // Create a vector of zeros instead
        }

        f["imu.accx"] = f["imu.accy"] = f["imu.accz"] = xvals;
        error( Event::ImuHistoryError, "Accelerometer history is empty, can't tag frame!" );
        return;
    }

    // Now using the list of times, calculate the actual value at each
    for( size_t point = 0; point < interpPoints.size(); point++ )
    {
        // Step backward through time (moving forward through the buffer)
        size_t i;
        for( i = 0; i < mAccHistory.size(); i++ )
        {
            // If the desired time is earlier than this time, keep looking
            if( interpPoints[point] < mAccHistory[i].time ) { continue; }

            // If not, then this is the sample immediately preceding
            if( i > 0 )
            {
                // If this isn't the first point, then we have two samples
                // to interpolate between. interp will be 0 if the point
                // equals the earlier sample; 1 if it equals the later.
                float interp = float( interpPoints[point] - mAccHistory[i].time ) /
                               ( mAccHistory[i - 1].time - mAccHistory[i].time );
                // Just do linear interpolation here
                xvals.push_back( ( 1 - interp )*mAccHistory[i].xAcc + interp * mAccHistory[i - 1].xAcc );
                yvals.push_back( ( 1 - interp )*mAccHistory[i].yAcc + interp * mAccHistory[i - 1].yAcc );
                zvals.push_back( ( 1 - interp )*mAccHistory[i].zAcc + interp * mAccHistory[i - 1].zAcc );
                break;
            }
            else
            {
                // All samples in the history are older than what we're looking for,
                // so just use the latest sample without interpolation.
                // For low sample rates, this is not an uncommon occurrence, because
                // frames are generally tagged very quickly after they are shot.
                xvals.push_back( mAccHistory[0].xAcc );
                yvals.push_back( mAccHistory[0].yAcc );
                zvals.push_back( mAccHistory[0].zAcc );
            }
        } // END stepping through mAccHistory
        if( i == mAccHistory.size() )
        {
            // If we got to the end without finding a sample from before
            // our target time, then we ran out of history.  Use the oldest
            // sample without interpolation, and print a warning.
            xvals.push_back( mAccHistory[mAccHistory.size() - 1].xAcc );
            yvals.push_back( mAccHistory[mAccHistory.size() - 1].yAcc );
            zvals.push_back( mAccHistory[mAccHistory.size() - 1].zAcc );

            error( Event::ImuHistoryError,
                   "Accelerometer reading at time %d %d is unknown - ran out of history",
                   interpPoints[point].s(), interpPoints[point].us() );
        }
    }

    // Now assign the vectors to the tags
    f["imu.accx"] = xvals;
    f["imu.accy"] = yvals;
    f["imu.accz"] = zvals;
}


void Imu::tagOrientation( Frame f, std::vector<Time> interpPoints )
{
    // Vectors which will eventually be applied as tags
    // The FCam tag interface only supports vectors of floats, so make vectors
    // of quaternion elements.
    std::vector<float> q1, q2, q3, q4;

    // Make sure the history isn't empty
    if( mOrientHistory.size() <= 0 )
    {
        for( size_t i = 0; i < interpPoints.size(); i++ )
        {
            q1.push_back( 0.0f ); // Create a vector of zeros instead
        }
        f["imu.quat1"] = f["imu.quat2"] = f["imu.quat3"] = f["imu.quat4"] = q1;
        error( Event::ImuHistoryError, "Orientation history is empty, can't tag frame!" );

        return;
    }

    // Using the list of times, calculate the actual value at each
    for( size_t point = 0; point < interpPoints.size(); point++ )
    {
        float quat[4]; // Quaternion that will eventually be stored for this time
        // Step backward through time (moving forward through the buffer)
        size_t i;
        for( i = 0; i < mOrientHistory.size(); i++ )
        {
            // If the desired time is earlier than this time, keep looking
            if( interpPoints[point] < mOrientHistory[i].time ) { continue; }

            // If not, then this is the sample immediately preceding
            if( i > 0 )
            {
                // If this isn't the first point, then we have two samples
                // to interpolate between. interp will be 0 if the point
                // equals the earlier sample; 1 if it equals the later.
                float interp = float( interpPoints[point] - mOrientHistory[i].time ) /
                               ( mOrientHistory[i - 1].time - mOrientHistory[i].time );
                // Use linear interpolation to mix the orientations.
                // Since the orientations are very likely to be close together,
                // it isn't worth the extra complexity to use SLERP.
                float *qstart = mOrientHistory[i].q;
                float *qend = mOrientHistory[i - 1].q;
                quat[0] = ( 1 - interp ) * qstart[0] + interp * qend[0];
                quat[1] = ( 1 - interp ) * qstart[1] + interp * qend[1];
                quat[2] = ( 1 - interp ) * qstart[2] + interp * qend[2];
                quat[3] = ( 1 - interp ) * qstart[3] + interp * qend[3];
                break;
            }
            else
            {
                // All samples in the history are older than what we're looking for,
                // so just use the latest sample without interpolation.
                // For low sample rates, this is not an uncommon occurrence, because
                // frames are generally tagged very quickly after they are shot.
                quat[0] = mOrientHistory[0].q[0];
                quat[1] = mOrientHistory[0].q[1];
                quat[2] = mOrientHistory[0].q[2];
                quat[3] = mOrientHistory[0].q[3];
            }
        } // END stepping through mOrientationHistory
        if( i == mOrientHistory.size() )
        {
            // If we got to the end without finding a sample from before
            // our target time, then we ran out of history.  Use the oldest
            // sample without interpolation, and print a warning.
            quat[0] = mOrientHistory[mOrientHistory.size() - 1].q[0];
            quat[1] = mOrientHistory[mOrientHistory.size() - 1].q[1];
            quat[2] = mOrientHistory[mOrientHistory.size() - 1].q[2];
            quat[3] = mOrientHistory[mOrientHistory.size() - 1].q[3];
            error( Event::ImuHistoryError,
                   "Orientation reading at time %d %d is unknown - ran out of history",
                   interpPoints[point].s(), interpPoints[point].us() );

        }

        // Save the quaternion into the vectors
        q1.push_back( quat[0] );
        q2.push_back( quat[1] );
        q3.push_back( quat[2] );
        q4.push_back( quat[3] );
    }

    // Now assign the vectors to the tags
    f["imu.quat1"] = q1;
    f["imu.quat2"] = q2;
    f["imu.quat3"] = q3;
    f["imu.quat4"] = q4;
}


/**
 * Only sensors which are already enabled will be logged.
 */
void Imu::beginLogging( const std::string filepath )
{
    mLogData = true;
    // Close the files if they already exist
    if( mGyroLogFile ) { fclose( mGyroLogFile ); }
    if( mAccLogFile ) { fclose( mAccLogFile ); }
    if( mOrientLogFile ) { fclose( mOrientLogFile ); }

    // Build the file paths and open the files
    mGyroLogFile = fopen( ( filepath + "gyro.csv" ).c_str(), "w" );
    mAccLogFile = fopen( ( filepath + "acc.csv" ).c_str(), "w" );
    mOrientLogFile = fopen( ( filepath + "orient.csv" ).c_str(), "w" );

    // If the files successfully opened, write the CSV headers
    if( mGyroLogFile )
    {
        fprintf( mGyroLogFile, "sec, usec, gyroX, gyroY, gyroZ\n" );
    }
    if( mAccLogFile )
    {
        fprintf( mAccLogFile, "sec, usec, accX, accY, accZ\n" );
    }
    if( mOrientLogFile )
    {
        fprintf( mOrientLogFile, "sec, usec, quat1, quat2, quat3, quat4\n" );
    }
}

/* End logging of raw IMU data to a file. */
void Imu::endLogging( void )
{
    // Set the flag indicating that we are no longer logging data.
    // We don't actually close the file here, since the callback could be
    // currently executing, and we would cut it off partway through a
    // write.  Instead, the callback checks when the logging has stopped
    // and closes the files after it completes the write.
    mLogData = false;

}

void Imu::autoCalibration( int calSamples )
{
    mCalibrating = true;
    mCalibrationCount = 0;
    mCalibrationDesired = calSamples;
    mGyroXSum = mGyroYSum = mGyroZSum = 0.0f;
    mGyroXSquared = mGyroYSquared = mGyroZSquared = 0.0f;
}
void Imu::setCalibration( float xBias, float yBias, float zBias )
{
    mGyroXBias = xBias;
    mGyroYBias = yBias;
    mGyroZBias = zBias;
}

void Imu::getCalibration( float *xBias, float *yBias, float *zBias,
                          float *xVar, float *yVar, float *zVar )
{
    *xBias = mGyroXBias;
    *yBias = mGyroYBias;
    *zBias = mGyroZBias;

    // Calculate and return the variance
    // Var(X) = E[X - E[X]] = E[X^2] - E[X]^2
    // mGyro*Bias is the mean, i.e, E[X]
    *xVar = mGyroXSquared / mCalibrationCount - ( mGyroXBias * mGyroXBias );
    *yVar = mGyroYSquared / mCalibrationCount - ( mGyroYBias * mGyroYBias );
    *zVar = mGyroZSquared / mCalibrationCount - ( mGyroZBias * mGyroZBias );
}

void Imu::doCalibration( float x, float y, float z )
{
    if( mCalibrationCount < mCalibrationDesired )
    {
        // Calibration ongoing, add the values to the totals
        mGyroXSum += x;
        mGyroYSum += y;
        mGyroZSum += z;

        mGyroXSquared += ( x * x );
        mGyroYSquared += ( y * y );
        mGyroZSquared += ( z * z );
        mCalibrationCount++;
    }
    else
    {
        // Calibration is all done, save the values
        mGyroXBias = mGyroXSum / mCalibrationCount;
        mGyroYBias = mGyroYSum / mCalibrationCount;
        mGyroZBias = mGyroZSum / mCalibrationCount;
        mCalibrating = false;
    }
}

}
}
