//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#include <nv_shader/nv_shader.h>
#include "Image.h"
#include "ApplicationGPGPU.h"

/**
 * This is the main entry point of a native application that is using
 * android_native_app_glue.  It runs in its own thread, with its own
 * event loop for receiving input events and doing other things.
 */
void android_main( struct android_app *app )
{
    // Make sure glue isn't stripped
    app_dummy();
    SetupImageFileReader( app );

    // initialize EGL context
    std::unique_ptr<NvEGLUtil> egl( NvEGLUtil::create() );
    if( !egl )
    {
        // if we have a basic EGL failure, we need to exit immediately; nothing else we can do
        nv_app_force_quit_no_cleanup( app );
        return;
    }

    // initialize application class
    std::unique_ptr<ApplicationGPGPU> instance( new ApplicationGPGPU( app, egl.get() ) );

    while( nv_app_status_running( app ) )
    {
        // read all pending events.
        int ident;
        int events;
        struct android_poll_source *source;

        // if not rendering, we will block forever waiting for events.
        // if animating, we loop until all events are read, then continue
        // to draw the next frame of animation.
        while( ( ident = ALooper_pollAll( ( nv_app_status_focused( app ) ? 1 : 250 ), NULL, &events, (void **) &source ) )
                >= 0 )
        {
            // if we timed out, then there are no pending messages.
            if( ident == ALOOPER_POLL_TIMEOUT )
            {
                break;
            }

            // process this event.
            if( source != NULL )
            {
                source->process( app, source );
            }

            // check if we are exiting.  If so, dump out.
            if( !nv_app_status_running( app ) )
            {
                break;
            }
        }

        if( nv_app_status_interactable( app ) )
        {
            // run the application state machine
            if (instance->runStateMachine()) {
                // exit state reached -> quit application
                break;
            }
        }
    }

    nv_app_force_quit_no_cleanup( app );
}

