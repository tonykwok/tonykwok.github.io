#include <jni.h>
#include "com_nvidia_simplefcam_SimpleFCamActivity.h"
#include "simplefcam.h"

#ifdef __cplusplus
extern "C"
{
#endif

    jint JNI_OnLoad( JavaVM *vm, void *reserved )
    {

#if defined(WAIT_FOR_DEBUGGER)
        volatile int _dbg = 1;
        while( _dbg )
        {
        }
#endif

        return JNI_VERSION_1_2;
    }

    /*
     * Class:     com_nvidia_simplefcam_SimpleFCamActivity
     * Method:    launchNativeThread
     * Signature: (Ljava/lang/String;)V
     */JNIEXPORT void JNICALL Java_com_nvidia_simplefcam_SimpleFCamActivity_launchNativeThread( JNIEnv *env, jobject thiz,
            jstring joutputPath )
    {
        // Create a new SimpleFCam instance
        SimpleFCam *fcamApp = new SimpleFCam( env, thiz );

        // Set the output path string
        const char *outputPath = env->GetStringUTFChars( joutputPath, NULL );
        fcamApp->setOutputDirectory( outputPath );
        env->ReleaseStringUTFChars( joutputPath, outputPath );

        // Launch the worker thread that invokes the fcam code.
        // fcamApp will be deleted when the worker thread exits.
        fcamApp->launchWorkerThread();
    }

#ifdef __cplusplus
}
#endif
