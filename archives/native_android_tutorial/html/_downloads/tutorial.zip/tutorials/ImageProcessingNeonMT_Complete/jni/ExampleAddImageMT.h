//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifndef EXAMPLEADDIMAGEMT_H_
#define EXAMPLEADDIMAGEMT_H_

#include "ExampleAddImageNEON.h"

typedef struct
{
    // image width and height
    int width, height;
    // pointer to destination image data
    uint8_t *dst;
    // pointer to 1st source image data
    uint8_t const *src1;
    // pointer to 2nd source image data
    uint8_t const *src2;
} AddImage8Data;


static void *AddImage8ThreadProc( void *ptr )
{
    ThreadData<AddImage8Data> const *tdata = static_cast<ThreadData<AddImage8Data> const *>( ptr );
    AddImage8Data const *params = tdata->params;

    // compute start offset (tdata->taskStartIndex corresponds to image row number)
    int index = tdata->taskStartIndex * params->width;

    // invoke image processing on the image area assigned to the current thread
    AddImage8( params->dst + index, params->src1 + index, params->src2 + index, params->width,
               tdata->taskEndIndex - tdata->taskStartIndex );
    return 0;
}


NO_INLINE
void AddImage8MT( uint8_t *dst, uint8_t const *src1, uint8_t const *src2, int width, int height )
{
    AddImage8Data params;

    // set up shared thread data (pointers to source and destination images and their size)
    params.src1 = src1;
    params.src2 = src2;
    params.dst = dst;
    params.width = width;
    params.height = height;

    // execute AddImage8ThreadProc() in parallel
    // the thread count is set to zero (auto-detect) and the granularity
    // of task is set to the number of image rows
    RunThreads( AddImage8ThreadProc, &params, height, 0 );
}


static void *AddImage8ThreadProcNEON( void *ptr )
{
    ThreadData<AddImage8Data> const *tdata = static_cast<ThreadData<AddImage8Data> const *>( ptr );
    AddImage8Data const *params = tdata->params;

    // compute start offset (tdata->taskStartIndex corresponds to image row number)
    int index = tdata->taskStartIndex * params->width;

    // invoke image processing on the image area assigned to the current thread
    AddImage8UnalignedNEON( params->dst + index, params->src1 + index, params->src2 + index, params->width,
                            tdata->taskEndIndex - tdata->taskStartIndex );

    return 0;
}


NO_INLINE
void AddImage8NEON_MT( uint8_t *dst, uint8_t const *src1, uint8_t const *src2, int width, int height )
{
    AddImage8Data params;

    // set up shared thread data (pointers to source and destination images and their size)
    params.src1   = src1;
    params.src2   = src2;
    params.dst    = dst;
    params.width  = width;
    params.height = height;

    // execute AddImage8ThreadProcNEON() in parallel
    // the thread count is set to zero (auto-detect) and the granularity
    // of task is set to the number of image rows
    RunThreads( AddImage8ThreadProcNEON, &params, height, 0 );
}
#endif /* EXAMPLEADDIMAGEMT_H_ */
