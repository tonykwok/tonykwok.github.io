//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include <jni.h>
#include <sstream>

#if !defined(LOG_TAG)
#define LOG_TAG "Fibonacci"
#endif

#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG  , LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO   , LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN   , LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR  , LOG_TAG, __VA_ARGS__)

#include <android/log.h>

int Fibonacci( int n )
{
    if( n == 1 ) { return 1; }
    if( n <= 0 ) { return 0; }

    return Fibonacci( n - 1 ) + Fibonacci( n - 2 );
}


#ifdef __cplusplus
extern "C" {
#endif


    // Uncomment this define to have the program wait for the debugger
    // Once the debugger is attached, break the execution,
    // set up your breakpoints, change _dbg to 0 and continue.

    // #define WAIT_FOR_DEBUGGER

    jint JNI_OnLoad( JavaVM *vm, void *reserved )
    {

#if defined(WAIT_FOR_DEBUGGER)
        volatile int _dbg = 1;
        while( _dbg )
        {
        }
#endif

        return JNI_VERSION_1_2;
    }
    /*
     * Class:     com_nvidia_example_fibonacci_FibonacciActivity
     * Method:    Fibonacci
     * Signature: (I)I
     */
    JNIEXPORT jint JNICALL Java_com_nvidia_example_fibonacci_FibonacciActivity_Fibonacci
    ( JNIEnv *env, jobject obj, jint n )
    {
        LOGV( "Fibonaci(%d) = %d\n", n, Fibonacci( n ) );
        return Fibonacci( n );
    }

    /*
     * Class:     com_nvidia_example_fibonacci_FibonacciActivity
     * Method:    FibonacciSequence
     * Signature: (I)V
     */
    JNIEXPORT void JNICALL Java_com_nvidia_example_fibonacci_FibonacciActivity_FibonacciSequence
    ( JNIEnv *env, jobject obj, jint n )
    {
        const char *methodName = "printToConsole";
        const char *methodSignature = "(Ljava/lang/String;)V";

        jclass    objClass = ( jclass ) env->GetObjectClass( obj );
        jmethodID methodId = env->GetMethodID( objClass, methodName, methodSignature );

        for( int i = 0; i <= n; i++ )
        {
            // Our string buffer for the output message.
            std::stringstream msg;

            // Compute the current Fibonacci number.
            int fibo = Fibonacci( i );

            // Create the msg to print.
            msg << "Fibonacci(" << i << ") = " << fibo << std::endl;

            // Create a jstring to send the message to the Java VM.
            jstring jtext = env->NewStringUTF( msg.str().c_str() );

            // Call the Java class printToConsole method.
            env->CallVoidMethod( obj, methodId, jtext );

            // Delete the local reference created by NewStringUTF
            // to allow the Java VM to garbage collect the jstring object.
            env->DeleteLocalRef( jtext );
        }
    }


#ifdef __cplusplus
}
#endif
