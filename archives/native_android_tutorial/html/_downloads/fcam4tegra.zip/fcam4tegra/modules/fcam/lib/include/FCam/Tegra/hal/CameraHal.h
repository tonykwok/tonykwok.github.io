/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef FCAM_TEGRA_CAMERA_HAL_STUB
#define FCAM_TEGRA_CAMERA_HAL_STUB

/* CameraHal stub -
 * Different hal versions can have incompatible/different function
 * prototypes. Each version of the fcam library has an associated
 * hal version that is specified in the Android.mk file as
 * FCAM_HAL_VERSION. The same applies to the fcamhal library.
 * Because we can't commit changes to the fcamhal and fcam library
 * simultaneously (they live in different git repos) we keep a
 * history of hal headers that are included conditionally depending
 * on the value of FCAM_HAL_VERSION. This allows us to stage
 * the changes to the hal without breaking the build.
 *
 * When an incompatible change is required to the HAL, create a new
 * CameraHal-yymmdd.y header file and add the conditional compilation
 * condition below. Then, modify the Android.mk to use the new hal
 * version, first in the fcam library and then in the fcamhal.
 *
 */

#if FCAM_HAL_VERSION == 121003
#include "CameraHal-121003.h"

#elif FCAM_HAL_VERSION == 120926
#include "CameraHal-120926.h"

#else
#include "CameraHal-120924.h"

#endif


#endif
