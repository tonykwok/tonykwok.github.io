var searchData=
[
  ['handleevent',['handleEvent',['../class_f_cam_1_1_device.html#a9cf188a84cff6f11e02c3145b8541cd3',1,'FCam::Device::handleEvent()'],['../class_f_cam_1_1_tegra_1_1_flash.html#a3b82737bddc224e5e526a4c2dedebdc2',1,'FCam::Tegra::Flash::handleEvent()'],['../class_f_cam_1_1_tegra_1_1_lens.html#a45d044b80e788d77bab8aed29cc4fc04',1,'FCam::Tegra::Lens::handleEvent()']]],
  ['height',['height',['../class_f_cam_1_1_image.html#a278b601ba0a86e6da0291659e0db054e',1,'FCam::Image::height()'],['../class_f_cam_1_1_sharpness_map.html#a6c15d8bce5d4454b78064d7444de13cb',1,'FCam::SharpnessMap::height()']]],
  ['histogram',['Histogram',['../class_f_cam_1_1_histogram.html#a6e212f1cfdd43fcacd5daff0868144a4',1,'FCam::Histogram::Histogram()'],['../class_f_cam_1_1_histogram.html#aa21288a34070ea5d1433b729709923ea',1,'FCam::Histogram::Histogram(unsigned buckets, unsigned channels, Rect region, ColorSpace colorspace=RGB)'],['../class_f_cam_1_1_frame.html#a027a337b5c67bca0a357130f976ea7e4',1,'FCam::Frame::histogram()']]],
  ['histogramconfig',['HistogramConfig',['../class_f_cam_1_1_histogram_config.html#ab6a2bf6a42af8e34053b28833bdf0ee6',1,'FCam::HistogramConfig']]]
];
