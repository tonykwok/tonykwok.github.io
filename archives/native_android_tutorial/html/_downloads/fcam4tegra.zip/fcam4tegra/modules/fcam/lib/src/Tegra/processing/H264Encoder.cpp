/* Copyright (c) 2011-2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "../../Debug.h"
#include "FCam/Tegra/processing/H264Encoder.h"

namespace FCam
{
namespace Tegra
{

// HQ_720p30fps at 19.2Mbps
H264Encoder::Profile H264Encoder::HQ_720p30fps = { 1280, 720, 30, 19200000};

H264Encoder::H264Encoder() :
    pProduct( NULL ),
    pEncoderHAL( NULL ),
    isStreaming( false )
{
    pProduct = Hal::System::openProduct();

    if( pProduct.get() != NULL )
    {
        pEncoderHAL = pProduct->getH264EncoderHal();
    }
    else
    {
        LOGE( "Failed Hal::System::openProduct() - verify hal versions\n" );
    }
}

H264Encoder::~H264Encoder()
{}

bool H264Encoder::open( Profile profile )
{
    bool success = true;

    success = pEncoderHAL->open();
    if( !success ) { return false; }

    Hal::IVideoEncoder::Profile halprofile;
    halprofile.width = profile.width;
    halprofile.height = profile.height;
    halprofile.bps = profile.bitrate;
    halprofile.level = Hal::IVideoEncoder::AVCLevel40;
    halprofile.fps = profile.fps;

    success = pEncoderHAL->configureProfile( halprofile );
    return success;
}

bool H264Encoder::close()
{
    // if we are streaming, finish the stream
    if( isStreaming && !endStream() )
    {
        return false;
    }

    return pEncoderHAL->close();
}

bool H264Encoder::beginStream( const char *outfilename )
{
    if( isStreaming )
    {
        return false;
    }

    bool success = pEncoderHAL->beginStream( outfilename );

    if( success )
    {
        isStreaming = true;
    }

    return success;
}

bool H264Encoder::endStream()
{
    if( !isStreaming )
    {
        return false;
    }

    bool success = pEncoderHAL->endStream();

    if( success )
    {
        isStreaming = false;
    }

    return success;
}

bool H264Encoder::encode( FCam::Image img )
{
    // Only supports YUV420p
    if( img.type() != FCam::YUV420p )
    {
        return false;
    }
    Hal::IVideoEncoder::Frame frame;
    frame.bufferSize = img.width() * img.height() / 2 * 3;
    frame.pBuffer = img( 0, 0 );
    frame.width = img.width();
    frame.height = img.height();
    frame.format = Hal::YUV420p;
    return pEncoderHAL->encode( frame );
}

}
}



