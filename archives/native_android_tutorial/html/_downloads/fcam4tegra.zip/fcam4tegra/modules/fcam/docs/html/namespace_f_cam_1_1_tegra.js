var namespace_f_cam_1_1_tegra =
[
    [ "Hal", null, [
      [ "SensorConfig", "class_f_cam_1_1_tegra_1_1_hal_1_1_sensor_config.html", "class_f_cam_1_1_tegra_1_1_hal_1_1_sensor_config" ],
      [ "LensConfig", "class_f_cam_1_1_tegra_1_1_hal_1_1_lens_config.html", "class_f_cam_1_1_tegra_1_1_hal_1_1_lens_config" ],
      [ "managed_ptr", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr.html", "class_f_cam_1_1_tegra_1_1_hal_1_1managed__ptr" ]
    ] ],
    [ "AutoFocus", "class_f_cam_1_1_tegra_1_1_auto_focus.html", "class_f_cam_1_1_tegra_1_1_auto_focus" ],
    [ "Flash", "class_f_cam_1_1_tegra_1_1_flash.html", "class_f_cam_1_1_tegra_1_1_flash" ],
    [ "Frame", "class_f_cam_1_1_tegra_1_1_frame.html", "class_f_cam_1_1_tegra_1_1_frame" ],
    [ "Lens", "class_f_cam_1_1_tegra_1_1_lens.html", "class_f_cam_1_1_tegra_1_1_lens" ],
    [ "Platform", "class_f_cam_1_1_tegra_1_1_platform.html", "class_f_cam_1_1_tegra_1_1_platform" ],
    [ "Sensor", "class_f_cam_1_1_tegra_1_1_sensor.html", "class_f_cam_1_1_tegra_1_1_sensor" ],
    [ "Shot", "class_f_cam_1_1_tegra_1_1_shot.html", "class_f_cam_1_1_tegra_1_1_shot" ]
];