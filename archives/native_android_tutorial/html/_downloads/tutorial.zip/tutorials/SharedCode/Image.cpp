//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#include <string>
#ifdef ANDROID
#include <nv_file/nv_file.h>
#include <nv_and_util/nv_native_app_glue.h>
#include <sys/stat.h>
#include <errno.h>
#endif
#include <stdio.h>
#include "ImagePixelARGB32.h"
#include "Image.h"

typedef unsigned long ulong;
typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned char uchar;

typedef struct S_BITMAP_HEADER
{
    ushort fileType;
    uint fileSize;
    ushort reserved[2];
    uint bitmapPtr;
} __attribute__((packed)) BITMAP_HEADER;

typedef struct S_BMPV3_INFO_HEADER
{
    uint headerSize;
    uint bWidth;
    uint bHeight;
    ushort bitplanesNum;
    ushort bBpp;
    uint compression;
    uint bSize;
    uint hPixelPerMeter;
    uint vPixelPerMeter;
    uint colorsNum;
    uint imColorsNum;
} __attribute__((packed)) BMPV3_INFO_HEADER;

// TODO: get rid of stdio.h

static std::string gExternalDataPath;

static bool StringEndsWith( const char *str, const char *pattern )
{
    int lstr = strlen( str );
    int pstr = strlen( pattern );

    if( lstr < pstr || lstr == 0 || pstr == 0 )
    {
        return false;
    }

    int istart = lstr - pstr;
    for( int i = istart; i < lstr; i++ )
    {
        if( str[i] != pattern[i - istart] )
        {
            return false;
        }
    }

    return true;
}

#ifdef ANDROID

static int MakeDir( std::string const &path, mode_t mode )
{
    struct stat st;
    if( stat( path.c_str(), &st ) != 0 )
    {
        if( mkdir( path.c_str(), mode ) != 0 && errno != EEXIST )
        {
            return false;
        }
    }
    else if( !S_ISDIR( st.st_mode ) )
    {
        errno = ENOTDIR;
        return false;
    }

    return true;
}

static bool MakePath( std::string const &path, mode_t mode )
{
    std::string cstr( path );

    int cpos = 0;
    int ppos = 0;
    bool success = true;
    while( success && ( cpos = cstr.find_first_of( "/", ppos ) ) != std::string::npos )
    {
        if( cpos != ppos )
        {
            /* Neither root nor double slash in path */
            cstr[cpos] = '\0';
            success = MakeDir( cstr, mode );
            cstr[cpos] = '/';
        }
        ppos = cpos + 1;
    }

    if( success )
    {
        success = MakeDir( path, mode );
    }

    return success;
}

void SetupImageFileReader( android_app *app )
{
    // copy external path
    gExternalDataPath = app->activity->externalDataPath;
    // create the path if it does not exist
    MakePath( gExternalDataPath, S_IRWXU );
    // init .apk reader
    NvFInit( app->activity->assetManager );
}

#endif

template<> void Image<IPF_argb32>::loadImage( const char *name )
{
#ifdef ANDROID
    NvFile *f = NvFOpen( name );
    if( !f )
    {
        LOG( "error opening %s!\n", name );
        return;
    }
#else
    char tname[256];
    sprintf( tname, "assets/%s", name );
    FILE *f = fopen( tname, "rb" );
    if( !f )
    {
        LOG( "error opening %s!\n", tname );
        return;
    }
#endif

    if( StringEndsWith( name, ".bmp" ) )
    {
        BITMAP_HEADER head;
        BMPV3_INFO_HEADER info;

#ifdef ANDROID
        NvFRead( &head, sizeof(BITMAP_HEADER), 1, f );
        NvFRead( &info, sizeof(BMPV3_INFO_HEADER), 1, f );
        NvFSeek( f, head.bitmapPtr, SEEK_SET );
#else
        fread( &head, sizeof(BITMAP_HEADER), 1, f );
        fread( &info, sizeof(BMPV3_INFO_HEADER), 1, f );
        fseek( f, head.bitmapPtr, SEEK_SET );
#endif

        if( info.bBpp != 24 && info.bBpp != 32 )
        {
            LOG( "unsupported bitmap type!" );
#ifdef ANDROID
			NvFClose( f );
#else
			fclose( f );
#endif
			return;
        } 

        set( info.bWidth, info.bHeight );

        int scanSize = ( mWidth * ( info.bBpp >> 3 ) + 3 ) & ~0x3;
        uchar *rdata = new uchar[scanSize];
        for( int y = mHeight - 1; y >= 0; y-- )
        {
#ifdef ANDROID
            NvFRead( rdata, scanSize, 1, f );
#else
            fread( rdata, scanSize, 1, f );
#endif
            // shuffle rgb
            int index = y * mWidth;
            if( info.bBpp == 24 )
            {
                for( int i = 0; i < mWidth; i++ )
                {
                    mData[index + i] = ImagePixelARGB32( rdata[i * 3 + 2], rdata[i * 3 + 1], rdata[i * 3], 255 );
                }
            }
            else
            {
                for( int i = 0; i < mWidth; i++ )
                {
                    mData[index + i] = ImagePixelARGB32( rdata[i * 4 + 2], rdata[i * 4 + 1], rdata[i * 4],
                                                         rdata[i * 4 + 3] );
                }
            }
        }

        delete[] rdata;
    }
    else if( StringEndsWith( name, ".ppm" ) )
    {
        char temp[256];

#ifdef ANDROID
        // read header
        NvFGets( temp, 256, f );
#else
        // read header
        fgets( temp, 256, f );
#endif
        if( strcmp( temp, "P6" ) == 0 )
        {
            int width, height;
#ifdef ANDROID
            // skip comment line
            NvFGets( temp, 256, f );
            NvFGets( temp, 256, f );
            sscanf( temp, "%i %i\n", &width, &height );
            // always equal to "255" for P6
            NvFGets( temp, 256, f );
#else
            // skip comment line
            fgets( temp, 256, f );
            fscanf( f, "%i %i\n", &width, &height );
            // always equal to "255" for P6
            fgets( temp, 256, f );
#endif

            // read data
            set( width, height );

            uchar *rdata = new uchar[width * 3];
            int index = 0;
            for( int y = 0; y < height; y++ )
            {
#ifdef ANDROID
                NvFRead( rdata, width * 3, 1, f );
#else
                fread( rdata, width * 3, 1, f );
#endif
                // shuffle rgb
                for( int i = 0; i < width; i++ )
                {
                    mData[index + i] = ImagePixelARGB32( rdata[i * 3 + 2], rdata[i * 3 + 1], rdata[i * 3], 255 );
                }

                index += width;
            }

            delete[] rdata;
        }
        else
        {
            LOG( "loadImage(): %s: format not supported!", name );
        }
    }

#ifdef ANDROID
    NvFClose( f );
#else
    fclose( f );
#endif
}

template<> void Image<IPF_argb32>::writeImage( const char *name )
{
    if( mData == 0 )
    {
        return;
    }

    int scanSize = ( mWidth * 3 + 3 ) & ~0x3;
    int fileSize = scanSize * mHeight + sizeof(BITMAP_HEADER) + sizeof(BMPV3_INFO_HEADER);

    BITMAP_HEADER head;
    BMPV3_INFO_HEADER info;

    head.fileType = 0x4d42;
    head.fileSize = fileSize;
    head.bitmapPtr = sizeof(BITMAP_HEADER) + sizeof(BMPV3_INFO_HEADER);

    info.bBpp = 24;
    info.bWidth = mWidth;
    info.bHeight = mHeight;
    info.vPixelPerMeter = info.hPixelPerMeter = 0;
    info.headerSize = sizeof(BMPV3_INFO_HEADER);
    info.compression = 0;
    info.bitplanesNum = 1;
    info.bSize = scanSize * mHeight;
    info.imColorsNum = 0;
    info.colorsNum = 0;

#ifdef ANDROID
    char tname[256];
    sprintf( tname, "%s/%s", gExternalDataPath.c_str(), name );
    FILE *f = fopen( tname, "wb" );
    if( !f )
    {
        LOG( "error writing %s!\n", tname );
        return;
    }
    else
    {
        LOG( "Writing %s\n", tname );
    }
#else
    FILE *f = fopen( name, "wb" );
    if( !f )
    {
        LOG( "error writing %s!\n", name );
        return;
    }
#endif

    fwrite( &head, sizeof(BITMAP_HEADER), 1, f );
    fwrite( &info, sizeof(BMPV3_INFO_HEADER), 1, f );
    uchar *rdata = new uchar[scanSize];
    memset( rdata, 0, scanSize );

    for( int y = mHeight - 1; y >= 0; y-- )
    {
        int index = y * mWidth;
        for( int i = 0; i < mWidth; i++ )
        {
            rdata[i * 3] = mData[index + i][0];
            rdata[i * 3 + 1] = mData[index + i][1];
            rdata[i * 3 + 2] = mData[index + i][2];
        }

        fwrite( rdata, scanSize, 1, f );
    }

    delete[] rdata;

    fclose( f );
}

