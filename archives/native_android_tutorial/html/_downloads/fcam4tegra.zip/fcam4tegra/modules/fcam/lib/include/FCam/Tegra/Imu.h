/* Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *  * Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  * Neither the name of NVIDIA CORPORATION nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef FCAM_TEGRA_IMU_H
#define FCAM_TEGRA_IMU_H

/** \file
 * Device which provides IMU measurements. */

#include <android/sensor.h>
#include "../CircularBuffer.h"
#include "../Imu.h"

namespace FCam
{
namespace Tegra
{
class Imu : public FCam::Imu
{
public:
    Imu();
    ~Imu();
    virtual bool available( ImuSensor s );
    virtual void enable( ImuSensor s );
    virtual void disable( ImuSensor s );
    virtual void setRate( int rate );

    virtual void tagFrame( FCam::Frame );
    virtual void handleEvent( const Event &e );

    /** Log raw data to files.
     * Begins logging sensor data directly to a set of CSV files. Unlike
     * the tags applied to frames, the log will contain every sample
     * captured by the sensors. Only sensors which are enabled are logged.
     * \param filepath  Base file path to use for logging.  Individual
     * filenames will be created by appending "gyro.csv", "acc.csv", and
     * "orient.csv" to the provided path. */
    void beginLogging( const std::string filepath );

    /** Stop logging data
     * Stops recording to the log files and closes the file handles.
     */
    void endLogging( void );

    inline bool isCalibrating() { return mCalibrating; }
    void autoCalibration( int calSamples = Imu::DEFALT_CALIBRATION_SAMPLES );
    void setCalibration( float xBias, float yBias, float zBias );
    void getCalibration( float *xBias, float *yBias, float *zBias,
                         float *xVar, float *yVar, float *zVar );

private:
    /** Tags the frame with gyro data */
    void tagGyro( Frame f, std::vector<Time> interpPoints );
    /** Tags the frame with accelerometer data */
    void tagAccelerometer( Frame f, std::vector<Time> interpPoints );
    /** Tags the frame with orientation data */
    void tagOrientation( Frame f, std::vector<Time> interpPoints );

    /** Helper to convert a 3-element rotation vector to a full quaternion.
     * \param rot 3-element rotation vector
     * \param quat 4-element float array where the resulting quaternion will
     * be placed.
     */
    void rotationToQuaternion( float *rot, float *quat );

    /** Callback required by the Android sensor event / Looper model.
     * It does not do anything.
     */
    static int dummyCallback( int fd, int events, void *data );
    static void *updateThread( void *obj );
    void update( void );
    void doCalibration( float x, float y, float z );

    // For some reason, not all of the sensors are defined in the Android
    // sensor.h file, so we define them here.  These numbers are the same
    // as the IDs from the Java Sensor.getType() method.
    const static int ASENSOR_TYPE_ROTATION_VECTOR = 11;

    // Identifiers which are used to determine which sensor an event came from
    const static int GYRO_QUEUE = 1;
    const static int ACC_QUEUE = 2;
    const static int ORIENTATION_QUEUE = 3;

    struct GyroState
    {
        Time time; ///< Timestamp for the event, as an FCam Time
        float xVel; ///< X angular velocity
        float yVel; ///< Y angular velocity
        float zVel; ///< Z angular velocity
    };

    struct AccState
    {
        Time time; ///< Timestamp for the event, as an FCam Time
        float xAcc; ///< X acceleration
        float yAcc; ///< Y acceleration
        float zAcc; ///< Z acceleration
    };

    struct OrientationState
    {
        Time time; ///< Timestamp for the event, as an FCam Time
        float q[4]; ///< Unit quaternion representing the rotation
    };

    // Constant offset used to correct for timestamp lead/lag relative to
    // the camera.  This should be a result of hardware latency - e.g, the
    // delay from the IMU's built-in digital low-pass filter or from
    // processing in the ISP.
    // This value should be specified in microseconds.  It will be
    // subtracted from all IMU event timestamps as they come in.
    const static int IMU_LAG = 30000; // 30ms

    /** Integrates a single sample of gyro data and returns the new
     * orientation as a quaternion. */
    OrientationState integrateGyro( const GyroState g, const OrientationState last );

    const static int HIST_LEN = 300; ///< Number of history samples to buffer
    CircularBuffer<GyroState> mGyroHistory;
    CircularBuffer<AccState> mAccHistory;
    CircularBuffer<OrientationState> mOrientHistory;
    ASensorEventQueue *mGyroQueue;
    ASensorEventQueue *mAccQueue;
    ASensorEventQueue *mOrientQueue;

    const bool mFusedOrientation; ///< Whether to use acc+gyro or just gyro for orientation
    bool mGyroEnabled, mAccEnabled, mOrientEnabled;
    int mRate; ///< Hint for how many samples per second to provide

    bool mLogData; ///< Whether or not we are logging all data to files
    FILE *mGyroLogFile;
    FILE *mAccLogFile;
    FILE *mOrientLogFile;

    /// How many calibration samples to take if a value isn't specified
    const static int DEFALT_CALIBRATION_SAMPLES = 500;
    bool mCalibrating; ///< Whether or not the sensor is in calibration
    int mCalibrationCount; ///< Number of calibration samples taken
    int mCalibrationDesired; ///< Number of calibration samples requested

    float mGyroXSum; ///< Running total of X values, used to find the mean
    float mGyroYSum; ///< Running total of Y values, used to find the mean
    float mGyroZSum; ///< Running total of Z values, used to find the mean

    float mGyroXSquared; ///< Running total of X^2, used to find the variance
    float mGyroYSquared; ///< Running total of Y^2, used to find the variance
    float mGyroZSquared; ///< Running total of Z^2, used to find the variance

    float mGyroXBias; ///< Gyro X bias, subtracted from incoming values
    float mGyroYBias; ///< Gyro Y bias, subtracted from incoming values
    float mGyroZBias; ///< Gyro Z bias, subtracted from incoming values
};

}
}

#endif
