//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#include <jni.h>
#include <errno.h>

#include <EGL/egl.h>
#include <GLES2/gl2.h>

#include <android/sensor.h>
#include <android_native_app_glue.h>

#include <android/log.h>
#define LOGW(...) ((void)__android_log_print(ANDROID_LOG_WARN, "SimpleNativeGL", __VA_ARGS__))
#define LOGI(...) ((void)__android_log_print(ANDROID_LOG_INFO, "SimpleNativeGL", __VA_ARGS__))


/**
 * State of our app
 */
struct Engine
{
    // Save in the engine a pointer to the Android app
    struct android_app *app;

    // EGL Display, surface, and context
    EGLDisplay display;
    EGLSurface surface;
    EGLContext context;

    // States and touch locations
    bool animating;
    int width;
    int height;
    int x_touch;
    int y_touch;
};


/**
 * Initialize an EGL context for the current display
 */
static int engine_init_display( struct Engine *engine )
{
    // initialize OpenGL ES and EGL
    EGLDisplay display = eglGetDisplay( EGL_DEFAULT_DISPLAY );

    eglInitialize( display, 0, 0 );

    // Specify the attributes of the desired configuration.
    // We select an EGLConfig with at least 8 bits per color component
    // that is compatible with on-screen windows.
    const EGLint attribs[] =
    { EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_BLUE_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_RED_SIZE, 8, EGL_NONE };

    // Here, the application chooses the configuration it desires.
    // eglChooseConfig in general returns all the configurations compatible
    // with the attributes passed. In this sample, we have a very simplified
    // selection process, where we pick the first EGLConfig that matches
    // our criteria (by setting the third argument to 1).
    EGLConfig config;
    EGLint numConfigs;
    eglChooseConfig( display, attribs, &config, 1, &numConfigs );

    // EGL_NATIVE_VISUAL_ID is an attribute of the EGLConfig that is
    // guaranteed to be accepted by ANativeWindow_setBuffersGeometry().
    // We can use it to make the ANativeWindow buffers to match.
    EGLint format;
    eglGetConfigAttrib( display, config, EGL_NATIVE_VISUAL_ID, &format );

    // Set a native Android window to have the format configured by EGL
    ANativeWindow_setBuffersGeometry( engine->app->window, 0, 0, format );

    // Create EGL surface and context
    EGLSurface surface = eglCreateWindowSurface( display, config, engine->app->window, NULL );
    EGLContext context = eglCreateContext( display, config, NULL, NULL );

    // Use the surface and context we just created and configure the engine
    if( eglMakeCurrent( display, surface, surface, context ) == EGL_FALSE )
    {
        LOGW( "Unable to eglMakeCurrent" );
        return -1;
    }

    // Get width and height of the surface
    EGLint w, h;
    eglQuerySurface( display, surface, EGL_WIDTH, &w );
    eglQuerySurface( display, surface, EGL_HEIGHT, &h );

    // Store the app variables so the callbacks can access the data
    engine->display = display;
    engine->context = context;
    engine->surface = surface;
    engine->width   = w;
    engine->height  = h;

    // Initialize GL state
    glEnable( GL_CULL_FACE );
    glDisable( GL_DEPTH_TEST );

    return 0;
}


/**
 * Draw the current frame on the display
 */
static void engine_draw_frame( struct Engine *engine )
{
    if( engine->display == NULL ) { return; } // No display

    // Set the clear color based on the touch location from the engine
    glClearColor( ( ( float ) engine->x_touch ) / engine->width,  // Red channel
                  0,                                              // Green channel
                  ( ( float ) engine->y_touch ) / engine->height, // Blue channel
                  1 );                                            // Alpha channel
    // Clear the screen to the color we just set
    glClear( GL_COLOR_BUFFER_BIT );

    // Swap the buffers, which indicates we're done with rendering this frame
    eglSwapBuffers( engine->display, engine->surface );
    // LOGI( "Buffers swapped by eglSwapBuffers..." );
}


/**
 * Tear down the EGL context currently associated with the display
 */
static void engine_term_display( struct Engine *engine )
{
    if( engine->display != EGL_NO_DISPLAY )
    {
        eglMakeCurrent( engine->display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT );
        if( engine->context != EGL_NO_CONTEXT )
        {
            eglDestroyContext( engine->display, engine->context );
        }
        if( engine->surface != EGL_NO_SURFACE )
        {
            eglDestroySurface( engine->display, engine->surface );
        }
        eglTerminate( engine->display );
    }
    engine->animating = false;
    engine->display   = EGL_NO_DISPLAY;
    engine->context   = EGL_NO_CONTEXT;
    engine->surface   = EGL_NO_SURFACE;
}


/**
 * Process the input event
 */
static int32_t engine_handle_input( struct android_app *app, AInputEvent *event )
{
    // Get a local pointer to the engine that we stored in the application
    struct Engine *engine = ( struct Engine * ) app->userData;

    // Analyze the type of event
    if( AInputEvent_getType( event ) == AINPUT_EVENT_TYPE_MOTION )
    {
        // If the user lifted the finger from the screen, stop updating
        int32_t action = AMotionEvent_getAction( event );
        if( action != AMOTION_EVENT_ACTION_MOVE )
        {
            engine->animating = false;
            return 1;
        }

        // Otherwise get the touch position and set animation to true
        engine->x_touch = AMotionEvent_getX( event, 0 );
        engine->y_touch = AMotionEvent_getY( event, 0 );
        engine->animating = true;
        return 1;
    }

    return 0;
}

/**
 * Process the next main command
 */
static void engine_handle_cmd( struct android_app *app, int32_t cmd )
{
    // Get a local pointer to the engine that we stored in the application
    struct Engine *engine = ( struct Engine * ) app->userData;

    // Analyze the command
    switch( cmd )
    {
    case APP_CMD_INIT_WINDOW:
        // The window is being shown, get it ready
        if( engine->app->window != NULL )
        {
            // Initialize the engine based on the current display
            engine_init_display( engine );
            // Start drawing
            engine_draw_frame( engine );
        }
        break;
    case APP_CMD_TERM_WINDOW:
        // The window is being hidden or closed, clean it up
        engine_term_display( engine );
        break;
    case APP_CMD_LOST_FOCUS:
        // When our app loses focus, we stop animating
        engine->animating = false;
        break;
    }
}

/**
 * This is the main entry point of a native application that is using
 * android_native_app_glue.  It runs in its own thread, with its own
 * event loop for receiving input events and doing other things.
 */
void android_main( struct android_app *app )
{
    // Make sure glue isn't stripped
    app_dummy();

    // Initialize the engine.
    // The engine stores the state and global variables of the application.
    struct Engine engine;
    memset( &engine, 0, sizeof( engine ) );
    // The engine needs a pointer to app, e.g., to access the window data
    engine.app = app;

    // Link the app to the engine and attach callbacks.
    // Store a pointer to the application engine for event handling.
    app->userData     = &engine;
    // Callback for handling application status changes
    app->onAppCmd     = engine_handle_cmd;
    // Callback for handling touch input
    app->onInputEvent = engine_handle_input;

    // The core of the main is an infinite loop which waits for events
    // and redraws the frame when needed.
    while( 1 )
    {
        // read all pending events
        int events;
        struct android_poll_source *source;

        // If not animating, we will block forever waiting for events.
        // If animating, we loop until all events are read, then continue
        // to draw the next frame of animation.
        while( ( ALooper_pollAll( engine.animating ? 0 : -1, NULL, &events, ( void ** ) &source ) ) >= 0 )
        {
            // Process this event.
            // Depending on the event, app->onAppCmd or app->onInputEvent may be called.
            if( source != NULL )
            {
                source->process( app, source );
            }

            // Check if we are exiting (e.g., user presses the back button)
            if( app->destroyRequested != 0 )
            {
                engine_term_display( &engine );
                return;
            }
        }

        if( engine.animating )
        {
            // Done with events; draw next animation frame.
            // Drawing is synched with the screen update rate, so there
            // is no need to do timing here.
            engine_draw_frame( &engine );
        }
    }
}
