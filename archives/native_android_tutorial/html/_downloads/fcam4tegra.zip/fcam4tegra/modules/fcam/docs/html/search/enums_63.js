var searchData=
[
  ['colorspace',['ColorSpace',['../namespace_f_cam.html#acd57b1f895e126a148e9cd525e31cb60',1,'FCam']]],
  ['confidence',['Confidence',['../class_f_cam_1_1_tegra_1_1_frame.html#abe02facdeec10eb0762d2956b7d26274',1,'FCam::Tegra::Frame']]]
];
