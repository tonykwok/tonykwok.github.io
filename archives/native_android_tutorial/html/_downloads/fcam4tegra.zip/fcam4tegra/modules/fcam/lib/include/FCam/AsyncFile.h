/* Copyright (c) 1995-2010, Stanford University.
 * Copyright (c) 2011-2012, NVIDIA CORPORATION.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FCAM_ASYNCFILE_H
#define FCAM_ASYNCFILE_H

#include <queue>
#include <semaphore.h>
#include <string>
#include <pthread.h>

#include "Frame.h"

//! \file
//! AsyncFile contains classes to load and save images in the background

namespace FCam
{

class Lens;
class Flash;

/** The AsyncFileWriter saves frames in a low priority background
 * thread */
class AsyncFileWriter
{
public:
    AsyncFileWriter();
    ~AsyncFileWriter();

    /** Save a DNG in a background thread. */
    void saveDNG( Frame, std::string filename );
    void saveDNG( Image, std::string filename );

    /** Save a JPEG in a background thread. You can optionally
     * pass a jpeg quality (0-100). */
    void saveJPEG( Frame, std::string filename, int quality = 75 );
    void saveJPEG( Image, std::string filename, int quality = 75 );

    /** Save a raw dump in a background thread. */
    void saveDump( Frame, std::string filename );
    void saveDump( Image, std::string filename );

    /** How many save requests are pending (including the one
     * currently saving) */
    int savesPending()
    {
        return pending;
    }

    /** Cancel all outstanding requests. The writer will finish
     * saving the current request, but not save any more */
    void cancel();

private:

    friend void *launch_async_file_writer_thread_( void * );

    struct SaveRequest
    {
        // only one of these two things should be defined
        Frame frame;
        Image image;

        std::string filename;
        enum {DNGFrame = 0, JPEGFrame, JPEGImage, DumpFrame, DumpImage} fileType;
        int quality;
    };

    std::queue<SaveRequest> saveQueue;
    pthread_mutex_t saveQueueMutex;
    sem_t *saveQueueSemaphore;

    bool running, stop;
    pthread_t thread;

    void run();

    int pending;
};

}

#endif
