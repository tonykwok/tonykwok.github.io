var struct_f_cam_1_1_lens_1_1_tags =
[
    [ "Tags", "struct_f_cam_1_1_lens_1_1_tags.html#af74067164c27d38cdc9ff478534005f2", null ],
    [ "focus", "struct_f_cam_1_1_lens_1_1_tags.html#a98c8a02887d382e17b0ad6a196ccef3c", null ],
    [ "focusSpeed", "struct_f_cam_1_1_lens_1_1_tags.html#a8d78073c62e1a53784036cf828d04d72", null ],
    [ "initialFocus", "struct_f_cam_1_1_lens_1_1_tags.html#a1b1fd9b8e011a619af0d7691c488178c", null ],
    [ "finalFocus", "struct_f_cam_1_1_lens_1_1_tags.html#ae27f376453d6d000e5db1017bb14bf5e", null ],
    [ "zoom", "struct_f_cam_1_1_lens_1_1_tags.html#ae07129b4f4893442bfe9a21be8d77f78", null ],
    [ "zoomSpeed", "struct_f_cam_1_1_lens_1_1_tags.html#a31f42a9b51621e7e5fd243ca26769d74", null ],
    [ "initialZoom", "struct_f_cam_1_1_lens_1_1_tags.html#a156955d654a9fab6d3906433400e676e", null ],
    [ "finalZoom", "struct_f_cam_1_1_lens_1_1_tags.html#a0e900b5d73ae2377b75d0623df6cdb7d", null ],
    [ "aperture", "struct_f_cam_1_1_lens_1_1_tags.html#a4a6297590947d01c6fd4712f06d8e5ab", null ],
    [ "apertureSpeed", "struct_f_cam_1_1_lens_1_1_tags.html#abeca2652484b88a9c60385082fa69ebf", null ],
    [ "initialAperture", "struct_f_cam_1_1_lens_1_1_tags.html#ab0b5c5536745467bf4cf33f652530980", null ],
    [ "finalAperture", "struct_f_cam_1_1_lens_1_1_tags.html#a11255a31083e649c8f4c40979bded568", null ]
];