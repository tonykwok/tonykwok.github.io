/* Copyright (c) 1995-2010, Stanford University.
 * Copyright (c) 2011-2012, NVIDIA CORPORATION.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef FCAM_ACTION_H
#define FCAM_ACTION_H

#include <stdio.h>

/** \file
 * Abstract base classes for device actions.
 *
 * Actions represent things that devices should do at precise times
 * into the exposure. They are attached to \ref FCam::Shot objects.
 */

namespace FCam
{
/** An abstract base class for actions */
class Action
{
public:

    Action() : owner( 0 ) {}
    virtual ~Action();

    enum
    {
        FlashMask = 0x1F,       // Bitmask to test for flash actions
        FlashFire = 0x11,
        FlashTorch,

        LensMask  = 0x2F,       // Bitmask to test for lens actions
        LensFocus = 0x21,
        LensStepFocus,
        LensZoom,
        LensAperture,

        CustomAction = 0xFFFF // Start of custom actions
    };

    /** A value that denotes the type of the action as defined by
     *  the enum.
     */
    virtual int type() const = 0;

    /** The number of microseconds into the exposure at which this
     * action should occur. */
    int time;

    /** How long before the \ref FCam::Action::time "time" must \ref FCam::Action::doAction "doAction" be called?    */
    int latency;

    /** An owner tag that indicates which module added the action to the shot.
     *  \ref FCam::Shot::clearActions takes an owner tag to clear only actions
     *  that match the owner. Default is 0.
     */
    void *owner;

    /** Perform the action. Derived classes should override
     * this. This method will be called in the highest priority
     * thread possible to allow for precise timing, so don't
     * perform any long running computations in it unless you
     * really want the entire OS to freeze. */
    virtual void doAction() = 0;

    /** Make a new copy of this action (on the heap). Used when
     * making deep copies of Shot objects. Inherit from
     * \ref CopyableAction instead to have this implemented for you
     * using your action's copy constructor.
     */
    virtual Action *copy() const = 0;

private:

    friend class Shot;
};

/** For convenience, derived \ref FCam::Action Action classes may
 * inherit from this so they don't have to implement the
 * \ref FCam::Action::copy method. It's templatized over the derived class
 * type.
 */
template<typename Derived>
class CopyableAction : public Action
{
public:
    /** Make a new copy of this action on the heap using the
     * default copy constructor. */
    Action *copy() const
    {
        return new Derived( *( ( Derived * )this ) );
    }
};

}


#endif
