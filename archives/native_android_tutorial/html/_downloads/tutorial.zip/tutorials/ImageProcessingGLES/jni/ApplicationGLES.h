//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#ifndef APPLICATIONGLES_H_
#define APPLICATIONGLES_H_

#include <nv_and_util/nv_native_app_glue.h>
#include <nv_egl_util/nv_egl_util.h>

class ApplicationGLES
{
public:
    ApplicationGLES( struct android_app *app, NvEGLUtil *egl )
    {
        app->userData = this;
        app->onAppCmd = HandleCmd;
        app->onInputEvent = HandleInput;

        mEgl = egl;
        mNativeAppInstance = app;
        mIsExitRequested = false;
    }

    virtual ~ApplicationGLES( void )
    {

    }

    static void HandleCmd( struct android_app *app, int32_t cmd )
    {
        ApplicationGLES *instance = static_cast<ApplicationGLES *>( app->userData );
        if( instance )
        {
            instance->handleCommand( cmd );
        }
    }

    void handleCommand( int cmd )
    {
        switch( cmd )
        {
            case APP_CMD_INIT_WINDOW:
            // The window is being shown, get it ready.
            // Note that on ICS, the EGL size will often be correct for the new size here,
            // but on HC it will not be.  We need to defer checking the new res until the
            // first render with the new surface!

            case APP_CMD_WINDOW_RESIZED:
            // A command to resize the window was issued, we need to
            // redraw it with its new size.
            mEgl->setWindow( mNativeAppInstance->window );
            break;

            case APP_CMD_TERM_WINDOW:
            // The window is being hidden or closed, clean it up.
            mEgl->setWindow( NULL );
            break;

            case APP_CMD_GAINED_FOCUS:
            // The app window gained focus we need to start rendering it.
            break;

            case APP_CMD_LOST_FOCUS:
            // The app window lost focus so we need to pause it.

            case APP_CMD_PAUSE:
            // Move out of active mode if we are in it. But if we are
            // in another dialog mode, leave it as-is.
                nv_app_force_quit_no_cleanup( mNativeAppInstance );
            break;

            case APP_CMD_CONFIG_CHANGED:
            // ICS does not appear to require this, but on GB phones,
            // not having this causes rotation changes to be delayed or
            // ignored when we're in a non-rendering mode like autopause.
            // The forced renders appear to allow GB to process the rotation.
            break;
        }
    }

    /**
     * Process the next input event.
     */
    static int32_t HandleInput( struct android_app *app, AInputEvent *event )
    {
        ApplicationGLES *instance = static_cast<ApplicationGLES *>( app->userData );
        if( !instance )
        {
            return 0;
        }
        return instance->handleInput( event );
    }

    int handleInput( AInputEvent *event )
    {
        //We only handle motion events (touchscreen) and key (button/key) events
        int32_t eventType = AInputEvent_getType( event );

        if( eventType == AINPUT_EVENT_TYPE_MOTION )
        {
            int32_t actionData = AMotionEvent_getAction( event );
            int32_t action = actionData & AMOTION_EVENT_ACTION_MASK;

            int32_t pcount = AMotionEvent_getPointerCount( event );
            switch( action )
            {
                case AMOTION_EVENT_ACTION_DOWN:
                case AMOTION_EVENT_ACTION_UP:
                case AMOTION_EVENT_ACTION_MOVE:
                case AMOTION_EVENT_ACTION_CANCEL:
                // dummy handle
                break;
            }

            return 1;
        }
        else if( eventType == AINPUT_EVENT_TYPE_KEY )
        {
            int32_t code = AKeyEvent_getKeyCode( (const AInputEvent *) event );

            if( ( code == AKEYCODE_BACK ) )
            {
                mIsExitRequested = true;
                return 1;
            }
        }

        return 0;
    }

protected:
    bool mIsExitRequested;
    NvEGLUtil *mEgl;
    struct android_app *mNativeAppInstance;
};

#endif /* APPLICATIONGLES_H_ */
