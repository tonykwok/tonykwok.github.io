/* Copyright (c) 1995-2010, Stanford University.
 * Copyright (c) 2011-2012, NVIDIA CORPORATION.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the names of copyright owners nor  the
 *       names of their contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY COPYRIGHT HOLDERS ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNERS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <stdlib.h>

#include "FCam/Lens.h"
#include "FCam/Frame.h"

#include "Debug.h"

namespace FCam
{

Lens::FocusAction::FocusAction( Lens *l ) :
    lens( l )
{
    focus = 0.0f;
    speed = lens->maxFocusSpeed();
    latency = lens->focusLatency();
    time = 0;
}

Lens::FocusAction::FocusAction( Lens *l, int t, float f ) :
    focus( f ), lens( l )
{
    speed = lens->maxFocusSpeed();
    latency = lens->focusLatency();
    time = t;
}

Lens::FocusAction::FocusAction( Lens *l, int t, float f, float s ) :
    focus( f ), speed( s ), lens( l )
{
    latency = lens->focusLatency();
    time = t;
}

void Lens::FocusAction::doAction()
{
    lens->setFocus( focus, speed );
}

Lens::FocusSteppingAction::FocusSteppingAction( Lens *l ) :
    lens( l )
{
    step  = 0.0f;
    speed = lens->maxFocusSpeed();
    latency = lens->focusLatency();
    time = 0;
    repeat = 1;
}

Lens::FocusSteppingAction::FocusSteppingAction( Lens *l, int r, int t, float f ) :
    step( f ), repeat( r ), lens( l )
{
    speed = lens->maxFocusSpeed();
    latency = lens->focusLatency();
    time = t;
}

Lens::FocusSteppingAction::FocusSteppingAction( Lens *l, int r, int t, float f, float s ) :
    step( f ), speed( s ), repeat( r ), lens( l )
{
    latency = lens->focusLatency();
    time = t;
}

void Lens::FocusSteppingAction::doAction()
{
    if( repeat > 0 && !lens->focusChanging() )
    {
        float current = lens->getFocus();
        lens->setFocus( step + current, speed );
        repeat--;
    }
}

Lens::ZoomAction::ZoomAction( Lens *l ) :
    lens( l )
{
    zoom = 0.0f;
    speed = lens->maxZoomSpeed();
    latency = lens->zoomLatency();
    time = 0;
}

Lens::ZoomAction::ZoomAction( Lens *l, int t, float f ) :
    zoom( f ), lens( l )
{
    speed = lens->maxZoomSpeed();
    latency = lens->zoomLatency();
    time = t;
}

Lens::ZoomAction::ZoomAction( Lens *l, int t, float f, float s ) :
    zoom( f ), speed( s ), lens( l )
{
    latency = lens->zoomLatency();
    time = t;
}

void Lens::ZoomAction::doAction()
{
    lens->setZoom( zoom, speed );
}


Lens::ApertureAction::ApertureAction( Lens *l ) :
    lens( l )
{
    aperture = 0.0f;
    speed = lens->maxApertureSpeed();
    latency = lens->apertureLatency();
    time = 0;
}

Lens::ApertureAction::ApertureAction( Lens *l, int t, float f ) :
    aperture( f ), lens( l )
{
    speed = lens->maxApertureSpeed();
    latency = lens->apertureLatency();
    time = t;
}

Lens::ApertureAction::ApertureAction( Lens *l, int t, float f, float s ) :
    aperture( f ), speed( s ), lens( l )
{
    latency = lens->apertureLatency();
    time = t;
}

void Lens::ApertureAction::doAction()
{
    lens->setAperture( aperture, speed );
}

Lens::Tags::Tags( Frame f )
{
    initialFocus    = f["lens.initialFocus"];
    finalFocus      = f["lens.finalFocus"];
    focus           = f["lens.focus"];
    focusSpeed      = f["lens.focusSpeed"];
    zoom            = f["lens.zoom"];
    initialZoom     = f["lens.initialZoom"];
    finalZoom       = f["lens.finalZoom"];
    aperture        = f["lens.aperture"];
    initialAperture = f["lens.initialAperture"];
    finalAperture   = f["lens.finalAperture"];
    apertureSpeed   = f["lens.apertureSpeed"];
}

}
