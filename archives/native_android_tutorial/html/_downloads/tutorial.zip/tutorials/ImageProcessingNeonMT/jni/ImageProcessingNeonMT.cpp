//----------------------------------------------------------------------------------
//
// Copyright (c) 2012, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//
//----------------------------------------------------------------------------------

#ifdef ANDROID
#include <nv_and_util/nv_native_app_glue.h>
#endif
#include <vector>
#include <algorithm>

#include "ExampleAddImageMT.h"
#include "ExampleVBlurImageMT.h"
#include "ImagePixelARGB32.h"
#include "Image.h"
#include "Timer.h"

/**
 * This is the main entry point of a native application that is using
 * android_native_app_glue.  It runs in its own thread, with its own
 * event loop for receiving input events and doing other things.
 */
#ifdef ANDROID
void android_main( struct android_app *app )
#else
int main( int argc, char **argv )
#endif
{
#ifdef ANDROID
    // Make sure glue isn't stripped.
    app_dummy();
    SetupImageFileReader( app );
#endif

    // load images
    Image<IPF_argb32> image1, image2, result;
    image1.loadImage( "nvidia_logo.bmp" );
    image2.loadImage( "checker_board.bmp" );

    int w = image1.getWidth();
    int h = image1.getHeight();
    result.set( w, h );

    // we align the line width such that its size is a multiple of cpu cache line size
    int wAligned = ( image1.getWidth() + CACHELINE_ALIGNMENT / 4 ) & ~( CACHELINE_ALIGNMENT / 4 - 1 );

    // create source and destination images with vector size aligned width
    Image<IPF_argb32> aimage1, aimage2, aresult;
    aimage1.set( wAligned, h );
    aimage1.clear( 0 );
    image1.copyTo( aimage1 );

    aimage2.set( wAligned, h );
    aimage2.clear( 0 );
    image2.copyTo( aimage2 );

    aresult.set( wAligned, h );

    // initialize pointers
    uint8_t const *sourcePtr1 = reinterpret_cast<uint8_t const *>( image1.getRawPointer() );
    uint8_t const *sourcePtr2 = reinterpret_cast<uint8_t const *>( image2.getRawPointer() );
    uint8_t *dest = reinterpret_cast<uint8_t *>( result.getRawPointer() );

    uint8_t const *alignedSourcePtr1 = reinterpret_cast<uint8_t const *>( aimage1.getRawPointer() );
    uint8_t const *alignedSourcePtr2 = reinterpret_cast<uint8_t const *>( aimage2.getRawPointer() );
    uint8_t *aDest = reinterpret_cast<uint8_t *>( aresult.getRawPointer() );

    Timer t;
    std::vector<std::vector<double> > timings( 10 );
    int const measurementCount = 10;

    for( int i = 0; i < measurementCount; i++ )
    {
        // we pass 4 times bigger width because each pixel has 4 color channel (argb)
        t.tic();
        AddImage8( dest, sourcePtr1, sourcePtr2, w * 4, h );
        timings[0].push_back( t.toc() );

        t.tic();
        AddImage8AlignedNEON( aDest, alignedSourcePtr1, alignedSourcePtr2, wAligned * 4, h );
        timings[1].push_back( t.toc() );

        t.tic();
        AddImage8UnalignedNEON( dest, sourcePtr1, sourcePtr2, w * 4, h );
        timings[2].push_back( t.toc() );

        t.tic();
        AddImage8MT( dest, sourcePtr1, sourcePtr2, w * 4, h );
        timings[3].push_back( t.toc() );

        t.tic();
        AddImage8NEON_MT( dest, sourcePtr1, sourcePtr2, w * 4, h );
        timings[4].push_back( t.toc() );

        result.copyTo( aimage1 );

        t.tic();
        VBlurImage8( aDest, alignedSourcePtr1, wAligned * 4, h, wAligned * 4, 0, h );
        timings[5].push_back( t.toc() );

        t.tic();
        VBlurImage8AlignedNEON( aDest, alignedSourcePtr1, wAligned * 4, h, wAligned * 4, 0, h );
        timings[6].push_back( t.toc() );

        t.tic();
        VBlurImage8MT( aDest, alignedSourcePtr1, wAligned * 4, h );
        timings[7].push_back( t.toc() );

        t.tic();
        VBlurImage8NEON_MT( aDest, alignedSourcePtr1, wAligned * 4, h );
        timings[8].push_back( t.toc() );

        t.tic();
        VBlurImage8NEON_MT_TILED( aDest, alignedSourcePtr1, wAligned * 4, h );
        timings[9].push_back( t.toc() );

        LOG( "%i/%i", i + 1, measurementCount );
    }

    const char *procNames[] =
    {
        "AddImage8", "AddImage8AlignedNEON", "AddImage8UnalignedNEON", "AddImage8MT", "AddImage8NEON_MT", "VBlurImage8",
        "VBlurImage8AlignedNEON", "VBlurImage8MT", "VBlurImage8NEON_MT", "VBlurImage8NEON_MT_TILED"
    };

    for( int i = 0; i < timings.size(); i++ )
    {
        // display median of all measurements for each type of call
        std::sort( timings[i].begin(), timings[i].end() );
        LOG( "%s(): %.3fms", procNames[i], timings[i][timings[i].size() / 2] );
    }

    // write out the result
    result.writeImage( "result0.bmp" );
    aresult.writeImage( "result1.bmp" );

#ifndef ANDROID
    return 0;
#else
    nv_app_force_quit_no_cleanup( app );
#endif
}

